@extends('layouts.admin')

@section('page-title')
    {{ __('Manage Warning') }}
@endsection

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('home') }}">{{ __('Home') }}</a></li>
    <li class="breadcrumb-item">{{ __('Warning') }}</li>
@endsection

@section('action-button')
    @if (\Auth::user()->type != 'employee')
        @can('Create Warning')
            <a href="#" data-url="{{ route('warning.create') }}" data-ajax-popup="true"
                data-title="{{ __('Create New Warning') }}" data-size="lg" data-bs-toggle="tooltip" title=""
                class="btn btn-sm btn-primary" data-bs-original-title="{{ __('Create') }}">
                <i class="ti ti-plus"></i>
            </a>
        @endcan
    @endif
@endsection
@section('content')
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-header card-body table-border-style">
                    {{-- <h5> </h5> --}}
                    <div class="table-responsive">
                        <table class="table" id="pc-dt-simple">
                            <thead>
                                <tr>
                                    <th>{{ __('Warning By') }}</th>
                                    <th>{{ __('Warning To') }}</th>
                                    <th>{{ __('Subject') }}</th>
                                    <th>{{ __('Warning Date') }}</th>
                                    <th>{{ __('Description') }}</th>
                                    @if (Gate::check('Edit Warning') || Gate::check('Delete Warning'))
                                        <th width="200px">{{ __('Action') }}</th>
                                    @endif
                                </tr>
                            </thead>
                            <tbody>

                                @foreach ($warnings as $warning)
                                    <tr>
                                        <td>{{ !empty($warning->warningBy) ? $warning->warningBy->name : '' }}
                                        </td>
                                        <td>{{ !empty($warning->warningTo) ? $warning->warningTo->name : '' }}
                                        </td>
                                        <td>{{ $warning->subject }}</td>
                                        <td>{{ \Auth::user()->dateFormat($warning->warning_date) }}</td>
                                        <td class="dispwrap">{{ $warning->description }}</td>
                                        <td class="Action">
                                            @if (\Auth::user()->type != 'employee')
                                                @if (Gate::check('Edit Warning') || Gate::check('Delete Warning'))
                                                    <span>
                                                        @can('Edit Warning')
                                                            @if (Auth::user()->type == 'company')
                                                                <div class="action-btn bg-info ms-2">
                                                                    <a href="#"
                                                                        class="mx-3 btn btn-sm  align-items-center"
                                                                        data-size="lg"
                                                                        data-url="{{ URL::to('warning/' . $warning->id . '/edit') }}"
                                                                        data-ajax-popup="true" data-size="md"
                                                                        data-bs-toggle="tooltip" title=""
                                                                        data-title="{{ __('Edit Warning') }}"
                                                                        data-bs-original-title="{{ __('Edit') }}">
                                                                        <i class="ti ti-pencil text-white"></i>
                                                                    </a>
                                                                </div>
                                                            @else
                                                                @if ($warning->main_created_by == Auth::id() || $warning->warning_by == Auth::user()->getUSerEmployee(Auth::id())->id)
                                                                    <div class="action-btn bg-info ms-2">
                                                                        <a href="#"
                                                                            class="mx-3 btn btn-sm  align-items-center"
                                                                            data-size="lg"
                                                                            data-url="{{ URL::to('warning/' . $warning->id . '/edit') }}"
                                                                            data-ajax-popup="true" data-size="md"
                                                                            data-bs-toggle="tooltip" title=""
                                                                            data-title="{{ __('Edit Warning') }}"
                                                                            data-bs-original-title="{{ __('Edit') }}">
                                                                            <i class="ti ti-pencil text-white"></i>
                                                                        </a>
                                                                    </div>
                                                                @endif
                                                            @endif
                                                        @endcan

                                                        @can('Delete Warning')
                                                            @if (Auth::user()->type == 'company')
                                                                <div class="action-btn bg-danger ms-2">
                                                                    {!! Form::open([
                                                                        'method' => 'DELETE',
                                                                        'route' => ['warning.destroy', $warning->id],
                                                                        'id' => 'delete-form-' . $warning->id,
                                                                    ]) !!}
                                                                    <a href="#"
                                                                        class="mx-3 btn btn-sm  align-items-center bs-pass-para"
                                                                        data-bs-toggle="tooltip" title=""
                                                                        data-bs-original-title="Delete" aria-label="Delete"><i
                                                                            class="ti ti-trash text-white text-white"></i></a>
                                                                    </form>
                                                                </div>
                                                            @else
                                                                @if ($warning->main_created_by == Auth::id() || $warning->warning_by == Auth::user()->getUSerEmployee(Auth::id())->id)
                                                                    <div class="action-btn bg-danger ms-2">
                                                                        {!! Form::open([
                                                                            'method' => 'DELETE',
                                                                            'route' => ['warning.destroy', $warning->id],
                                                                            'id' => 'delete-form-' . $warning->id,
                                                                        ]) !!}
                                                                        <a href="#"
                                                                            class="mx-3 btn btn-sm  align-items-center bs-pass-para"
                                                                            data-bs-toggle="tooltip" title=""
                                                                            data-bs-original-title="Delete"
                                                                            aria-label="Delete"><i
                                                                                class="ti ti-trash text-white text-white"></i></a>
                                                                        </form>
                                                                    </div>
                                                                @endif
                                                            @endif
                                                        @endcan
                                                    </span>
                                                @endif
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach


                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection


@push('script-page')
    <script>
        $(document).ready(function() {

            $("#commonModal").on("submit", 'form', function(event) {
                event.preventDefault();
                var form_cust = this;
                var formData = new FormData(form_cust);
                var url = $(this).attr('action');
                var type = "POST";
                $.ajax({
                    context: 'commonModal',
                    type: type,
                    url: url,
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.status == 1) {
                            show_toastr('Success', response.message, 'success');
                            location.reload();
                        }
                        if (response.status == 0) {
                            $.each(response.message, function(key, value) {
                                toastr.error(value)
                            });
                        }
                    },
                })
                return false;
            });
        });
    </script>
@endpush
