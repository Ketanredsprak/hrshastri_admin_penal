@extends('layouts.admin')

@section('page-title')
{{ __('Manage Leave Request') }}
@endsection


@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('home') }}">{{ __('Home') }}</a></li>
<li class="breadcrumb-item">{{ __('Leave ') }}</li>
@endsection

@section('action-button')
<a href="#" data-url="{{ route('leave_request_create') }}" data-ajax-popup="true" data-title="{{ __('Create New Leave') }}" data-size="lg" data-bs-toggle="tooltip" title="" class="btn btn-sm btn-primary" data-bs-original-title="{{ __('Create') }}">
     <i class="ti ti-plus"></i>
</a>
@endsection




@section('content')
<div class="row">

     <div class="col-xxl-4 col-md-4 col-sm-6">
          <div class="card">
               <div class="card-body">
                    <div class="row align-items-center justify-content-between">
                         <div class="col-auto mb-3 mb-sm-0">
                              <div class="d-flex align-items-center">
                                   <div class="theme-avtar bg-warning">
                                        <i class="ti ti-circle-minus"></i>
                                        <i class="fa-solid fa-lights-holiday"></i>
                                   </div>
                                   <div class="ms-3">
                                        <small class="text-muted">{{ __('Total') }}</small>
                                        <h6 class="m-0">{{ __('Pending') }}</h6>
                                   </div>
                              </div>
                         </div>
                         <div class="col-auto text-end">
                              <h4 class="m-0 text-warning">{{ re_leave_pending() }}</h4>
                         </div>
                    </div>
               </div>
          </div>
     </div>
     <div class="col-xxl-4 col-md-4 col-sm-6">
          <div class="card">
               <div class="card-body">
                    <div class="row align-items-center justify-content-between">
                         <div class="col-auto mb-3 mb-sm-0">
                              <div class="d-flex align-items-center">
                                   <div class="theme-avtar bg-success">
                                        <i class="ti ti-circle-check"></i>
                                   </div>
                                   <div class="ms-3">
                                        <small class="text-muted">{{ __('Total') }}</small>
                                        <h6 class="m-0">{{ __('Approved') }}</h6>
                                   </div>
                              </div>
                         </div>
                         <div class="col-auto text-end">
                              <h4 class="m-0 text-success">{{ re_leave_approved() }}</h4>
                         </div>
                    </div>
               </div>
          </div>
     </div>
     <div class="col-xxl-4 col-md-4 col-sm-6">
          <div class="card">
               <div class="card-body">
                    <div class="row align-items-center justify-content-between">
                         <div class="col-auto mb-3 mb-sm-0">
                              <div class="d-flex align-items-center">
                                   <div class="theme-avtar bg-danger">
                                        <i class="ti ti-circle-x"></i>
                                   </div>
                                   <div class="ms-3">
                                        <small class="text-muted">{{ __('Total') }}</small>
                                        <h6 class="m-0">{{ __('Rejected') }}</h6>
                                   </div>
                              </div>
                         </div>
                         <div class="col-auto text-end">
                              <h4 class="m-0 text-danger">{{ re_leave_rejected() }}</h4>
                         </div>
                    </div>
               </div>
          </div>
     </div>

     <div class="col-xl-12">
          <div class="card">
               <div class="card-header card-body table-border-style">
                    <div class="table-responsive">
                         <table class="table" id="pc-dt-simple">
                              <thead>
                                   <tr>

                                        <th>{{ __('Employee') }}</th>

                                        <th>{{ __('Leave Type') }}</th>
                                        <th>{{ __('Applied On') }}</th>
                                        <th>{{ __('Start Date') }}</th>
                                        <th>{{ __('End Date') }}</th>
                                        <th>{{ __('Total Days') }}</th>

                                        <th>{{ __('status') }}</th>


                                        <th width="200px">{{ __('Action') }}</th>
                                   </tr>
                              </thead>
                              <?php $total_leave_data = 0; ?>
                              <tbody>
                                   @if(!empty($leavesRequest))
                                   @foreach ($leavesRequest as $leave)
                                   <tr>
                                        @if (\Auth::user()->type != 'employee')
                                        <td>
                                             @php
                                             $data = App\Models\Employee::find($leave->employee_id);

                                             @endphp
                                             {{ !empty(\Auth::user()->getEmployee($leave->employee_id)) ? \Auth::user()->getEmployee($leave->employee_id)->name : '' }}
                                        </td>
                                        @endif

                                        <td>{{ !empty(\Auth::user()->getLeaveType($leave->leave_type_id)) ? \Auth::user()->getLeaveType($leave->leave_type_id)->title : '' }}
                                        </td>
                                        <td>{{ \Auth::user()->dateFormat($leave->applied_on) }}</td>
                                        <td>{{ \Auth::user()->dateFormat($leave->start_date) }}</td>
                                        <td>{{ \Auth::user()->dateFormat($leave->end_date) }}</td>
                                        <td>{{ $leave->total_leave_days }}</td>


                                        <td>
                                             @if ($leave->status == 'Pending')

                                             <div class="badge bg-warning p-2 px-3 rounded status-badge5">
                                                  {{ $leave->status }}
                                             </div>

                                             @elseif($leave->status == 'Approved')

                                             <div class="badge bg-success p-2 px-3 rounded status-badge5">
                                                  {{ $leave->status }}
                                             </div>

                                             @elseif($leave->status == 'Reject')
                                             <div class="badge bg-danger p-2 px-3 rounded status-badge5">
                                                  {{ $leave->status }}
                                             </div>

                                             @endif
                                        </td>


                                        <td class="Action">


                                             <div class="action-btn bg-success">
                                                  <a href="#" class="mx-3 btn btn-sm  align-items-center" data-size="lg" data-url="{{ URL::to('leave/' . $leave->id . '/action') }}" data-ajax-popup="true" data-size="md" data-bs-toggle="tooltip" title="" data-title="{{ __('Leave Action') }}" data-bs-original-title="{{ __('Manage Leave') }}">
                                                       <i class="ti ti-caret-right text-white"></i>
                                                  </a>
                                             </div>

                                             <!-- edit leave -->
                                             <div class="action-btn bg-info ms-2">
                                                  <a href="#" class="mx-3 btn btn-sm  align-items-center" data-size="lg" data-url="{{ URL::to('leave/' . $leave->id . '/edit') }}?redirect=leaverequest" data-ajax-popup="true" data-size="md" data-bs-toggle="tooltip" title="" data-title="{{ __('Edit Leave') }}" data-bs-original-title="{{ __('Edit') }}">
                                                       <i class="ti ti-pencil text-white"></i>
                                                  </a>
                                             </div>
                                             <!-- edit leave -->

                                             @can('Delete Leave')


                                             {{-- <div class="action-btn bg-danger ms-2">
                                                        {!! Form::open([
                                                            'method' => 'DELETE',
                                                            'route' => ['leave.destroy', $leave->id],
                                                            'id' => 'delete-form-' . $leave->id,
                                                        ]) !!}
                                                        <a href="#"
                                                            class="mx-3 btn btn-sm  align-items-center bs-pass-para"
                                                            data-bs-toggle="tooltip" title=""
                                                            data-bs-original-title="Delete" aria-label="Delete"><i
                                                                class="ti ti-trash text-white text-white"></i></a>
                                                        </form>
                                                    </div>  --}}
                                             @endcan

                                        </td>
                                   </tr>
                                   @endforeach
                                   @endif
                              </tbody>
                         </table>
                    </div>
               </div>
          </div>
     </div>
</div>



</div>
@endsection