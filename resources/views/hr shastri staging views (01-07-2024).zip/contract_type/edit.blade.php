
{{ Form::model($contractType, array('route' => array('contract_type.update', $contractType->id), 'method' => 'PUT')) }}
<div class="modal-body">
    <div class="row">
        <div class="form-group col-12">
            {{ Form::label('name', __('Contract Type Name'),['class'=>'col-form-label']) }} <span class="text-danger"> * </span>
            {{ Form::text('name', null, array('class' => 'form-control','required'=>'required','placeholder' => 'Contract Type Name')) }}
        </div>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn  btn-light" data-bs-dismiss="modal">{{__('Close')}}</button>
    <button type="submit" class="btn  btn-primary">{{__('Update')}}</button>
</div>
   
{{ Form::close() }}

