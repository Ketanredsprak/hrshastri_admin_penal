@extends('layouts.admin')

@section('page-title')
{{ __('Manage Resignation Request') }}
@endsection

@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('home') }}">{{ __('Home') }}</a></li>
<li class="breadcrumb-item">{{ __('Resignation') }}</li>
@endsection


@section('content')
<div class="row">

     <div class="col-xl-12">
          <div class="card">
               <div class="card-header card-body table-border-style">
                    {{-- <h5> </h5> --}}
                    <div class="table-responsive">
                         <table class="table" id="pc-dt-simple">
                              <thead>
                                   <tr>
                                        <th>{{ __('Employee Name') }}</th>
                                        <th>{{ __('Resignation Date') }}</th>
                                        <th>{{ __('Last Working Day') }}</th>

                                        <th>{{ __('Reason') }}</th>
                                        <th>{{ __('Notes') }}</th>
                                        <th class="text-end">{{ __('status') }}</th>

                                        @if (Auth::user()->type == 1)
                                        <th width="200px">{{ __('Action') }}</th>
                                        @endif
                                   </tr>
                              </thead>
                              <tbody>
                                   @foreach ($resignations as $resignation)
                                   <tr>
                                        <td>{{ !empty($resignation->employee()) ? $resignation->employee()->name : '' }}</td>
                                        <td>{{ \Auth::user()->dateFormat($resignation->notice_date) }}</td>
                                        <td>{{ \Auth::user()->dateFormat($resignation->resignation_date) }}</td>

                                        <td>
                                             <!-- data-bs-toggle="tooltip"  -->
                                             <p title="{{$resignation->description}}">
                                                  {{ substr($resignation->description, 0, 60) . '..' }}
                                             </p>
                                        </td>

                                        <td>
                                             <p title="{{$resignation->notes}}">
                                                  {{ substr($resignation->notes, 0, 60) . '..' }}
                                             </p>
                                        </td>

                                        <td class="text-end">
                                             @if ($resignation->status == 0)
                                             <div class="badge bg-warning p-2 px-3 rounded status-badge5">pending</div>
                                             @endif

                                             @if ($resignation->status == 1)
                                             <div class="badge bg-success p-2 px-3 rounded status-badge5">Approved</div>
                                             @endif
                                             @if ($resignation->status == 2)
                                             <div class="badge bg-danger p-2 px-3 rounded status-badge5">Rejected</div>
                                             @endif

                                        </td>

                                        @if (Auth::user()->type != "employee")
                                        <td class="Action">
                                             <span>

                                                  <!-- 0 = pending, 1 = Approved, 2 = Rejected	 -->
                                                  @if (in_array($resignation->status, [0]))
                                                  <div class="action-btn bg-success ms-2">
                                                       <a href="#" class="mx-3 btn btn-sm  align-items-center" data-size="lg" data-url="{{ URL::to('resignation/' . $resignation->id . '/action') }}" data-ajax-popup="true" data-size="md" data-bs-toggle="tooltip" title="" data-title="{{ __('Resignation Action') }}" data-bs-original-title="{{ __('Manage Resignation') }}">
                                                            <i class="ti ti-caret-right text-white"></i>
                                                       </a>
                                                  </div>
                                                  @endif

                                                  @if (in_array($resignation->status, [1]))
                                                  <div class="action-btn bg-primary ms-2">
                                                       <a href="#" class="mx-3 btn btn-sm  align-items-center" data-size="lg" data-url="{{ URL::to('resignation/' . $resignation->id . '/exit_inerview') }}" data-ajax-popup="true" data-size="md" data-bs-toggle="tooltip" title="" data-title="{{ __('Exit Interview') }}" data-bs-original-title="{{ __('Exit Interview') }}">
                                                            <i class="ti ti-user text-white"></i>
                                                       </a>
                                                  </div>
                                                  @endif

                                                  @can('Delete Resignation')
                                                  @if (in_array($resignation->status, [0]))
                                                  <div class="action-btn bg-danger ms-2">
                                                       {!! Form::open(['method' => 'DELETE', 'route' => ['resignation.destroy', $resignation->id], 'id' => 'delete-form-' . $resignation->id]) !!}
                                                       <a href="#" class="mx-3 btn btn-sm  align-items-center bs-pass-para" data-bs-toggle="tooltip" title="" data-bs-original-title="Delete" aria-label="Delete"><i class="ti ti-trash text-white text-white"></i></a>
                                                       {!! Form::close() !!}
                                                  </div>
                                                  @endif
                                                  @endcan
                                             </span>

                                        </td>
                                        @endif
                                   </tr>
                                   @endforeach

                              </tbody>
                         </table>
                    </div>
               </div>
          </div>
     </div>
</div>
@endsection