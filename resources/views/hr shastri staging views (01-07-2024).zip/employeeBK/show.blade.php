@extends('layouts.admin')
@section('page-title')
{{__('Employee')}}
@endsection
@section('breadcrumb')
<li class="breadcrumb-item"><a href="{{ route('home') }}">{{ __('Home') }}</a></li>
<li class="breadcrumb-item"><a href="{{ url('employee') }}">{{ __('Employee') }}</a></li>
<li class="breadcrumb-item">{{ __('Manage Employee') }}</li>
@endsection
@section('action-button')
<div class="float-end">
   @can('edit employee')
   <a href="{{route('employee.edit',\Illuminate\Support\Facades\Crypt::encrypt($employee->id))}}" data-bs-toggle="tooltip" title="{{__('Edit')}}"class="btn btn-sm btn-primary">
   <i class="ti ti-pencil"></i>
   </a>
   @endcan
</div>
<div class="text-end mb-3">
   <div class="d-flex justify-content-end drp-languages">
      <ul class="list-unstyled mb-0 m-2">
         <li class="dropdown dash-h-item drp-language">
            <a class="dash-head-link dropdown-toggle arrow-none me-0" data-bs-toggle="dropdown" href="#"
               role="button" aria-haspopup="false" aria-expanded="false">
            <span class="drp-text hide-mob text-primary"> {{__('Joining Letter')}}
            <i class="ti ti-chevron-down drp-arrow nocolor hide-mob"></i>
            </a>
            <div class="dropdown-menu dash-h-dropdown">
               <a href="{{route('joiningletter.download.pdf',$employee->id)}}" class=" btn-icon dropdown-item" data-bs-toggle="tooltip" data-bs-placement="top"  target="_blanks"><i class="ti ti-download ">&nbsp;</i>{{__('PDF')}}</a>
               <a href="{{route('joininglatter.download.doc',$employee->id)}}" class=" btn-icon dropdown-item" data-bs-toggle="tooltip" data-bs-placement="top"  target="_blanks"><i class="ti ti-download ">&nbsp;</i>{{__('DOC')}}</a>
            </div>
         </li>
      </ul>
      <ul class="list-unstyled mb-0 m-2">
         <li class="dropdown dash-h-item drp-language">
            <a class="dash-head-link dropdown-toggle arrow-none me-0" data-bs-toggle="dropdown" href="#"
               role="button" aria-haspopup="false" aria-expanded="false">
            <span class="drp-text hide-mob text-primary"> {{__('Experience Certificate')}}
            <i class="ti ti-chevron-down drp-arrow nocolor hide-mob"></i>
            </a>
            <div class="dropdown-menu dash-h-dropdown">
               <a href="{{route('exp.download.pdf',$employee->id)}}" class=" btn-icon dropdown-item" data-bs-toggle="tooltip" data-bs-placement="top"  target="_blanks"><i class="ti ti-download ">&nbsp;</i>{{__('PDF')}}</a>
               <a href="{{route('exp.download.doc',$employee->id)}}" class=" btn-icon dropdown-item" data-bs-toggle="tooltip" data-bs-placement="top"  target="_blanks"><i class="ti ti-download ">&nbsp;</i>{{__('DOC')}}</a>
            </div>
         </li>
      </ul>
      <ul class="list-unstyled mb-0 m-2">
         <li class="dropdown dash-h-item drp-language">
            <a class="dash-head-link dropdown-toggle arrow-none me-0" data-bs-toggle="dropdown" href="#"
               role="button" aria-haspopup="false" aria-expanded="false">
            <span class="drp-text hide-mob text-primary"> {{__('NOC')}}
            <i class="ti ti-chevron-down drp-arrow nocolor hide-mob"></i>
            </a>
            <div class="dropdown-menu dash-h-dropdown">
               <a href="{{route('noc.download.pdf',$employee->id)}}" class=" btn-icon dropdown-item" data-bs-toggle="tooltip" data-bs-placement="top"  target="_blanks"><i class="ti ti-download ">&nbsp;</i>{{__('PDF')}}</a>
               <a href="{{route('noc.download.doc',$employee->id)}}" class=" btn-icon dropdown-item" data-bs-toggle="tooltip" data-bs-placement="top"  target="_blanks"><i class="ti ti-download ">&nbsp;</i>{{__('DOC')}}</a>
            </div>
         </li>
      </ul>
   </div>
</div>
@endsection
@section('content')
<div class="row">
   <div class="col-sm-12">
      <div class="card">
         <div class="card-body">
            <div class="employ_dtl">
               <div class="emploimg">
                  <img alt="#" src="https://redsparkte.a2hosted.com/hrms_staging//storage/uploads/avatar/Max-R_Headshot (1)_1681820818.jpg" class="" >
               </div>
               <div class="employctn">
                  <div class="row">
                     <div class="col-lg-3 col-sm-6">
                        <h5 class="mt-2"> {{$employee->name}}</h5>
                        <p> {{$employeesId}}</p>
                     </div>
                     <div class="col-lg-3 col-sm-6">
                        <div class="info text-sm mb-3 font-style">
                           <strong class="font-bold">Email :</strong>
                           <span>{{$employee->email}}</span>
                        </div>
                        <div class="info text-sm">
                           <strong class="font-bold">Phone :</strong>
                           <span>{{$employee->phone}}</span>
                        </div>
                     </div>
                     <div class="col-lg-3 col-sm-6">
                        <div class="info mb-3 text-sm">
                           <strong class="font-bold">Phone :</strong>
                           <span>{{$employee->phone}}</span>
                        </div>
                        <div class="info  text-sm">
                           <strong class="font-bold">Date of Birth :</strong>
                           <span>{{\Auth::user()->dateFormat($employee->dob)}}</span>
                        </div>
                     </div>
                     <div class="col-lg-3 col-sm-6">
                        <div class="info mb-3 text-sm">
                           <input type="checkbox" @if($employee->employee_exit == 1) checked @endif class="form-check-input isscheck isscheck_User" disabled id="employee_exit" name="employee_exit" value="1">
                           <strong class="form-label font-weight-500" for="employee_exit">&nbsp;Exit</strong>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <hr>
            <nav>
               <div class="nav nav-tabs tablists mb-3" id="nav-tab" role="tablist">
                  <button class="nav-link active" id="nav-Salary-tab" data-bs-toggle="tab" data-bs-target="#nav-Salary" type="button" role="tab" aria-controls="nav-Salary" aria-selected="true">Personal Detail</button>
                  <button class="nav-link" id="nav-Allowance-tab" data-bs-toggle="tab" data-bs-target="#nav-Allowance" type="button" role="tab" aria-controls="nav-Allowance" aria-selected="false">Company</button>
                  <button class="nav-link" id="nav-Experience-tab" data-bs-toggle="tab" data-bs-target="#nav-Experience" type="button" role="tab" aria-controls="nav-Experience" aria-selected="false">Experience</button>
                  <button class="nav-link" id="nav-Education-tab" data-bs-toggle="tab" data-bs-target="#nav-Education" type="button" role="tab" aria-controls="nav-Education" aria-selected="false"> Education</button>
                  <button class="nav-link" id="nav-Dependent-tab" data-bs-toggle="tab" data-bs-target="#nav-Dependent" type="button" role="tab" aria-controls="nav-Dependent" aria-selected="false">Dependent</button>
                  <button class="nav-link" id="nav-Commission-tab" data-bs-toggle="tab" data-bs-target="#nav-Commission" type="button" role="tab" aria-controls="nav-Commission" aria-selected="false">Document</button>
                  <button class="nav-link" id="nav-Loan-tab" data-bs-toggle="tab" data-bs-target="#nav-Loan" type="button" role="tab" aria-controls="nav-Loan" aria-selected="false">Bank Account</button>
                  @if (Auth::user()->type == 'employee')
                  <button class="nav-link" id="nav-Payslip-tab" data-bs-toggle="tab" data-bs-target="#nav-Payslip" type="button" role="tab" aria-controls="nav-Loan" aria-selected="false">Payslip</button>
                  @endif
               </div>
            </nav>
            <div class="tab-content tab_ctn" id="nav-tabContent">
               <div class="tab-pane fade active show" id="nav-Salary" role="tabpanel" aria-labelledby="nav-Salary-tab">
                  <div class="card ">
                     <div class="card-body employee-detail-body fulls-card emp-card">
                        <h5>{{__('Personal Detail')}}</h5>
                        <hr>
                        <div class="row">
                           <div class="col-md-6">
                              <div class="info text-sm">
                                 <strong class="font-bold">{{__('Employee ID')}} : </strong>
                                 <span>{{$employeesId}}</span>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="info text-sm font-style">
                                 <strong class="font-bold">{{__('Name')}} :</strong>
                                 <span>{{$employee->name}}</span>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="info text-sm font-style">
                                 <strong class="font-bold">{{__('Email')}} :</strong>
                                 <span>{{$employee->email}}</span>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="info text-sm">
                                 <strong class="font-bold">{{__('Date of Birth')}} :</strong>
                                 <span>{{\Auth::user()->dateFormat($employee->dob)}}</span>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="info text-sm">
                                 <strong class="font-bold">{{__('Phone')}} :</strong>
                                 <span>{{$employee->phone}}</span>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="info text-sm">
                                 <strong class="font-bold">{{__('Address')}} :</strong>
                                 <span>{{$employee->address}}</span>
                              </div>
                           </div>
                           <div class="col-md-6">
                              <div class="info text-sm">
                                 <strong class="font-bold">{{__('Marital')}} :</strong>
                                 <span>{{$employee->marital_status}}</span>
                              </div>
                           </div>
                           @if(!empty($userdata))
                           <div class="col-md-6">
                              <div class="info text-sm">
                                 <strong class="font-bold">{{__('Team Leader')}} :</strong>
                                 <span>{{$userdata->name}}</span>
                              </div>
                           </div>
                           @endif
                           <div class="col-md-6">
                              <div class="info text-sm">
                                 <strong class="font-bold">{{__('Basic Salary')}} :</strong>
                                 <span>{{$employee->salary}}</span>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade" id="nav-Allowance" role="tabpanel" aria-labelledby="nav-Allowance-tab">
                  <!-- Company -->
                  <!-- company data hear -->
                  <div class="row">
                     <div class="col-sm-12 col-md-12">
                     </div>
                     <div class="col-sm-12 col-md-12">
                        <div class="card ">
                           <div class="card-body employee-detail-body fulls-card emp-card">
                              <h5>{{__('Company')}}</h5>
                              <hr>
                              <div class="row">
                                 <div class="col-md-6">
                                    <div class="info text-sm">
                                       <strong class="font-bold">{{__('Branch')}} : </strong>
                                       <span>{{!empty($employee->branch)?$employee->branch->name:''}}</span>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="info text-sm font-style">
                                       <strong class="font-bold">{{__('Department')}} :</strong>
                                       <span>{{!empty($employee->department)?$employee->department->name:''}}</span>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="info text-sm">
                                       <strong class="font-bold">{{__('Designation')}} :</strong>
                                       <span>{{!empty($employee->designation)?$employee->designation->name:''}}</span>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="info text-sm">
                                       <strong class="font-bold">{{__('Employee Status')}} :</strong>
                                       <span>{{ $employee->employe_status}}</span>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="info text-sm">
                                       <strong class="font-bold">{{__('Employee Types')}} :</strong>
                                       <span>{{ $employee->employe_types}}</span>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="info text-sm">
                                       <strong class="font-bold">{{__('Experience')}} :</strong>
                                       <span>{{ $employee->employee_experience}}</span>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="info text-sm">
                                       <strong class="font-bold">{{__('Date on Exit')}} :</strong>
                                       <span>{{ $employee->date_of_exit}}</span>
                                    </div>
                                 </div>
                                 <div class="col-md-6">
                                    <div class="info text-sm">
                                       <strong class="font-bold">{{__('Date Of Joining')}} :</strong>
                                       <span>{{\Auth::user()->dateFormat($employee->company_doj)}}</span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade" id="nav-Commission" role="tabpanel" aria-labelledby="nav-Commission-tab">
                  <!-- Document -->
                  <div class="col-sm-12 col-md-12">
                     <div class="card ">
                        <div class="card-body employee-detail-body fulls-card emp-card">
                           <h5>{{__('Document')}}</h5>
                           <hr>
                           <div class="row">
                              @php
                              $employeedoc = $employee->documents()->pluck('document_value','document_id');
                              $logo=\App\Models\Utility::get_file('uploads/document');
                              @endphp
                              @if(!$documents->isEmpty())
                              @foreach($documents as $key=>$document)
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{$document->name }} : </strong>
                                    <span><a href="{{ (!empty($employeedoc[$document->id])?$logo.'/'.$employeedoc[$document->id]:'') }}" target="_blank">{{ (!empty($employeedoc[$document->id])?$employeedoc[$document->id]:'') }}</a></span>
                                 </div>
                              </div>
                              @endforeach
                              @else
                              <div class="text-center">
                                 No Document Type Added.!
                              </div>
                              @endif
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               {{-- //Work Experience-TABLE  --}}
               <div class="tab-pane fade" id="nav-Experience" role="tabpanel" aria-labelledby="nav-Experience-tab">
                  {{-- //Work Experience-TABLE --}}
                  @foreach($EXPTableData as $key=>$exp)
                  <div class="col-sm-12 col-md-12">
                     <div class="card ">
                        <div class="card-body employee-detail-body fulls-card emp-card">
                           <h5>{{ $key+1 }}   {{__('Work Experience')}}</h5>
                           <hr>
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Previous Company')}} : </strong>
                                    <span>{{$exp->previous_company_name}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm font-style">
                                    <strong class="font-bold">{{__('Job Title')}} :</strong>
                                    <span>{{$exp->previous_job_title}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('From Date')}} :</strong>
                                    <span>{{$exp->previous_from_date}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('To Date')}} :</strong>
                                    <span>{{$exp->previous_to_date}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Designation')}} :</strong>
                                    <?php $data = App\Models\Designation::where('id',$exp->previous_company_designation_id)->first()?>
                                    @if(!empty($data))
                                    <span>{{$data->name}}</span>
                                    @endif
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Experience Job Description')}} :</strong>
                                    <span>{{$exp->experiance_Job_description}}</span>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  @endforeach
                  {{-- //Work-TABLE --}}
               </div>
               {{-- //Education-TABLE  --}}
               <div class="tab-pane fade" id="nav-Education" role="tabpanel" aria-labelledby="nav-Education-tab">
                  {{-- //Education-TABLE --}}
                  @foreach($EducationData as $key=>$edu)
                  <div class="col-sm-12 col-md-12">
                     <div class="card ">
                        <div class="card-body employee-detail-body fulls-card emp-card">
                           <h5>{{ $key+1}}  {{__('Education')}}</h5>
                           <hr>
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Institute Name')}} : </strong>
                                    <span>{{$edu->institute_name}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm font-style">
                                    <strong class="font-bold">{{__('Education')}} :</strong>
                                    <span>{{$edu->education}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Specialization')}} :</strong>
                                    <span>{{$edu->specialization}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Date of completion')}} :</strong>
                                    <span>{{$edu->date_of_completion}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Notes')}} :</strong>
                                    <span>{{$edu->notes}}</span>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  @endforeach
                  {{-- //Education-TABLE --}}
               </div>
               {{-- //depended --}}
               {{-- //depended-TABLE  --}}
               <div class="tab-pane fade" id="nav-Dependent" role="tabpanel" aria-labelledby="nav-Dependent-tab">
                  {{-- //depended-TABLE --}}
                  @foreach($DependentData as $key=>$edu)
                  <div class="col-sm-12 col-md-12">
                     <div class="card ">
                        <div class="card-body employee-detail-body fulls-card emp-card">
                           <h5>{{ $key+1}} {{__('Dependent')}}</h5>
                           <hr>
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Name')}} : </strong>
                                    <span>{{$edu->dependent_name}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm font-style">
                                    <strong class="font-bold">{{__('Relation ')}} :</strong>
                                    <span>{{$edu->dependent_relation}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Date of completion')}} :</strong>
                                    <span>{{$edu->dependent_dob}}</span>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  @endforeach
                  {{-- //Education-TABLE --}}
               </div>
               <div class="tab-pane fade" id="nav-Loan" role="tabpanel" aria-labelledby="nav-Loan-tab">
                  <div class="col-sm-12 col-md-12">
                     <div class="card ">
                        <div class="card-body employee-detail-body fulls-card emp-card">
                           <h5>{{__('Bank Account')}}</h5>
                           <hr>
                           <div class="row">
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Account Holder Name')}} : </strong>
                                    <span>{{$employee->account_holder_name}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm font-style">
                                    <strong class="font-bold">{{__('Account Number')}} :</strong>
                                    <span>{{$employee->account_number}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Bank Name')}} :</strong>
                                    <span>{{$employee->bank_name}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Bank Identifier Code')}} :</strong>
                                    <span>{{$employee->bank_identifier_code}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Branch Location')}} :</strong>
                                    <span>{{$employee->branch_location}}</span>
                                 </div>
                              </div>
                              <div class="col-md-6">
                                 <div class="info text-sm">
                                    <strong class="font-bold">{{__('Tax Payer Id')}} :</strong>
                                    <span>{{$employee->tax_payer_id}}</span>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="tab-pane fade" id="nav-Payslip" role="tabpanel" aria-labelledby="nav-Payslip-tab">
                  <div class="col-12">
                     <div class="card">
                        <div class="card-header">
                           <div class="d-flex align-items-center justify-content-start mb-4">
                              <h5>{{ __('Payslip') }}</h5>
                           </div>
                           <div class="row">
                              <div class="col-sm-8">
                                 <div class="row">
                                    <div class="col-sm-6 col-lg-4">
                                       <div class="btn-box">
                                          <select class="form-control month_date " name="year" tabindex="-1" aria-hidden="true">
                                             <option value="--">--</option>
                                             @foreach ($month as $k => $mon)
                                             @php
                                             $selected = date('m') - 1 == $k ? 'selected' : '';
                                             @endphp
                                             <option value="{{ $k }}" {{ $selected }}>{{ $mon }}</option>
                                             @endforeach
                                          </select>
                                       </div>
                                    </div>
                                    <div class="col-sm-6 col-lg-4">
                                       <div class="btn-box">
                                          {{ Form::select('year', $year, null, ['class' => 'form-control year_date ']) }}
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="card-body px-0">
                           <div class="table-responsive">
                              <table class="table" id="pc-dt-render-column-cells">
                                 <thead>
                                    <tr>
                                       <th>{{ __('Employee Id') }}</th>
                                       {{-- 
                                       <th>{{ __('Name') }}</th>
                                       --}}
                                       <th>{{ __('Payroll Type') }}</th>
                                       <th>{{ __('Salary') }}</th>
                                       <th>{{ __('Net Salary') }}</th>
                                       <th>{{ __('Status') }}</th>
                                       <th>{{ __('Action') }}</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                 </tbody>
                              </table>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
</div>
@endsection
@push('script-page')
<script>
   $(document).ready(function() {
       callback();
   
       function callback() {
           var month = $(".month_date").val();
           var year = $(".year_date").val();
   
           $('.filter_month').val(month);
           $('.filter_year').val(year);
   
           if (month == '') {
               month = '{{ date('m', strtotime('last month')) }}';
               year = '{{ date('Y') }}';
   
               $('.filter_month').val(month);
               $('.filter_year').val(year);
           }
   
           var datePicker = year + '-' + month;
   
           $.ajax({
               url: '{{ route('payslip.search_json') }}',
               type: 'POST',
               data: {
                   "datePicker": datePicker,
                   "_token": "{{ csrf_token() }}",
               },
               success: function(data) {
                   console.log(data);
                   var datatable_data = {
                       data: data
                   };
   
                   function renderstatus(data, cell, row) {
                       if (data == 'Paid')
                           return '<div class="badge bg-success p-2 px-3 rounded"><a href="#" class="text-white">' +
                               data + '</a></div>';
                       else
                           return '<div class="badge bg-danger p-2 px-3 rounded"><a href="#" class="text-white">' +
                               data + '</a></div>';
                   }
   
                   function renderButton(data, cell, row) {
   
                       var $div = $(row);
                       employee_id = $div.find('td:eq(0)').text();
                       status = $div.find('td:eq(6)').text();
   
                       var month = $(".month_date").val();
                       var year = $(".year_date").val();
                       var id = employee_id;
                       var payslip_id = data;
   
                       var clickToPaid = '';
                       var payslip = '';
                       var view = '';
                       var edit = '';
                       var deleted = '';
                       var form = '';
   
                       if (data != 0) {
                           var payslip =
                               '<a href="#" data-url="{{ url('payslip/pdf/') }}/' + id +
                               '/' + datePicker +
                               '" data-size="md-pdf"  data-ajax-popup="true" class="btn btn-primary" data-title="{{ __('Employee Payslip') }}">' +
                               '{{ __('Payslip') }}' + '</a> ';
                       }
   
                       if (status == "UnPaid" && data != 0) {
                           clickToPaid = '<a href="{{ url('payslip/paysalary/') }}/' + id +
                               '/' + datePicker + '"  class="view-btn primary-bg btn-sm">' +
                               '{{ __('Click To Paid') }}' + '</a>  ';
                       }
   
                       if (data != 0) {
                           view =
                               '<a href="#" data-url="{{ url('payslip/showemployee/') }}/' +
                               payslip_id +
                               '"  data-ajax-popup="true" class="view-btn gray-bg" data-title="{{ __('View Employee Detail') }}">' +
                               '{{ __('View') }}' + '</a>';
                       }
   
                       if (data != 0 && status == "UnPaid") {
                           edit =
                               '<a href="#" data-url="{{ url('payslip/editemployee/') }}/' +
                               payslip_id +
                               '"  data-ajax-popup="true" class="view-btn blue-bg" data-title="{{ __('Edit Employee salary') }}">' +
                               '{{ __('Edit') }}' + '</a>';
                       }
   
                       var url = '{{ route('payslip.delete', ':id') }}';
                       url = url.replace(':id', payslip_id);
   
                       @if (\Auth::user()->type != 'employee')
                           if (data != 0) {
                               deleted = '<a href="#"  data-url="' + url +
                                   '" class="payslip_delete view-btn red-bg" >' +
                                   '{{ __('Delete') }}' + '</a>';
                           }
                       @endif
   
                       return view + payslip + clickToPaid + edit + deleted + form;
                   }
   
                   console.clear();
                   var tr = '';
                   if (data.length > 0) {
   
                       $.each(data, function(indexInArray, valueOfElement) {
                           var status =
                               '<div class="badge bg-danger p-2 px-3 rounded"><a href="#" class="text-white">' +
                               valueOfElement[6] + '</a></div>';
                           if (valueOfElement[6] == 'Paid') {
                               var status =
                                   '<div class="badge bg-success p-2 px-3 rounded"><a href="#" class="text-white">' +
                                   valueOfElement[6] + '</a></div>';
                           }
   
                           var id = valueOfElement[0];
                           var employee_id = valueOfElement[1];
                           var payslip_id = valueOfElement[7];
   
                           if (valueOfElement[7] != 0) {
                               var payslip =
                                   '<a href="#" data-url="{{ url('payslip/pdf/') }}/' +
                                   id +
                                   '/' + datePicker +
                                   '" data-size="lg"  data-ajax-popup="true" class=" btn-sm btn btn-warning" data-title="{{ __('Employee Payslip') }}">' +
                                   '{{ __('Payslip') }}' + '</a> ';
                           }
                           if (valueOfElement[6] == "UnPaid" && valueOfElement[7] != 0) {
                               var clickToPaid =
                                   '<a href="{{ url('payslip/paysalary/') }}/' + id +
                                   '/' + datePicker +
                                   '"  class="btn-sm btn btn-primary">' +
                                   '{{ __('Click To Paid') }}' + '</a>  ';
                           } else {
                               var clickToPaid = '';
                           }
   
                           if (valueOfElement[7] != 0 && valueOfElement[6] == "UnPaid") {
                               var edit =
                                   '<a href="#" data-url="{{ url('payslip/editemployee/') }}/' +
                                   payslip_id +
                                   '"  data-ajax-popup="true" class="btn-sm btn btn-info" data-title="{{ __('Edit Employee salary') }}">' +
                                   '{{ __('Edit') }}' + '</a>';
                           } else {
                               var edit = '';
                           }
   
                           var url = '{{ route('payslip.delete', ':id') }}';
                           url = url.replace(':id', payslip_id);
   
                           @if (\Auth::user()->type != 'employee')
                               if (valueOfElement[7] != 0) {
                                   var deleted = '<a href="#"  data-url="' + url +
                                       '" class="payslip_delete view-btn btn btn-danger ms-1 btn-sm"  >' +
                                       '{{ __('Delete') }}' + '</a>';
                               } else {
                                   var deleted = '';
                               }
                           @else
                               var deleted = '';
                           @endif
   
                           var url_employee = valueOfElement['url'];
   
                           tr +=
                               '<tr>' +
                               '<td> <a class="btn btn-outline-primary" href="' +
                               url_employee + '">' +
                               valueOfElement[1] + '</a></td> ' +
                               '<td>' + valueOfElement[2] + '</td> ' +
                               {{-- '<td>' + valueOfElement[3] + '</td>' + --}}
                               '<td>' + valueOfElement[4] + '</td>' +
                               '<td>' + valueOfElement[5] + '</td>' +
                               '<td>' + status + '</td>' +
   
                               '<td>' + payslip + clickToPaid + edit + deleted + '</td>' +
   
                               '</tr>';
                       });
                   } else {
                       var colspan = $('#pc-dt-render-column-cells thead tr th').length;
                       var tr = '<tr><td class="dataTables-empty" colspan="' + colspan +
                           '">{{ __('No entries found') }}</td></tr>';
                   }
   
                   $('#pc-dt-render-column-cells tbody').html(tr);
                   var table = document.querySelector("#pc-dt-render-column-cells");
                   var datatable = new simpleDatatables.DataTable(table);
               },
               error: function(data) {
   
               }
           });
       }
   
       $(document).on("change", ".month_date,.year_date", function() {
           callback();
       });
   
       //bulkpayment Click
       $(document).on("click", "#bulk_payment", function() {
   
           var month = $(".month_date").val();
           var year = $(".year_date").val();
           var datePicker = year + '_' + month;
   
       });
       $(document).on('click', '#bulk_payment',
           'a[data-ajax-popup="true"], button[data-ajax-popup="true"], div[data-ajax-popup="true"]',
           function() {
   
               var month = $(".month_date").val();
               var year = $(".year_date").val();
               var datePicker = year + '-' + month;
   
               var title = 'Bulk Payment';
               var size = 'md';
               var url = 'payslip/bulk_pay_create/' + datePicker;
   
               // return false;
   
               $("#commonModal .modal-title").html(title);
               $("#commonModal .modal-dialog").addClass('modal-' + size);
               $.ajax({
                   url: url,
                   success: function(data) {
                    if (data.length) {
                           $('#commonModal .body').html(data);
                           $("#commonModal").modal('show');
                           // common_bind();
                       } else {
                           show_toastr('error', 'Permission denied.');
                           $("#commonModal").modal('hide');
                       }
                   },
                   error: function(data) {
                       data = data.responseJSON;
                       show_toastr('error', data.error);
                   }
               });
           });
   
       $(document).on("click", ".payslip_delete", function() {
           var confirmation = confirm("are you sure you want to delete this payslip?");
           var url = $(this).data('url');
   
           if (confirmation) {
               $.ajax({
                   type: "GET",
                   url: url,
                   dataType: "JSON",
                   success: function(data) {
   
                       
                       show_toastr('success', 'Payslip Deleted Successfully', 'success');
   
                       setTimeout(function() {
                           location.reload();
                       }, 800)
                   },
               });
           }
       });
   });
</script>
@endpush