
    {{ Form::open(['url' => 'expense', 'method' => 'post']) }}
    <div class="modal-body">
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                {{ Form::label('account_id', __('Account'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>
                {{ Form::select('account_id', $accounts, null, ['class' => 'form-control select2', 'required' => 'required','placeholder' => __('Choose Account')]) }}
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('amount', __('Amount'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>
                {{ Form::number('amount', null, ['class' => 'form-control', 'required' => 'required','placeholder' => __('Amount')]) }}
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('date', __('Date'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>
                {{ Form::text('date', null, ['class' => 'form-control d_week current_date', 'required' => 'required','autocomplete' => 'off']) }}
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('expense_category_id', __('Category'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>
                {{ Form::select('expense_category_id', $expenseCategory, null, ['class' => 'form-control select2', 'required' => 'required','placeholder' => __('Choose a* Category')]) }}
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('payee_id', __('Payee'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>
                {{ Form::select('payee_id', $payees, null, ['class' => 'form-control select2','required' => 'required',]) }}
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('payment_type_id', __('Payment Method'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>
                {{ Form::select('payment_type_id', $paymentTypes, null, ['class' => 'form-control select2', 'required' => 'required','placeholder' => __('Choose Payment Method')]) }}
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group">
                {{ Form::label('referal_id', __('Ref#'), ['class' => 'col-form-label']) }}
                {{ Form::text('referal_id', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="col-md-12">
            <div class="form-group">
                {{ Form::label('description', __('Description'), ['class' => 'col-form-label']) }}
                {{ Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => __('Description'),'rows'=>'5']) }}
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <input type="button" value="Cancel" class="btn btn-light" data-bs-dismiss="modal">
    <input type="submit" value="{{ __('Create') }}" class="btn btn-primary">
</div>
{{ Form::close() }}

<script>
    $(document).ready(function() {
        var now = new Date();
        var month = (now.getMonth() + 1);
        var day = now.getDate();
        if (month < 10) month = "0" + month;
        if (day < 10) day = "0" + day;
        var today = now.getFullYear() + '-' + month + '-' + day;
        $('.current_date').val(today);
    });
</script>