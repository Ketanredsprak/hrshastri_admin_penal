{{ Form::open(['url' => 'termination', 'method' => 'post','novalidate']) }}

<div class="modal-body">

    <div class="row">

        <div class="form-group col-lg-6 col-md-6">

            {{ Form::label('employee_id', __('Employee'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

            {{ Form::select('employee_id', $employees, null, ['class' => 'form-control select2', 'required' => 'required']) }}

        </div>

        <div class="form-group col-lg-6 col-md-6">

            {{ Form::label('termination_type', __('Termination Type'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

            {{ Form::select('termination_type', $terminationtypes, null, ['class' => 'form-control select2', 'required' => 'required']) }}

        </div>

        <div class="form-group col-lg-6 col-md-6">

            {{ Form::label('notice_date', __('Notice Date'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

            {{ Form::text('notice_date', null, ['class' => 'form-control d_week current_date', 'autocomplete' => 'off' ,'required' => 'required']) }}

        </div>

        <div class="form-group col-lg-6 col-md-6">

            {{ Form::label('termination_date', __('Termination Date'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

            {{ Form::text('termination_date', null, ['class' => 'form-control d_week current_date', 'autocomplete' => 'off' ,'required' => 'required']) }}

        </div>

        <div class="form-group  col-lg-12">

            {{ Form::label('description', __('Description'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

            {{ Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => __('Enter Description'),'rows' => '3' ,'required' => 'required']) }}

        </div>

    </div>

</div>

<div class="modal-footer">

    <input type="button" value="Cancel" class="btn btn-light" data-bs-dismiss="modal">

    <input type="submit" value="{{ __('Create') }}" class="btn btn-primary">

</div>



{{ Form::close() }}



<script>

    $(document).ready(function() {

        var now = new Date();

        var month = (now.getMonth() + 1);

        var day = now.getDate();

        if (month < 10) month = "0" + month;

        if (day < 10) day = "0" + day;

        var today = now.getFullYear() + '-' + month + '-' + day;

        $('.current_date').val(today);

    });

</script>