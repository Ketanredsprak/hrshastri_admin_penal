@extends('layouts.admin')

@section('page-title')
    {{ __('Manage Holiday') }}
@endsection

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('home') }}">{{ __('Home') }}</a></li>
    <li class="breadcrumb-item">{{ __('Holidays List') }}</li>
@endsection

@section('action-button')
    <a href="{{ route('holidays.export') }}" class="btn btn-sm btn-primary" data-bs-toggle="tooltip"
        data-bs-original-title="{{ __('Export') }}">
        <i class="ti ti-file-export"></i>
    </a>

    <!-- <a href="#" data-url="{{ route('holidays.file.import') }}" data-ajax-popup="true" data-title="{{ __('Import Holiday CSV file') }}" data-bs-toggle="tooltip" title="" class="btn btn-sm btn-primary" data-bs-original-title="{{ __('Import') }}">
                                         <i class="ti ti-file-import"></i>
                                    </a> -->

    <a href="{{ route('holiday.calender') }}" class="btn btn-sm btn-primary" data-bs-toggle="tooltip"
        data-bs-original-title="{{ __('Calendar View') }}">
        <i class="ti ti-calendar"></i>
    </a>

    @can('Create Holiday')
        <a href="#" data-url="{{ route('holiday.create') }}" data-ajax-popup="true"
            data-title="{{ __('Create New Holiday') }}" data-bs-toggle="tooltip" title="" class="btn btn-sm btn-primary"
            data-bs-original-title="{{ __('Create') }}">
            <i class="ti ti-plus"></i>
        </a>
    @endcan
@endsection

@section('content')
    <div class="row">

        <div class="col-sm-12 col-lg-12 col-xl-12 col-md-12">
            <!-- <div class="multi-collapse mt-2 collapse" id="multiCollapseExample1" style=""> -->
            <div class="card">
                <div class="card-body">
                    {{ Form::open(['route' => ['holiday.index'], 'method' => 'get', 'id' => 'holiday_filter']) }}

                    <div class="row align-items-center">
                        <div class="col-sm-9">
                            <div class="row">
                                <div class="col-sm-6 col-lg-4">
                                    <div class="btn-box">

                                        {{ Form::label('start_date', __('Start Date'), ['class' => 'form-label']) }}
                                        {{ Form::date('start_date', $startDate, ['class' => 'month-btn form-control current_date', 'autocomplete' => 'off', 'max' => date('Y-m-d')]) }}

                                    </div>
                                </div>
                                <div class="col-sm-6 col-lg-4">
                                    <div class="btn-box">

                                        {{ Form::label('end_date', __('End Date'), ['class' => 'form-label']) }}
                                        {{ Form::date('end_date', $endDate, ['class' => 'month-btn form-control current_date', 'autocomplete' => 'off', 'min' => date('Y-m-d')]) }}

                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="col-sm-3 text-right pt-4">
                            <a href="#" class="btn btn-sm btn-primary"
                                onclick="document.getElementById('holiday_filter').submit(); return false;"
                                data-bs-toggle="tooltip" title="" data-bs-original-title="apply">
                                <span class="btn-inner--icon"><i class="ti ti-search"></i></span>
                            </a>
                            <a href="{{ route('holiday.index') }}" class="btn btn-sm btn-danger" data-bs-toggle="tooltip"
                                title="" data-bs-original-title="Reset">
                                <span class="btn-inner--icon"><i class="ti ti-refresh text-white-off "></i></span>
                            </a>
                        </div>
                    </div>







                    <!--<div class="d-flex align-items-center justify-content-end">
                                                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12 mx-2">
                                                                <div class="btn-box">

                                                                    {{ Form::label('start_date', __('Start Date'), ['class' => 'form-label']) }}
                                                                    {{ Form::date('start_date', isset($_GET['start_date']) ? $_GET['start_date'] : '', ['class' => 'month-btn form-control current_date', 'autocomplete' => 'off']) }}

                                                                </div>
                                                            </div>
                                                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12 mx-2">
                                                                <div class="btn-box">

                                                                    {{ Form::label('end_date', __('End Date'), ['class' => 'form-label']) }}
                                                                    {{ Form::date('end_date', isset($_GET['end_date']) ? $_GET['end_date'] : '', ['class' => 'month-btn form-control current_date', 'autocomplete' => 'off']) }}

                                                                </div>
                                                            </div>

                                                            <div class="col-auto float-end ms-2 mt-4">
                                                                <a href="#" class="btn btn-sm btn-primary"
                                                                    onclick="document.getElementById('holiday_filter').submit(); return false;"
                                                                    data-bs-toggle="tooltip" title="" data-bs-original-title="apply">
                                                                    <span class="btn-inner--icon"><i class="ti ti-search"></i></span>
                                                                </a>
                                                                <a href="{{ route('holiday.index') }}" class="btn btn-sm btn-danger" data-bs-toggle="tooltip"
                                                                    title="" data-bs-original-title="Reset">
                                                                    <span class="btn-inner--icon"><i class="ti ti-trash-off text-white-off "></i></span>
                                                                </a>
                                                            </div>

                                                        </div>-->
                    {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>


    <div class="col-xl-12">
        <div class="card">
            <div class="card-header card-body table-border-style">
                {{-- <h5></h5> --}}
                <div class="table-responsive">
                    <table class="table" id="pc-dt-simple">
                        <thead>
                            <tr>
                                <th>{{ __('Occasion') }}</th>
                                <th>{{ __('Branch') }}</th>
                                <th>{{ __('Start Date') }}</th>
                                <th>{{ __('End Date') }}</th>
                                @if (Gate::check('Edit Holiday') || Gate::check('Delete Holiday'))
                                    <th>Status</th>
                                    <th width="200px">{{ __('Action') }}</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($holidays as $holiday)
                                <tr>
                                    <td>{{ $holiday->occasion }}</td>
                                    <td>
                                        <?php
                                        
                                        $branchName = 'All';
                                        
                                        if ($holiday->branch_name != 0 && !empty($holiday->branch_name)) {
                                            $branch = DB::table('branches')
                                                ->where('id', $holiday->branch_name)
                                                ->first();
                                        
                                            $branchName = $branch->name;
                                        }
                                        
                                        ?>

                                        {{ $branchName }}
                                    </td>
                                    <td>{{ $holiday->start_date }}</td>
                                    <td>{{ $holiday->end_date }}</td>
                                    @if (Gate::check('Edit Holiday') || Gate::check('Delete Holiday'))
                                        @can('Delete Holiday')
                                            <td>
                                                @if ($holiday->status == 1)
                                                    <div class="action-btn bg-success ms-2">
                                                        {!! Form::open([
                                                            'method' => 'get',
                                                            'route' => ['inactive_holiday', $holiday->id],
                                                            'id' => 'delete-form-' . $holiday->id,
                                                        ]) !!}
                                                        <a href="#"
                                                            class="mx-3 btn btn-sm  align-items-center bs-pass-para"
                                                            data-bs-toggle="tooltip" title="InActive"
                                                            data-bs-original-title="InActive" aria-label="InActive"><i
                                                                class="ti ti-check text-white text-white"></i></a>
                                                        </form>
                                                    </div>
                                                @else
                                                    <div class="action-btn bg-danger ms-2">
                                                        {!! Form::open([
                                                            'method' => 'get',
                                                            'route' => ['active_holiday', $holiday->id],
                                                            'id' => 'delete-form-' . $holiday->id,
                                                        ]) !!}
                                                        <a href="#"
                                                            class="mx-3 btn btn-sm  align-items-center bs-pass-para"
                                                            data-bs-toggle="tooltip" title="Active"
                                                            data-bs-original-title="Active" aria-label="Active"><i
                                                                class="ti ti-minus text-white text-white"></i></a>
                                                        </form>
                                                    </div>
                                                @endif
                                            </td>
                                        @endcan
                                        <td class="Action">
                                            <span>
                                                @can('Edit Holiday')
                                                    <div class="action-btn bg-info ms-2">
                                                        <a href="#" class="mx-3 btn btn-sm  align-items-center"
                                                            data-url="{{ route('holiday.edit', $holiday->id) }}"
                                                            data-ajax-popup="true" data-size="md" data-bs-toggle="tooltip"
                                                            title="" data-title="{{ __('Edit Holiday') }}"
                                                            data-bs-original-title="{{ __('Edit') }}">
                                                            <i class="ti ti-pencil text-white"></i>
                                                        </a>
                                                    </div>
                                                @endcan

                                                @can('Delete Holiday')
                                                    <div class="action-btn bg-danger ms-2">
                                                        {!! Form::open([
                                                            'method' => 'DELETE',
                                                            'route' => ['holiday.destroy', $holiday->id],
                                                            'id' => 'delete-form-' . $holiday->id,
                                                        ]) !!}
                                                        <a href="#"
                                                            class="mx-3 btn btn-sm  align-items-center bs-pass-para"
                                                            data-bs-toggle="tooltip" title=""
                                                            data-bs-original-title="Delete" aria-label="Delete"><i
                                                                class="ti ti-trash text-white text-white"></i></a>
                                                        </form>
                                                    </div>
                                                @endcan
                                            </span>
                                        </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>
@endsection

@push('script-page')
    <script>
        $(document).ready(function() {
            // var now = new Date();
            // var month = (now.getMonth() + 1);
            // var day = now.getDate();
            // if (month < 10) month = "0" + month;
            // if (day < 10) day = "0" + day;
            // var today = now.getFullYear() + '-' + month + '-' + day;
            // $('.current_date').val(today);
        });
    </script>
@endpush
