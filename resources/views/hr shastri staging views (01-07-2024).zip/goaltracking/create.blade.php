{{ Form::open(['url' => 'goaltracking', 'method' => 'post']) }}

<div class="modal-body">

     <div class="row">

          <div class="col-md-6">

               <div class="form-group">

                    {{ Form::label('branch', __('Branch '), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

                    {{ Form::select('branch', $brances, null, ['class' => 'form-control select2']) }}

               </div>

          </div>

          <div class="col-md-6">

               <div class="form-group">

                    {{ Form::label('goal_type', __('Goal Type'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

                    {{ Form::select('goal_type', $goalTypes, null, ['class' => 'form-control select2']) }}

               </div>

          </div>

          <div class="col-md-6">

               <div class="form-group">

                    {{ Form::label('start_date', __('Start Date '), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

                    {{ Form::text('start_date', null, ['class' => 'form-control d_week current_date','autocomplete'=>'off' , 'required' => 'required']) }}

               </div>

          </div>

          <div class="col-md-6">

               <div class="form-group">

                    {{ Form::label('end_date', __('End Date '), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

                    {{ Form::text('end_date', null, ['class' => 'form-control d_week current_date','autocomplete'=>'off' , 'required' => 'required']) }}

               </div>

          </div>

          <div class="col-md-12">

               <div class="form-group">

                    {{ Form::label('subject', __('Subject '), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

                    {{ Form::text('subject', null, ['class' => 'form-control' ,'placeholder'=>'Enter subject' , 'required' => 'required']) }}

               </div>

          </div>

          <div class="col-md-12">

               <div class="form-group">

                    {{ Form::label('target_achievement', __('Target Achievement'), ['class' => 'col-form-label']) }}

                    {{ Form::text('target_achievement', null, ['class' => 'form-control' ,'placeholder'=>'Enter target achievement']) }}

               </div>

          </div>

          <div class="col-md-12">

               <div class="form-group">

                    {{ Form::label('description', __('Description'), ['class' => 'col-form-label']) }}

                    {{ Form::textarea('description', null, ['class' => 'form-control' ,'rows'=>'3' ,'placeholder'=>'Enter description']) }}

               </div>

          </div>

     </div>

</div>

<div class="modal-footer">

     <input type="button" value="Cancel" class="btn btn-light" data-bs-dismiss="modal">

     <input type="submit" value="{{ __('Create') }}" class="btn btn-primary">

</div>

{{ Form::close() }}



<script>
     $(document).ready(function() {

          var now = new Date();

          var month = (now.getMonth() + 1);

          var day = now.getDate();

          if (month < 10) month = "0" + month;

          if (day < 10) day = "0" + day;

          var today = now.getFullYear() + '-' + month + '-' + day;

          $('.current_date').val(today);

     });
</script>