{{ Form::open(['url' => 'applywfm_update_action','method' => 'post']) }}
<div class="modal-body">
    <div class="row">
        <div class="col-12">
            <table class="table modal-table" id="pc-dt-simple">
                <tr>
                    <th>{{ __('Satart Date') }}</th>
                    <td>{{ \Auth::user()->dateFormat($data->start_date) }}</td>
                </tr>
                <tr>
                    <th>{{ __('End Date') }}</th>
                    <td>{{ \Auth::user()->dateFormat($data->end_date) }}</td>
                </tr>
                <input type="hidden" value="{{ $data->id }}" name="leave_id">
            </table>
        </div>
    </div>
</div>
<div class="modal-footer">
    @if($data->status != 'Approved')
        <input type="submit" value="{{ __('Approved') }}" class="btn btn-success rounded" name="status">
    @endif
        <input type="submit" value="{{ __('Reject') }}" class="btn btn-danger rounded" name="status">
</div>
{{ Form::close() }}
