@php
    use App\Models\Utility;
    $users = \Auth::user();
    $currantLang = $users->currentLanguage();
    $languages = \App\Models\Utility::languages();
    $profile = \App\Models\Utility::get_file('uploads/avatar/');
    $data_branches = \App\Models\Branch::where('created_by', '=', \Auth::user()->creatorId())->get();

@endphp

<style>
    select#branch {
        width: 169px;
    }

    .text-left {
        text-align: left;
    }

    .text-center {
        text-align: center;
    }

    .text-right {
        text-align: right;
    }
</style>

@if (isset($setting['cust_theme_bg']) && $setting['cust_theme_bg'] == 'on')
    <header class="dash-header transprent-bg">
    @else
        <header class="dash-header">
@endif
{{-- <header class="dash-header  {{ isset($setting['is_sidebar_transperent']) && $setting['is_sidebar_transperent'] == 'on' ? 'transprent-bg' : '' }}"> --}}
{{-- <form action="" method="get"> --}}
<div class="header-wrapper">
    <div class="me-auto dash-mob-drp">
        <ul class="list-unstyled">
            <li class="dash-h-item mob-hamburger">
                <a href="#!" class="dash-head-link" id="mobile-collapse">
                    <div class="hamburger hamburger--arrowturn">
                        <div class="hamburger-box">
                            <div class="hamburger-inner"></div>
                        </div>
                    </div>
                </a>
            </li>



            <div class="row">
                <div class="col">
                    <?php /*?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?> ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    ?>
                    <li class="dropdown dash-h-item drp-company">
                        <a class="dash-head-link dropdown-toggle arrow-none me-0" data-bs-toggle="dropdown"
                            href="#" role="button" aria-haspopup="false" aria-expanded="false">
                            <span class="theme-avtar">
                                <img alt="#"
                                    src="{{ !empty($users->avatar) ? $profile . $users->avatar : $profile . '/avatar.png' }}"
                                    class="header-avtar" style="width: 100%; border-radius:50%">
                            </span>
                            <span class="hide-mob ms-2"> {{ Auth::user()->name }}
                                <i class="ti ti-chevron-down drp-arrow nocolor hide-mob"></i>
                        </a>
                        <div class="dropdown-menu dash-h-dropdown">
                            <a href="{{ route('profile') }}" class="dropdown-item">
                                <i class="ti ti-user"></i>
                                <span>{{ __('My Profile') }}</span>
                            </a>
                            <a href="{{ route('logout') }}" class="dropdown-item">
                                <i class="ti ti-power"></i>
                                <span>{{ __('Logout') }}</span>
                            </a>
                            {{-- <a href="{{ route('logout') }}" class="dropdown-item"
                                onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                <i class="ti ti-power"></i>
                                <span>{{ __('Logout') }}</span>
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf</form> --}}
                        </div>
                    </li><?php */ ?>
                </div>

            </div>






        </ul>
    </div>
    <div class="ms-auto">
        <ul class="list-unstyled">

            @php
                $unseenCounter = App\Models\ChMessage::where('to_id', Auth::user()->id)
                    ->where('seen', 0)
                    ->count();
            @endphp

            {{-- @if (Auth::user()->type != 'super admin')
                <li class="dash-h-item">
                    <a class="dash-head-link me-0" href="{{ url('/chats') }}">
                         <i class="ti ti-message-circle"></i>
                         <span class="bg-danger dash-h-badge message-counter custom_messanger_counter">{{ $unseenCounter }}
                              <span class="sr-only"></span>
                         </span>
                         </a>
                         </li>
                         @endif --}}

            {{-- unread messages --}}

            @php
                $unreadCounter = App\Models\ChMessage::where('to_id', Auth::user()->id)
                    ->where('seen', 0)
                    ->count();
            @endphp

            @if (\Auth::user()->type != 'super admin')
                <li class="dropdown dash-h-item drp-notification">
                    <a class="dash-head-link dropdown-toggle arrow-none me-0 " data-bs-toggle="dropdown" href="#"
                        role="button" aria-haspopup="false" aria-expanded="false" id="msg-btn">
                        {{-- <i class="ti ti-message-2"></i> --}}
                        <i class="fa fa-bell"></i>
                        {{-- <span
                            class="bg-danger dash-h-badge message-counter custom_messanger_counter">{{ $unreadCounter }}
                                   <span class="sr-only"></span>
                                   </span> --}}
                        <span class="bg-danger dash-h-badge message-counter custom_messanger_counter">
                            @if (!empty(bdaynotification()))
                                {{ bdaynotification() }}
                            @endif
                            <span class="sr-only"></span>
                        </span>
                    </a>
                    <div class="dropdown-menu dash-h-dropdown dropdown-menu-end">
                        <div class="noti-header">
                            <h5 class="m-0">{{ __('Messages') }}</h5>
                            {{-- <a href="#" class="dash-head-link mark_all_as_read_message">{{ __('Clear All') }}</a> --}}
                        </div>

                        <div class="noti-body dropdown-list-message-msg">
                            <div style="display: flex;">
                                {{-- <a href="#" class="show-listView"><i class="fas fa-arrow-left"></i></a> --}}

                                <div class="notifications-wrapper">
                                    <?php
                                    $employee = employeeBdayGet();
                                    ?>
                                    @if (!empty($employee))
                                        @foreach ($employee as $row)
                                            <a class="content" href="{{ redirectUrl($row) }}"
                                                data-id="{{ $row->id }}" id="notification-redirect-url">
                                                <div class="notification-item">
                                                    <h4>{{ $row->title }}</h4>
                                                    <span>{{ $row->details }}</span>
                                                </div>
                                            </a>
                                        @endforeach
                                    @endif
                                </div>
                                {{-- <div class="count-listOfContacts">
                                </div> --}}
                            </div>
                        </div>
                        {{-- <div class="noti-footer">
                            <div class="d-grid">
                                <a href="{{ route('chats') }}"
                                   class="btn dash-head-link justify-content-center text-primary mx-0">View all</a>
                              </div>
               </div> --}}
                    </div>
                </li>
            @endif

            @php
                $currantLang = basename(\App::getLocale());
            @endphp

            <li class="dropdown dash-h-item drp-language">
                <a class="dash-head-link dropdown-toggle arrow-none me-0 " data-bs-toggle="dropdown" href="#"
                    role="button" aria-haspopup="false" aria-expanded="false" id="dropdownLanguage">
                    <i class="ti ti-world nocolor"></i>
                    <span class="drp-text hide-mob">{{ Str::upper($currantLang) }}</span>
                    <i class="ti ti-chevron-down drp-arrow nocolor"></i>
                </a>
                <div class="dropdown-menu dash-h-dropdown dropdown-menu-end" aria-labelledby="dropdownLanguage">
                    @foreach (App\Models\Utility::languages() as $lang)
                        <a href="{{ route('change.language', $lang) }}"
                            class="dropdown-item {{ basename(App::getLocale()) == $lang ? 'text-danger' : '' }}">{{ Str::upper($lang) }}</a>
                    @endforeach
                    @if (\Auth::user()->type == 'super admin')
                        <div class="dropdown-divider m-0"></div>
                        <a href="{{ route('manage.language', [basename(App::getLocale())]) }}"
                            class="dropdown-item text-primary">{{ __('Manage Language') }}</a>
                    @endif
                </div>
            </li>

            @php
                $employee = App\Models\Employee::select('*', 'employee_profile as employee_profile_image')
                    ->where('user_id', \Auth::user()->id)
                    ->first();
            @endphp

            <li class="dropdown dash-h-item drp-company">
                <a class="dash-head-link dropdown-toggle arrow-none me-0" data-bs-toggle="dropdown" href="#"
                    role="button" aria-haspopup="false" aria-expanded="false">
                    <span class="theme-avtar">

                        @php

                            $imagePath = '';

                            if (Auth::user()->type == 'company') {
                                $imagePath = !empty($users->avatar)
                                    ? $profile . $users->avatar
                                    : $profile . 'avatar.png';
                            } else {
                                if (empty($employee->employee_profile)) {
                                    $imagePath = $profile . 'avatar.png';
                                } else {
                                    $imagePath = $employee->employee_profile_image;
                                }
                            }
                        @endphp

                        <img alt="#" src="{{ $imagePath }}" {{-- src="{{ !empty($users->avatar) ? $profile . $users->avatar : $profile . '/avatar.png' }}" --}} class="header-avtar"
                            style="width: 100%; border-radius:50%">
                    </span>
                    <span class="hide-mob ms-2"> {{ Auth::user()->name }}
                        <i class="ti ti-chevron-down drp-arrow nocolor hide-mob"></i>
                </a>
                <div class="dropdown-menu dash-h-dropdown">

                    @if (Auth::user()->type == 'company')
                        <a href="{{ route('profile') }}" class="dropdown-item">
                            <i class="ti ti-user"></i>
                            <span>{{ __('My Profile') }}</span>
                        </a>
                    @else
                        <a href="{{ route('employeeProfileShow', \Illuminate\Support\Facades\Crypt::encrypt($employee->id ?? 0)) }}"
                            class="dropdown-item">
                            <i class="ti ti-user"></i>
                            <span>{{ __('My Profile') }}</span>
                        </a>

                        <a href="{{ route('profile') }}" class="dropdown-item">
                            <i class="ti ti-user"></i>
                            <span>{{ __('Change Password') }}</span>
                        </a>
                    @endif


                    <a href="{{ route('logout') }}" class="dropdown-item">
                        <i class="ti ti-power"></i>
                        <span>{{ __('Logout') }}</span>
                    </a>
                    {{-- <a href="{{ route('logout') }}" class="dropdown-item"
                    onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                    <i class="ti ti-power"></i>
                    <span>{{ __('Logout') }}</span>
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                         @csrf</form> --}}
                </div>
            </li>

        </ul>
    </div>
</div>
</header>
@push('scripts')
    {{-- @include('Chatify::layouts.modals') --}}
    <script>
        $("#notification-redirect-url").click(function(e) {
            e.preventDefault();
            var url = $(this).attr('href');
            var id = $(this).data('id');
            $.ajax({
                type: "POST",
                url: "{{ route('notification.status') }}",
                data: {
                    id: id,
                },
                dataType: "json",
                success: function(response) {
                    if (response.status == '1') {
                        console.log(url)
                        window.location.href = url;
                    } else {
                        console.log('Notification redirection errror');
                    }
                }
            });

        });
        $('#msg-btn').click(function() {
            let contactsPage = 1;
            let contactsLoading = false;
            let noMoreContacts = false;
            $.ajax({
                url: url + "/getContacts",
                method: "GET",
                data: {
                    _token: "{{ csrf_token() }}",
                    page: contactsPage,
                    type: 'custom',
                },
                dataType: "JSON",
                success: (data) => {

                    if (contactsPage < 2) {
                        $(".count-listOfContacts").html(data.contacts);

                    } else {
                        $(".count-listOfContacts").append(data.contacts);
                    }
                    $('.count-listOfContacts').find('.messenger-list-item').each(function(e) {
                        $('.noti-body .activeStatus').remove()
                        $('.noti-body .avatar').remove()
                        $(this).find('span').remove()
                        $(this).find('p').addClass("d-inline")
                        // $(this).find('b').addClass('position-absolute')
                        // $(this).find('b').css({position: "absolute"});
                        $(this).find('b').css({
                            "position": "absolute",
                            "right": "50px"
                        });
                        $(this).find('tr').remove('td')

                    })
                },
                error: (error) => {
                    setContactsLoading(false);
                    console.error(error);
                },
            });
        })
    </script>
@endpush
