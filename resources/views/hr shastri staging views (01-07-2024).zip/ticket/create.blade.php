{{ Form::open(['url' => 'ticket', 'method' => 'post']) }}

<div class="modal-body">

    <div class="row">

        <div class="form-group">

            {{ Form::label('title', __('Subject'), ['class' => 'col-form-label']) }} <span class="text-danger"> * </span>

            {{ Form::text('title', null, ['class' => 'form-control', 'required' => 'required', 'placeholder' => __('Enter Ticket Subject')]) }}

        </div>

        @if (\Auth::user()->type == 'company')
            <div class="form-group">

                {{ Form::label('employee_id', __('Ticket for Employee'), ['class' => 'col-form-label']) }}

                {{ Form::select('employee_id', $employees, null, ['class' => 'form-control select2 employee_id', 'placeholder' => __('Select Employee')]) }}

            </div>
        @endif



        <div class="row">

            <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6">

                <div class="form-group">

                    {{ Form::label('priority', __('Priority'), ['class' => 'col-form-label']) }} <span
                        class="text-danger"> * </span>

                    <select name="priority" class="form-control select2" id="choices-multiple" required>

                        <option value="low">{{ __('Low') }}</option>

                        <option value="medium">{{ __('Medium') }}</option>

                        <option value="high">{{ __('High') }}</option>

                        <option value="critical">{{ __('critical') }}</option>

                    </select>

                </div>

            </div>

            <div class="col-md-6 col-sm-12 col-lg-6 col-xl-6" style="display: none;">

                <div class="form-group">

                    {{ Form::label('end_date', __('End Date'), ['class' => 'col-form-label']) }} <span
                        class="text-danger"> * </span>

                    {{ Form::text('end_date', null, ['class' => 'form-control d_week current_date', 'required' => 'required', 'autocomplete' => 'off']) }}

                </div>

            </div>

        </div>



        <div class="form-group">

            {{ Form::label('description', __('Description'), ['class' => 'col-form-label']) }}

            {{ Form::textarea('description', null, ['class' => 'form-control', 'placeholder' => __('Ticket Description'), 'rows' => '5']) }}

        </div>

    </div>

</div>

<div class="modal-footer">

    <input type="button" value="Cancel" class="btn btn-light" data-bs-dismiss="modal">

    <input type="submit" value="{{ __('Create') }}" class="btn  btn-primary">



</div>

{{ Form::close() }}



<script>
    $(document).ready(function() {

        var now = new Date();

        var month = (now.getMonth() + 1);

        var day = now.getDate();

        if (month < 10) month = "0" + month;

        if (day < 10) day = "0" + day;

        var today = now.getFullYear() + '-' + month + '-' + day;

        $('.current_date').val(today);

    });
</script>
