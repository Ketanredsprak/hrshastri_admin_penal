<table>
    <tbody>
        <tr>
            <td>Name </td>
            <td>Branch</td>
            <td>Designation</td>

            @foreach ($monthDates as $monthDateRow)
                @php
                    $checkData = $data->where('attendance_date', $monthDateRow);

                    $columnsCount = 0;
                    if ($checkData != null) {
                        if ($checkData->groupBY('employee_id')->max() != null) {
                            $columnsCount = $checkData->groupBY('employee_id')->max()->count();
                        }
                    }

                @endphp

                @if ($columnsCount > 0)
                    <td colspan="{{ $columnsCount * 2 + 1 }}" style="text-align: center;">{{ $monthDateRow }}</td>
                @else
                    <td colspan="3" style="text-align: center;">{{ $monthDateRow }}</td>
                @endif
            @endforeach
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td></td>

            @foreach ($monthDates as $monthDateRow)
                @php
                    $checkData = $data->where('attendance_date', $monthDateRow);

                    $columnsCount = 0;
                    if ($checkData != null) {
                        if ($checkData->groupBY('employee_id')->max() != null) {
                            $columnsCount = $checkData->groupBY('employee_id')->max()->count();
                        }
                    }
                @endphp

                @if ($columnsCount > 0)
                    @for ($i = 1; $i <= $columnsCount; $i++)
                        <td>In</td>
                        <td>Out</td>
                    @endfor
                @else
                    <td>In</td>
                    <td>Out</td>
                @endif
                <td>WH</td>
            @endforeach
        </tr>

        @foreach ($data->groupBy('employee_id') as $key => $row)
            @php
                $employeeData = getEmployeeDetails($key);
            @endphp
            <tr>
                <td style="border: 20px; border-color: black;">{{ $employeeData->name ?? '' }}</td>
                <td style="border: 20px; border-color: black;">{{ $employeeData->branch->name ?? '' }}</td>
                <td style="border: 20px; border-color: black;">{{ $employeeData->designation->name ?? '' }}
                </td>

                @foreach ($monthDates as $monthDateRow)
                    @php

                        $workingHours = 0;
                        $checkData = $data->where('attendance_date', $monthDateRow);

                        $columnsCount = 0;
                        if ($checkData != null) {
                            if ($checkData->groupBY('employee_id')->max() != null) {
                                $columnsCount = $checkData->groupBY('employee_id')->max()->count();
                            }
                        }
                    @endphp

                    @if ($columnsCount > 0)
                        @foreach ($checkData->where('employee_id', $key) as $childRow)
                            {{-- <td>{{ timeFormat($childRow->clock_in) }}</td>
                            <td>{{ timeFormat($childRow->clock_out) }}</td> --}}

                            <td>{{ $childRow->clock_in != '00:00:00' ? timeFormat($childRow->clock_in) : '' }}</td>
                            <td>{{ $childRow->clock_out != '00:00:00' ? timeFormat($childRow->clock_out) : '' }}</td>

                            @php

                                if ($childRow->clock_in != '00:00:00' && $childRow->clock_out != '00:00:00') {
                                    try {
                                        $from = new DateTime($childRow->clock_in);
                                        $to = new DateTime($childRow->clock_out);

                                        $diff = $from->diff($to);

                                        // Total working minutes
                                        $totalMinutes = $diff->i + $diff->h * 60 + $diff->days * 24 * 60;

                                        // Convert total minutes to hours with decimal representation
                                        $workingHours += $totalMinutes / 60;
                                    } catch (Exception | Throwable $th) {
                                        //     dd($th);
                                    }
                                }

                            @endphp
                        @endforeach

                        @for ($i = 1; $i <= $columnsCount - $checkData->where('employee_id', $key)->count(); $i++)
                            <td></td>
                            <td></td>
                        @endfor
                    @else
                        <td></td>
                        <td></td>
                    @endif

                    <td>{{ number_format($workingHours ?? 0, 2) }}</td>
                @endforeach

            </tr>
        @endforeach

    </tbody>
</table>
