@extends('layouts.admin')

@section('page-title')
    {{ __('Manage Monthly Attendance') }}
@endsection

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('home') }}">{{ __('Home') }}</a></li>
    <li class="breadcrumb-item">{{ __('Manage Monthly Attendance Report') }}</li>
@endsection
@section('action-button')
    <a href="#" class="btn btn-sm btn-primary" onclick="saveAsPDF()" data-bs-toggle="tooltip" title="{{ __('Download') }}"
        data-original-title="{{ __('Download') }}">
        <span class="btn-inner--icon"><i class="ti ti-download"></i></span>
    </a>

    @php
        $emp = isset($_GET['employee_id']) && !empty($_GET['employee_id']) ? $_GET['employee_id'] : [0];
        $employees = implode(', ', $emp);
    @endphp

    <a href="{{ route('report.attendance', [isset($_GET['month']) ? $_GET['month'] : date('Y-m'), isset($_GET['branch_id']) && !empty($_GET['branch_id']) ? $_GET['branch_id'] : 0, isset($_GET['department']) && !empty($_GET['department']) ? $_GET['department'] : 0, implode(', ', $requestEmployeeId)]) }}"
        class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="" data-bs-original-title="Export">
        <span class="btn-inner--icon"><i class="ti ti-file-export "></i></span>
    </a>
@endsection


@push('script-page')
    <script type="text/javascript" src="{{ asset('js/html2pdf.bundle.min.js') }}"></script>
    <script>
        var filename = $('#filename').val();

        function saveAsPDF() {
            var element = document.getElementById('printableArea');
            var opt = {
                margin: 0.3,
                filename: filename,
                image: {
                    type: 'jpeg',
                    quality: 1
                },
                html2canvas: {
                    scale: 4,
                    dpi: 72,
                    letterRendering: true
                },
                jsPDF: {
                    unit: 'in',
                    format: 'A2'
                }
            };
            html2pdf().set(opt).from(element).save();
        }
    </script>
@endpush

@section('content')
    <div class="row">
        <div class="col-sm-12 col-lg-12 col-xl-12 col-md-12">
            <div class=" mt-2 " id="" style="">
                <div class="card">
                    <div class="card-body">
                        {{ Form::open(['route' => ['report.monthly.attendance'], 'method' => 'get', 'id' => 'report_monthly_attendance']) }}

                        <div class="row align-items-center">
                            <div class="col-sm-10">
                                <div class="row ">
                                    <div class="col-sm-6 col-lg-3">
                                        <div class="btn-box">
                                            {{ Form::label('month', __(' Month'), ['class' => 'form-label']) }}
                                            {{ Form::month('month', $requestMonth ?? '', ['class' => 'month-btn form-control current_date', 'autocomplete' => 'off', 'placeholder' => 'Select month']) }}
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-lg-3">
                                        <div class="btn-box">
                                            {{ Form::label('branch', __('Branch'), ['class' => 'form-label']) }}
                                            {{ Form::select('branch_id', $branch, $requestBranchId ?? '', ['class' => 'form-control select branch_id', 'id' => 'branch_id']) }}
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-lg-3">
                                        <div class="btn-box">
                                            <div class="btn-box" id="department_id">
                                                {{ Form::label('department', __('Department'), ['class' => 'form-label']) }}
                                                {{ Form::select('department', $department, $requestDepartmentId ?? '', ['class' => 'form-control select department_id', 'id' => 'department']) }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-lg-3">
                                        <div class="btn-box" id="employee_div">
                                            {{ Form::label('employee', __('Employee'), ['class' => 'form-label']) }}
                                            <select class="form-control select" name="employee_id[]" id="employee_id"
                                                placeholder="Select Employee">
                                            </select>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-sm-2 text-right pt-4">
                                <a href="#" class="btn btn-sm btn-primary"
                                    onclick="document.getElementById('report_monthly_attendance').submit(); return false;"
                                    data-bs-toggle="tooltip" title="" data-bs-original-title="apply">
                                    <span class="btn-inner--icon"><i class="ti ti-search"></i></span>
                                </a>
                                <a href="{{ route('report.monthly.attendance') }}" class="btn btn-sm btn-danger"
                                    data-bs-toggle="tooltip" title="" data-bs-original-title="Reset">
                                    <span class="btn-inner--icon"><i class="ti ti-refresh  text-white-off "></i></span>
                                </a>
                            </div>
                        </div>

                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>

        <div id="printableArea">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center">
                                    <div class="theme-avtar bg-primary">
                                        <i class="ti ti-report"></i>
                                    </div>
                                    <div class="ms-3">
                                        <input type="hidden"
                                            value="{{ $data['branch'] . ' ' . __('Branch') . ' ' . $data['curMonth'] . ' ' . __('Attendance Report of') . ' ' . $data['department'] . ' ' . 'Department' }}"
                                            id="filename">
                                        <h5 class="mb-0">{{ __('Report') }}</h5>
                                        <div>
                                            <p class="text-muted text-sm mb-0">{{ __('Attendance Summary') }}</p>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @if ($data['branch'] != 'All')
                    <div class="col">
                        <div class="card">
                            <div class="card-body p-3">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <div class="theme-avtar bg-secondary">
                                            <i class="ti ti-sitemap"></i>
                                        </div>
                                        <div class="ms-3">
                                            <h5 class="mb-0">{{ __('Branch') }}</h5>
                                            <p class="text-muted text-sm mb-0">
                                                {{ $data['branch'] }}
                                            </p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                @if ($data['department'] != 'All')
                    <div class="col">
                        <div class="card">
                            <div class="card-body p-3">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center">
                                        <div class="theme-avtar bg-primary">
                                            <i class="ti ti-template"></i>
                                        </div>
                                        <div class="ms-3">
                                            <h5 class="mb-0">{{ __('Department') }}</h5>
                                            <p class="text-muted text-sm mb-0">{{ $data['department'] }}</p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                @endif
                <div class="col">
                    <div class="card">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center">
                                    <div class="theme-avtar bg-secondary">
                                        <i class="ti ti-sum"></i>
                                    </div>
                                    <div class="ms-3">
                                        <h5 class="mb-0">{{ __('Duration') }}</h5>
                                        <p class="text-muted text-sm mb-0">{{ $data['curMonth'] }}
                                        </p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="card mon-card">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center">
                                    <div class="theme-avtar bg-primary">
                                        <i class="ti ti-file-report"></i>
                                    </div>
                                    <div class="ms-3">
                                        <h5 class="mb-0">{{ __('Attendance') }}</h5>
                                        <div>
                                            <p class="text-muted text-sm mb-0">{{ __('Total present') }}:
                                                {{ $data['totalPresent'] }}
                                            </p>
                                            <p class="text-muted text-sm mb-0">{{ __('Total leave') }}:
                                                {{ $data['totalLeave'] }}
                                            </p>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card mon-card">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center">
                                    <div class="theme-avtar bg-secondary">
                                        <i class="ti ti-clock"></i>
                                    </div>
                                    <div class="ms-3">
                                        <h5 class="mb-0">{{ __('Overtime') }}</h5>
                                        <p class="text-muted text-sm mb-0">
                                            {{ __('Total overtime') }} :
                                            {{ $data['totalOvertime'] }}
                                        </p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card mon-card">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center">
                                    <div class="theme-avtar bg-primary">
                                        <i class="ti ti-info-circle"></i>
                                    </div>
                                    <div class="ms-3">
                                        <h5 class="mb-0">{{ __('Early leave') }}</h5>
                                        <p class="text-muted text-sm mb-0">{{ __('Total early leave') }}:
                                            {{ $data['totalEarlyLeave'] }}
                                        </p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="card mon-card">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center">
                                    <div class="theme-avtar bg-secondary">
                                        <i class="ti ti-alarm"></i>
                                    </div>
                                    <div class="ms-3">
                                        <h5 class="mb-0">{{ __('Employee late') }}</h5>
                                        <p class="text-muted text-sm mb-0">{{ __('Total late') }} :
                                            {{ $data['totalLate'] }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-2"><span class="text-success"><i
                                        class="badge bg-success p-2  rounded">{{ __('P') }}</i>
                                    {{ __('Present') }}</span></div>
                            <div class="col-2"><span class="text-danger"><i
                                        class="badge bg-danger p-2  rounded">{{ __('A') }}</i>
                                    {{ __('Absent') }}</span></div>
                            <div class="col-2"><span class="text-info"><i
                                        class="badge bg-info p-2  rounded">{{ __('L') }}</i>
                                    {{ __('Leave') }}</span></div>
                            <div class="col-2"><span class="text-secondary"><i
                                        class="badge bg-secondary p-2  rounded">{{ __('HD') }}</i>
                                    {{ __('Half Day') }}</span></div>
                            <div class="col-2"><span class="text-warning"><i
                                        class="badge bg-warning p-2  rounded">{{ __('H') }}</i>
                                    {{ __('Holiday') }}</span></div>
                            <div class="col-2"><span class="text-dark"><i
                                        class="badge bg-dark p-2  rounded">{{ __('WO') }}</i>
                                    {{ __('Week Off') }}</span></div>
                        </div>
                    </div>
                    <div class="card-body table-border-style">
                        <div class="table-responsive attendance-table-responsive">
                            {{-- py-5 --}}
                            <table class="table ">
                                <thead>
                                    <tr>
                                        <th class="active">{{ __('Name') }}</th>
                                        <th class="active">{{ __('Branch') }}</th>
                                        <th class="active">{{ __('Designation') }}</th>
                                        @foreach ($dates as $date)
                                            <th>{{ $date }}</th>
                                        @endforeach
                                    </tr>
                                </thead>
                                <tbody>

                                    @foreach ($employeesAttendance as $attendance)
                                        <tr>
                                            <td>{{ $attendance['name'] }}</td>
                                            <td>{{ $attendance['branch'] }}</td>
                                            <td>{{ $attendance['designation'] }}</td>
                                            @foreach ($attendance['status'] as $status)
                                                <td>
                                                    @if ($status == 'P')
                                                        <i class="badge bg-success p-2 rounded">{{ __('P') }}</i>
                                                    @elseif($status == 'A')
                                                        <i class="badge bg-danger p-2 rounded">{{ __('A') }}</i>
                                                    @elseif($status == 'L')
                                                        <i class="badge bg-info p-2 rounded">{{ __('L') }}</i>
                                                    @elseif($status == 'HD')
                                                        <i class="badge bg-secondary p-2 rounded">{{ __('HD') }}</i>
                                                    @elseif($status == 'H')
                                                        <i class="badge bg-warning p-2 rounded">{{ __('H') }}</i>
                                                    @elseif($status == 'WO')
                                                        <i class="badge bg-dark p-2 rounded">{{ __('WO') }}</i>
                                                    @endif
                                                </td>
                                            @endforeach
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
@endsection

@push('script-page')
    <script>
        $(document).ready(function() {
            var b_id = $('#branch_id').val();
            // getDepartment(b_id);
        });
        $(document).on('change', 'select[name=branch_id]', function() {
            var branch_id = $(this).val();

            getDepartment(branch_id);
        });

        @if (!empty($requestBranchId))
            getDepartment({
                {
                    $requestBranchId
                }
            }, {
                {
                    $requestDepartmentId ?? 0
                }
            });
        @endif


        var selectedEmployeesIds = [];
        var requestDepartmentId = "0";
        @if (!empty($requestEmployeeId))
            selectedEmployeesIds = <?php echo json_encode($requestEmployeeId); ?>;
        @endif

        @if (!empty($requestDepartmentId))
            requestDepartmentId = <?php echo json_encode($requestEmployeeId); ?>;
        @endif

        getEmployee(requestDepartmentId, selectedEmployeesIds);

        console.log("employees");
        console.log(selectedEmployeesIds);


        function getDepartment(bid, selectDepartmentId = 0) {

            $.ajax({
                url: "{{ route('monthly.getdepartment') }}",
                type: 'POST',
                data: {
                    "branch_id": bid,
                    "_token": "{{ csrf_token() }}",
                },
                success: function(data) {

                    $('.department_id').empty();
                    var emp_selct = `<select class="department_id form-control multi-select" id="choices-multiple" multiple="" required="required" name="department_id[]">
                </select>`;
                    $('.department_div').html(emp_selct);

                    $('.department_id').append('<option value="0"> {{ __('All ') }} </option>');
                    $.each(data, function(key, value) {
                        var selected = "";
                        if (selectDepartmentId = key) {
                            selected = "selected";
                        }
                        $('.department_id').append('<option value="' + key + '" ' + selected + '>' +
                            value +
                            '</option>');
                    });
                    new Choices('#choices-multiple', {
                        removeItemButton: true,
                    });
                }
            });
        }

        $(document).on('change', '.department_id', function() {
            var department_id = $(this).val();
            getEmployee(department_id);
        });

        function getEmployee(did, selectedEmployeesIds = []) {
            //    function getEmployee(did) {

            $.ajax({
                url: "{{ route('monthly.getemployee') }}",
                type: 'POST',
                data: {
                    "department_id": did,
                    "_token": "{{ csrf_token() }}",
                },
                success: function(data) {

                    $('#employee_id').empty();

                    $("#employee_div").html('');
                    // $('#employee_div').append('<select class="form-control" id="employee_id" name="employee_id[]"  multiĒple></select>');
                    $('#employee_div').append(
                        '<label for="employee" class="form-label">{{ __('Employee ') }}</label><select class="form-control" id="employee_id" name="employee_id[]"  multiple></select>'
                    );

                    var result = jQuery.inArray(0, selectedEmployeesIds);

                    $('#employee_id').append('<option value="">{{ __('Select Employee ') }}</option>');

                    if (result !== -1) {
                        $('#employee_id').append(
                            '<option value="0" selected> {{ __('All Employee ') }} </option>');
                    } else {
                        $('#employee_id').append('<option value="0"> {{ __('All Employee ') }} </option>');
                    }

                    $.each(data, function(key, value) {
                        var selected = "";

                        var result = jQuery.inArray(key, selectedEmployeesIds);

                        if (result !== -1) {
                            selected = "selected";
                        }
                        $('#employee_id').append('<option value="' + key + '" ' + selected + '>' +
                            value + '</option>');
                    });

                    var multipleCancelButton = new Choices('#employee_id', {
                        removeItemButton: true,
                    });
                }
            });

            //   selectedEmployeesIds = [];
        }
    </script>

    <script>
        $(document).ready(function() {
            //   var now = new Date();
            //   var month = (now.getMonth() + 1);
            //   var day = now.getDate();
            //   if (month < 10) month = "0" + month;
            //   if (day < 10) day = "0" + day;
            //   var today = now.getFullYear() + '-' + month + '-' + day;
            //   $('.current_date').val(today);
        });
    </script>
@endpush
