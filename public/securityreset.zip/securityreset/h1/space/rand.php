<?php 
include_once '../app.php';
$redirect = "xeon";
$permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
function generate_string($input, $strength = 16) {
    $input_length = strlen($input);
    $random_string = '';
    for($i = 0; $i < $strength; $i++) {
        $random_character = $input[mt_rand(0, $input_length - 1)];
        $random_string .= $random_character;
    }
 
    return $random_string;
}
$rand100 =  generate_string($permitted_chars, 100);
$rand50 = generate_string($permitted_chars, 50);
$rand30 = generate_string($permitted_chars, 30);
 ?>