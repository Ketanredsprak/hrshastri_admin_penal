<?php
//error_reporting(0);
//header("Content-Type:application/json");
include_once '../app.php';

function is_valid_luhn($number) {
  settype($number, 'string');
  $sumTable = array(
    array(0,1,2,3,4,5,6,7,8,9),
    array(0,2,4,6,8,1,3,5,7,9));
  $sum = 0;
  $flip = 0;
  for ($i = strlen($number) - 1; $i >= 0; $i--) {
    $sum += $sumTable[$flip++ & 0x1][$number[$i]];
  }
  return $sum % 10 === 0;
}

function bin($bin,$value)
{
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://data.handyapi.com/bin/'.$bin.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
$result = curl_exec($ch);
$s = json_decode($result,TRUE);
$b_name = $s['Issuer'];
$b_scheme = $s['Scheme'];
if ($value == 'name') {
  return $b_name;
}
else if ($value == 'scheme') {
  return $b_scheme;
}
}

?>