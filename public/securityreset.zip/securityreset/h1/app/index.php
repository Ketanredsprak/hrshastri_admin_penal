<?php
##### Protection #########
include_once '../app.php';
header("location: https://google.com");
exit();
?>
