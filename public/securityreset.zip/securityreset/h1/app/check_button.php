<?php
if (file_exists('button.txt')) {
    $button = file_get_contents('button.txt');
    unlink('button.txt'); // Remove the button file

    echo $button;
} else {
    echo 'none';
}
?>
