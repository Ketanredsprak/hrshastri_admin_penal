<?php 
date_default_timezone_set("Africa/Casablanca");
if(isset($_POST['time'])){
echo date("d-m-Y h:i:sa");
}
?>