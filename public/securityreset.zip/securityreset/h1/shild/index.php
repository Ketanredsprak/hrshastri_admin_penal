<?php
include '../app.php';
header("Location: https://google.com/");
exit();
?>
