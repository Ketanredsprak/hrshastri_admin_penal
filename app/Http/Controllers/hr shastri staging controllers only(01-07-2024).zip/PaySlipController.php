<?php

namespace App\Http\Controllers;

use App\Exports\EmployeesSalarySlipPreviewExcelFileDownload;
use App\Exports\PayslipExport;
use App\Models\Allowance;
use App\Models\Commission;
use App\Models\Employee;
use App\Models\Loan;
use App\Mail\InvoiceSend;
use App\Mail\PayslipSend;
use App\Models\AllowanceOption;
use App\Models\Commission_option;
use App\Models\DeductionOption;
use App\Models\Department;
use App\Models\Designation;
use App\Models\OtherPayment;
use App\Models\Overtime;
use App\Models\PaySlip;
use App\Models\SaturationDeduction;
use App\Models\Utility;
use App\Models\Leave;
use App\Models\LeaveType;
use App\Models\OtherPaymentotion;
use App\Models\PayslipType;
use App\Models\UserLeaveBalanceYear;
use Barryvdh\DomPDF\Facade\Pdf;
use DB;
use Dompdf\Dompdf;
use Dompdf\Options;
use Exception;
use Google\Service\Sheets\NumberFormat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use Throwable;

class PaySlipController extends Controller
{
     public function index(Request $request)
     {
          if ($request->has("debug"))
          {
               $formate_month_year = 2024 . '-' . 06;

               $employeeDetails = Employee::where("id", 578)->first();

               $basicSalary = $employeeDetails->salary;

               $companyWorkingDays = getCompanyWorkingDays();
               $companyWorkingDays = 31;

               $leaveDataRaw = Employee::paySlipLeaveDeduction($employeeDetails->id, $formate_month_year, false);
               $extraLeaveDays = $leaveDataRaw["extraLeaveDays"];
               $extraLeaveDaysTotalAmount = $leaveDataRaw["total"];

               // $employeeWorkingDays = abs($companyWorkingDays - $extraLeaveDays);
               // $employeeWorkingDays = 28;

               // $payableSalary = ($basicSalary / $companyWorkingDays * $employeeWorkingDays);

               // $extraData = [
               //      "companyWorkingDays" => $companyWorkingDays,
               //      "employeeWorkingDays" => $employeeWorkingDays,
               // ];

               // $allowancesDataRaw = Employee::payslipAllowanceEmployeeWise($employeeDetails->id, $extraData);
               // dd($allowancesDataRaw);
          }

          if (\Auth::user()->can('Manage Pay Slip') || \Auth::user()->type == 'employee')
          {
               $employees = Employee::where(
                    [
                         'created_by' => \Auth::user()->creatorId(),
                    ]
               )
                    ->first();

               $month = [
                    '01' => 'JAN',
                    '02' => 'FEB',
                    '03' => 'MAR',
                    '04' => 'APR',
                    '05' => 'MAY',
                    '06' => 'JUN',
                    '07' => 'JUL',
                    '08' => 'AUG',
                    '09' => 'SEP',
                    '10' => 'OCT',
                    '11' => 'NOV',
                    '12' => 'DEC',
               ];

               $year = [

                    '2022' => '2022',
                    '2023' => '2023',
                    '2024' => '2024',
                    '2025' => '2025',
                    '2026' => '2026',
                    '2027' => '2027',
                    '2028' => '2028',
                    '2029' => '2029',
                    '2030' => '2030',
                    '2031' => '2031',
                    '2032' => '2032',
               ];


               $employees = Employee::where(['created_by' => \Auth::user()->creatorId(),])->first();

               // $payslip  = PaySlip::where('employee_id', $employees->id)->where('salary_month', $month)->where('created_by', \Auth::user()->creatorId())->first();
               // $employee = Employee::find($payslip->employee_id);
               // $payslipDetail = Utility::employeePayslipDetail($employees->id, $payslip->play_slab_id, $payslip);

               return view('payslip.index', compact('employees', 'month', 'year'));
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function create()
     {
          //
     }

     public function store(Request $request)
     {
          $validator = Validator::make(
               $request->all(),
               [
                    'month' => 'required',
                    'year' => 'required',

               ]
          );

          if ($validator->fails())
          {
               $messages = $validator->getMessageBag();
               return redirect()->back()->with('error', $messages->first());
          }

          try
          {
               $month = $request->month;
               $year  = $request->year;

               $formate_month_year = $year . '-' . $month;
               $validatePaysilp = PaySlip::where('salary_month', '=', $formate_month_year)->where('created_by', Auth::user()->creatorId())->pluck('employee_id')->toArray();

               $payslip_employee   = Employee::where('created_by', Auth::user()->creatorId())->where('company_doj', '<=', date($year . '-' . $month . '-t'))->count();

               $searchEmployeeIds = [508];


               if ($payslip_employee > count($validatePaysilp))
               {
                    $employees = Employee::where('created_by', Auth::user()->creatorId())
                         ->where('company_doj', '<=', date($year . '-' . $month . '-t'))
                         // ->whereNotIn('id', $validatePaysilp)
                         ->where('employe_status', "Active")
                         ->whereIn("id", $searchEmployeeIds)
                         ->where("salary", ">", 0)
                         ->get();

                    // $employeesSalary = Employee::where('created_by', Auth::user()->creatorId())->where('salary', '<=', 0)
                    //      ->whereNotIn('id', $validatePaysilp)
                    //      // ->whereIn("id", $searchEmployeeIds)
                    //      ->first();

                    // if (!empty($employeesSalary))
                    // {
                    //      return redirect()->route('payslip.index')->with('error', __('Please set employee salary.'));
                    // }

                    $previewData = [];
                    foreach ($employees as $employee)
                    {
                         $employeeDetails = $employee;

                         // Set Pay Slip Data Start

                         DB::beginTransaction();

                         $paySlipData = [];

                         $logo = Utility::get_file('uploads/logo/');
                         $company_logo = Utility::get_company_logo_without_auth($employeeDetails->created_by);
                         $designation = Designation::find($employeeDetails->designation_id);
                         $departments = Department::find($employeeDetails->department_id);

                         $basicSalary = $employeeDetails->salary;

                         $companyWorkingDays = getCompanyWorkingDays();
                         // $companyWorkingDays = 31;

                         // Old leave deduction
                         // $leaveDataRaw = Employee::paySlipLeaveDeduction($employeeDetails->id, $formate_month_year, false);
                         // $extraLeaveDays = $leaveDataRaw["extraLeaveDays"];
                         // $extraLeaveDaysTotalAmount = $leaveDataRaw["total"];
                         // Old leave deduction

                         // new leave deduction
                         $leaveDataRaw = getLeavesDataforPaySlip($employeeDetails->id, $formate_month_year);
                         $extraLeaveDays = $leaveDataRaw["extraLeaveDays"];
                         $extraLeaveDaysTotalAmount = $leaveDataRaw["total"];

                         // dd($leaveDataRaw, $formate_month_year);
                         // new leave deduction


                         $employeeWorkingDays = abs($companyWorkingDays - $extraLeaveDays);
                         // $employeeWorkingDays = 28;

                         // 

                         $payableSalary = ($basicSalary / $companyWorkingDays * $employeeWorkingDays);

                         // dd(
                         //      [
                         //           "basic Salary" => $basicSalary,
                         //           "company Working Days" => $companyWorkingDays,
                         //           "employee Working Days" => $employeeWorkingDays,
                         //           "payable Salary" => $payableSalary,
                         //           "employee id" => $employeeDetails->id,
                         //      ]
                         // );

                         $extraData = [
                              "companyWorkingDays" => $companyWorkingDays,
                              "employeeWorkingDays" => $employeeWorkingDays,
                              "formate_month_year" => $formate_month_year,
                              "extraLeaveDaysTotalAmount" => $extraLeaveDaysTotalAmount,
                         ];

                         // company data
                         $paySlipData["companyLogo"] = $logo . '/' . isset($company_logo) && !empty($company_logo) ? $company_logo : 'logo-dark.png';
                         $paySlipData["companyName"] = Utility::getValByName('company_name');
                         $paySlipData["companyAddress"] = Utility::getValByName('company_address');
                         $paySlipData["companyCity"] = Utility::getValByName('company_city');
                         $paySlipData["companyState"] = Utility::getValByName('company_state');
                         $paySlipData["companyZipcode"] = Utility::getValByName('company_zipcode');
                         // company data

                         // employee data
                         // $paySlipData["employeeId"] = employeeIdFormat($employeeDetails->id);
                         $paySlipData["employeeId"] = $employeeDetails->employee_id;
                         $paySlipData["employeeName"] = $employeeDetails->name;
                         $paySlipData["employeeDesignation"] = ($designation->name ?? "");
                         $paySlipData["employeeDepartment"] = ($departments->name ?? "");

                         $paySlipData["employeeSalaryMonth"] = date("Y-m");
                         // $paySlipData["employeeBasicSalary"] = $basicSalary;
                         $paySlipData["employeeBasicSalary"] = $payableSalary;
                         // $paySlipData["employeeBasicSalaryPayable"] = $payableSalary;
                         // employee data

                         // Earnings
                         $allowancesTotal = 0;
                         $commissionTotal = 0;
                         $overtimeTotal = 0;
                         $otherPaymentsTotal = 0;
                         $totalEarnings = 0; // Total of all earnings

                         $allowancesDataRaw = Employee::payslipAllowanceEmployeeWise($employeeDetails->id, $extraData);
                         $allowancesTotal = $allowancesDataRaw["total"];
                         $allowancesData = $allowancesDataRaw["data"];
                         // dd($allowancesData);

                         $commissionDataRaw = Employee::paySlipCommissionEmployeeWise($employeeDetails->id, $extraData);
                         $commissionTotal = $commissionDataRaw["total"];
                         $commissionData = $commissionDataRaw["data"];

                         // overtime calculation is pending | need to discuss then calculate this
                         $overtimeDataRaw = Employee::paySlipOvertime($employeeDetails->id);
                         $overtimeTotal = $overtimeDataRaw["total"];
                         $overtimeData = $overtimeDataRaw["data"];

                         $otherPaymentsDataRaw = Employee::paySlipOtherPaymentEarningsEmployeeWise($employeeDetails->id, $extraData);
                         $otherPaymentsTotal = $otherPaymentsDataRaw["total"];
                         $otherPaymentsData = $otherPaymentsDataRaw["data"];

                         $totalEarnings = ($allowancesTotal + $commissionTotal + $overtimeTotal + $otherPaymentsTotal);

                         $paySlipData["earnings"] = [
                              "allowances" => [
                                   "total" => $allowancesTotal,
                                   "data" => $allowancesData
                              ],
                              "commission" => [
                                   "total" => $commissionTotal,
                                   "data" => $commissionData
                              ],

                              // calculation is pending | need to discuss then calculate this
                              "overtime" => [
                                   "total" => $overtimeTotal,
                                   "data" => $overtimeData
                              ],
                              "otherPayments" => [
                                   "total" => $otherPaymentsTotal,
                                   "data" => $otherPaymentsData
                              ],
                              // "totalEarnings" => $totalEarnings,
                         ];

                         $statutoryBonusDataRaw = Employee::statutoryBonusEarningsEmployeeWise($employeeDetails->id, $extraData);
                         $statutoryBonusTotal = $statutoryBonusDataRaw["total"];
                         $statutoryBonusData = $statutoryBonusDataRaw["data"];

                         $paySlipData["statutoryBonus"] = [
                              "total" => $statutoryBonusTotal,
                              "data" => $statutoryBonusData
                         ];

                         $paySlipData["totalEarnings"] = $totalEarnings;
                         // Earnings

                         // Deductions

                         $saturationTotal = 0;
                         $loanTotal = 0;
                         $leaveTotal = 0;
                         $totalDeductions = 0; // total of all deductions

                         $saturationDataRaw = Employee::paySlipSaturationDeductionEmployeeWise($employeeDetails->id, $extraData);
                         $saturationTotal = $saturationDataRaw["total"];
                         $saturationData = $saturationDataRaw["data"];

                         // Loan Deduction
                         $loanDataRaw = Employee::paySlipLoanDeduction($employeeDetails->id, $formate_month_year);
                         $loanTotal = $loanDataRaw["total"];
                         $loanData = $loanDataRaw["data"];

                         // Old Leave Deduction
                         // $leaveDataRaw = Employee::paySlipLeaveDeduction($employeeDetails->id, $formate_month_year, true);
                         // $leaveTotal = $leaveDataRaw["total"];
                         // $leaveData = $leaveDataRaw["data"];
                         // Old Leave Deduction

                         // New Leave Deduction
                         $leaveDataRaw = getLeavesDataforPaySlip($employeeDetails->id, $formate_month_year);
                         // dd($leaveDataRaw);
                         $leaveTotal = $leaveDataRaw["total"];
                         $leaveData = $leaveDataRaw["data"];
                         // New Leave Deduction

                         // Other Payment Deductions Calculation Like (Employee Provident Fund, Employees State Insurance, Employees Professional Tax)
                         $grossSalary = numberFormat(round($payableSalary + $totalEarnings));
                         // $grossSalary = $basicSalary;

                         // Employee Provident Fund of Employee
                         $providentFundEmployeeDeductionDataRaw = Employee::providentFundEmployeeDeduction($employeeDetails->id, $grossSalary, $extraData);
                         $providentFundEmployeeDeductionTotal = $providentFundEmployeeDeductionDataRaw["total"];
                         $providentFundEmployeeDeductionData = $providentFundEmployeeDeductionDataRaw["data"];
                         // Employee Provident Fund of Employee

                         // Employees State Insurance of Employee
                         $employeesStateInsuranceEmployeeDeductionDataRaw = Employee::employeesStateInsuranceEmployeeDeduction($employeeDetails->id, $grossSalary, $extraData);
                         $employeesStateInsuranceEmployeeDeductionTotal = $employeesStateInsuranceEmployeeDeductionDataRaw["total"];
                         $employeesStateInsuranceEmployeeDeductionData = $employeesStateInsuranceEmployeeDeductionDataRaw["data"];
                         // Employees State Insurance of Employee


                         // Employees Professional Tax
                         $employeeProfessionalTaxDeductionDataRaw = Employee::employeeProfessionalTaxDeduction($employeeDetails->id, $grossSalary, $extraData);
                         $employeeProfessionalTaxDeductionTotal = $employeeProfessionalTaxDeductionDataRaw["total"];
                         $employeeProfessionalTaxDeductionData = $employeeProfessionalTaxDeductionDataRaw["data"];
                         // Employees Professional Tax

                         $tdsDeductionDataRaw = Employee::tdsDeductionEmployeeWise($employeeDetails->id, $extraData);
                         $tadDeductionTotal = $tdsDeductionDataRaw["total"];
                         $tadDeductionData = $tdsDeductionDataRaw["data"];

                         // $totalDeductions = ($saturationTotal + $loanTotal + $leaveTotal + $providentFundEmployeeDeductionTotal + $employeesStateInsuranceEmployeeDeductionTotal + $employeeProfessionalTaxDeductionTotal + $tadDeductionTotal);
                         $totalDeductions = ($saturationTotal + $loanTotal + $providentFundEmployeeDeductionTotal + $employeesStateInsuranceEmployeeDeductionTotal + $employeeProfessionalTaxDeductionTotal + $tadDeductionTotal);

                         $paySlipData["deductions"] = [
                              "saturation" => [
                                   "total" => $saturationTotal,
                                   "data" => $saturationData
                              ],

                              // Loan Deduction
                              "loan" => [
                                   "total" => $loanTotal,
                                   "data" => $loanData
                              ],
                              // Loan Deduction

                              // Employee Provident Fund of Employee
                              "providentFundEmployeeDeduction" => [
                                   "total" => $providentFundEmployeeDeductionTotal,
                                   "data" => $providentFundEmployeeDeductionData
                              ],
                              // Employee Provident Fund of Employee

                              // Employees State Insurance of Employee
                              "employeesStateInsuranceEmployeeDeduction" => [
                                   "total" => $employeesStateInsuranceEmployeeDeductionTotal,
                                   "data" => $employeesStateInsuranceEmployeeDeductionData
                              ],
                              // Employees State Insurance of Employee

                              // Employees Professional Tax
                              "employeeProfessionalTaxDeduction" => [
                                   "total" => $employeeProfessionalTaxDeductionTotal,
                                   "data" => $employeeProfessionalTaxDeductionData
                              ],
                              // Employees Professional Tax


                              // Tax Deduction at Sourse
                              "tdsDeductions" => [
                                   "total" => $tadDeductionTotal,
                                   "data" => $tadDeductionData
                              ],
                              // Tax Deduction at Sourse
                         ];

                         // Leave Deduction
                         $paySlipData["leave"] = [
                              "total" => $leaveTotal,
                              "data" => $leaveData
                         ];
                         // Leave Deduction

                         $paySlipData["totalDeductions"] = $totalDeductions;


                         // Employee Provident Fund of Company
                         $providentFundEompanyDeductionDataRaw = Employee::providentFundCompanyDeduction($employeeDetails->id, $grossSalary, $extraData);
                         $providentFundCompanyDeductionTotal = $providentFundEompanyDeductionDataRaw["total"];
                         $providentFundCompanyDeductionData = $providentFundEompanyDeductionDataRaw["data"];

                         $paySlipData["providentFundCompanyDeduction"] = [
                              "total" => $providentFundCompanyDeductionTotal,
                              "data" => $providentFundCompanyDeductionData
                         ];

                         // Employee Provident Fund of Company

                         // Employees State Insurance of Employee
                         $employeesStateInsuranceCompanyDeductionDataRaw = Employee::employeesStateInsuranceCompanyDeduction($employeeDetails->id, $grossSalary, $extraData);
                         $employeesStateInsuranceCompanyDeductionTotal = $employeesStateInsuranceCompanyDeductionDataRaw["total"];
                         $employeesStateInsuranceCompanyDeductionData = $employeesStateInsuranceCompanyDeductionDataRaw["data"];

                         $paySlipData["employeesStateInsuranceCompanyDeduction"] = [
                              "total" => $employeesStateInsuranceCompanyDeductionTotal,
                              "data" => $employeesStateInsuranceCompanyDeductionData
                         ];

                         // Employees State Insurance of Employee


                         // Deductions


                         // $finalPayableSalary = numberFormat(round((($payableSalary + $totalEarnings + $statutoryBonusTotal) - ($totalDeductions + $providentFundCompanyDeductionTotal + $employeesStateInsuranceCompanyDeductionTotal))));
                         // $finalPayableSalary = numberFormat(round((($payableSalary + $totalEarnings + $statutoryBonusTotal) - ($totalDeductions))));
                         $finalPayableSalary = numberFormat(round((($payableSalary + $totalEarnings) - ($totalDeductions))));

                         $paySlipData["employeeNewPayableSalary"] = $finalPayableSalary;

                         // echo json_encode($paySlipData);
                         // exit;

                         // Set Pay Slip Data 

                         // ----------------------------------------------------------------------------

                         if ($request->has("download_payslip_preview"))
                         {
                              $paySlipData["employee_id"] = $employeeDetails->id;
                              $previewData[] = $paySlipData;
                         }
                         else
                         {
                              $payslipEmployee = new PaySlip();
                              $payslipEmployee->employee_id = $employee->id;
                              $payslipEmployee->play_slab_id = $employee->play_slab_id;
                              $payslipEmployee->status = 0;
                              $payslipEmployee->salary_month = $formate_month_year;

                              $payslipEmployee->basic_salary = $basicSalary;
                              $payslipEmployee->net_payble = $finalPayableSalary;

                              // For Old Structure
                              // Earnings
                              $payslipEmployee->allowance = null;
                              $payslipEmployee->commission = null;
                              $payslipEmployee->overtime = null;
                              $payslipEmployee->other_payment = null;
                              // Earnings

                              // Deductions
                              $payslipEmployee->saturation_deduction = null;
                              $payslipEmployee->loan = null;
                              $payslipEmployee->leave_deduction = 0;

                              $payslipEmployee->other_payments_deductions = null;
                              $payslipEmployee->other_payments_deductions_total_amount = 0;
                              // Deductions
                              // For Old Structure

                              // New Structure
                              $payslipEmployee->pay_slip_data = json_encode($paySlipData);
                              $payslipEmployee->pay_slip_data_type = 1;
                              // New Structure

                              $payslipEmployee->created_by = Auth::user()->creatorId();
                              $payslipEmployee->save();

                              DB::commit();
                         }
                    }

                    if ($request->has("download_payslip_preview"))
                    {
                         // Earnings List

                         $totalEarningsColumnsCount = 0;

                         // do not consider this in earnings column
                         // // add Statutory Bonus also
                         // $totalEarningsColumnsCount += 1; // for Statutory Bonus column

                         $allowancesList = AllowanceOption::where('created_by', '=', Auth::user()->creatorId())->orderBy('name', 'ASC')->get();
                         $commissionList = Commission_option::where('created_by', '=', Auth::user()->creatorId())->orderBy('name', 'ASC')->get();
                         $otherPaymentList = OtherPaymentotion::where('created_by', '=', Auth::user()->creatorId())->orderBy('name', 'ASC')->get();

                         $totalEarningsColumnsCount += $allowancesList->count();
                         $totalEarningsColumnsCount += $commissionList->count();
                         $totalEarningsColumnsCount += $otherPaymentList->count();

                         $totalEarningsColumnsCount += 1; // for total earnings total column
                         // Earnings List

                         //   ------------------------------------------------------------------------

                         // Deductions List

                         $totalDeductionsColumnsCount = 0;
                         $deductionList = DeductionOption::where('created_by', '=', Auth::user()->creatorId())->orderBy('name', 'ASC')->get();

                         $totalDeductionsColumnsCount += $deductionList->count();

                         // add below deductions also
                         // ____________________________________
                         // loan amount
                         // EPF | Employee Provident Fund Start
                         // ESI | Employees State Insurance Start
                         // EPT | Employees Professional Tax Start
                         // Tax Deducted at Source Start

                         $totalDeductionsColumnsCount += 1; /// for loan amount
                         $totalDeductionsColumnsCount += 1; /// for EPF | Employee Provident Fund Start column
                         $totalDeductionsColumnsCount += 1; /// for ESI | Employees State Insurance Start
                         $totalDeductionsColumnsCount += 1; /// for EPT | Employees Professional Tax Start
                         $totalDeductionsColumnsCount += 1; /// for Tax Deducted at Source Start

                         $totalDeductionsColumnsCount += 1; /// for total deductions column

                         // Deductions List

                         $pasasData = [
                              "earnings" => [
                                   "allowances" => $allowancesList,
                                   "commission" => $commissionList,
                                   "otherPayments" => $otherPaymentList,
                              ],
                              "totalEarningsColumnsCount" => $totalEarningsColumnsCount,
                              "deductions" => [
                                   $deductionList,
                              ],
                              "totalDeductionsColumnsCount" => $totalDeductionsColumnsCount,
                              "salarySlipData" => json_decode(json_encode($previewData)),
                         ];

                         // dd($pasasData);

                         return Excel::download(new EmployeesSalarySlipPreviewExcelFileDownload($pasasData), "Employees Salary Slip Preview of $formate_month_year.xlsx");
                    }

                    return redirect()->route('payslip.index')->with('success', __('Payslip successfully created.'));
               }
               else
               {
                    return redirect()->route('payslip.index')->with('error', __('Payslip Already created.'));
               }
          }
          catch (Exception | Throwable $ex)
          {
               // dd($ex);
               return redirect()->route('payslip.index')->with('error', showExceptionMessage($ex));
          }
     }

     public function destroy($id)
     {
          $payslip = PaySlip::find($id);
          $payslip->delete();
          return true;
     }

     public function showemployee($paySlip)
     {
          $payslip = PaySlip::find($paySlip);
          return view('payslip.show', compact('payslip'));
     }

     public function search_json(Request $request)
     {
          $formate_month_year = $request->datePicker;
          $employee_id = $request->employee_id ?? 0;

          $validatePaysilp = [];
          if ($employee_id > 0)
          {
               $validatePaysilp    = PaySlip::where('salary_month', '=', $formate_month_year)->where("employee_id", $employee_id)->where('created_by', Auth::user()->creatorId())->get()->toarray();
          }
          else
          {
               $validatePaysilp    = PaySlip::where('salary_month', '=', $formate_month_year)->where('created_by', Auth::user()->creatorId())->get()->toarray();
          }
          $data = [];
          if (empty($validatePaysilp))
          {
               $data = [];

               return;
          }
          else
          {

               if (Auth::user()->type == 'employee')
               {
                    $paylip_employee = PaySlip::where('pay_slips.status', 1)->select(
                         [
                              'employees.id',
                              'employees.employee_id',
                              'employees.name',
                              'employees.salary',
                              'payslip_types.name as payroll_type',
                              'pay_slips.basic_salary',

                              'pay_slips.net_payble',
                              'pay_slips.id as pay_slip_id',
                              'pay_slips.status',
                              'employees.user_id',
                         ]
                    )->leftjoin(
                         'employees',
                         function ($join) use ($formate_month_year)
                         {
                              $join->on('employees.id', '=', 'pay_slips.employee_id');
                              $join->on('pay_slips.salary_month', '=', \DB::raw("'" . $formate_month_year . "'"));
                              $join->leftjoin('payslip_types', 'payslip_types.id', '=', 'employees.salary_type');
                         }
                    )->where('employees.created_by', \Auth::user()->creatorId());

                    if ($employee_id > 0)
                    {
                         $paylip_employee = $paylip_employee->where("employees.id", $employee_id)->get();
                    }
                    else
                    {
                         $paylip_employee = $paylip_employee->get();
                    }
               }
               else
               {
                    $paylip_employee = PaySlip::select(
                         [
                              'employees.id',
                              'employees.employee_id',
                              'employees.name',
                              'employees.salary',
                              'payslip_types.name as payroll_type',
                              'pay_slips.basic_salary',
                              'pay_slips.net_payble',
                              'pay_slips.id as pay_slip_id',
                              'pay_slips.status',
                              'employees.user_id',
                         ]
                    )->leftjoin(
                         'employees',
                         function ($join) use ($formate_month_year)
                         {
                              $join->on('employees.id', '=', 'pay_slips.employee_id');
                              $join->on('pay_slips.salary_month', '=', \DB::raw("'" . $formate_month_year . "'"));
                              $join->leftjoin('payslip_types', 'payslip_types.id', '=', 'employees.salary_type');
                         }
                    )
                         ->where('employees.created_by', \Auth::user()->creatorId());

                    if ($employee_id > 0)
                    {
                         $paylip_employee = $paylip_employee->where("employees.id", $employee_id)->get();
                    }
                    else
                    {
                         $paylip_employee = $paylip_employee->get();
                    }
               }

               foreach ($paylip_employee as $employee)
               {
                    if (Auth::user()->type == 'employee')
                    {
                         $empdata = Employee::find($employee->id);

                         $playslapdata = PayslipType::find($empdata->play_slab_id);

                         if (Auth::user()->id == $employee->user_id)
                         {
                              $tmp   = [];
                              $tmp[] = $employee->id;
                              // $tmp[] = \Auth::user()->employeeIdFormat($employee->employee_id);
                              $tmp[] = $employee->employee_id;
                              $tmp[] = $employee->name;
                              // $tmp[] = $employee->payroll_type;
                              $tmp[] = !empty($playslapdata->name)  ?  $playslapdata->name : $employee->id;
                              // $tmp[] = $employee->pay_slip_id;
                              $tmp[] = !empty($employee->basic_salary) ? \Auth::user()->priceFormat($employee->salary) : '-';
                              $tmp[] = !empty($employee->net_payble) ? \Auth::user()->priceFormat($employee->net_payble) : '-';
                              if ($employee->status == 1)
                              {
                                   $tmp[] = 'Paid';
                              }
                              else
                              {
                                   $tmp[] = 'UnPaid';
                              }
                              $tmp[]  = !empty($employee->pay_slip_id) ? $employee->pay_slip_id : 0;
                              $tmp['url']  = route('employee.show', Crypt::encrypt($employee->id));
                              $data[] = $tmp;
                         }
                    }
                    else
                    {
                         $empdata = Employee::find($employee->id);
                         $playslapdata = PayslipType::find($empdata->play_slab_id);
                         $tmp   = [];
                         $tmp[] = $employee->id;
                         // $tmp[] = \Auth::user()->employeeIdFormat($employee->employee_id);
                         $tmp[] = $employee->employee_id;
                         $tmp[] = $employee->name;
                         // $tmp[] = $employee->payroll_type;
                         $tmp[] = !empty($playslapdata->name)  ?  $playslapdata->name : $employee->id;
                         $tmp[] = !empty($employee->basic_salary) ? \Auth::user()->priceFormat($employee->basic_salary) : '-';
                         $tmp[] = !empty($employee->net_payble) ? \Auth::user()->priceFormat($employee->net_payble) : '-';
                         if ($employee->status == 1)
                         {
                              $tmp[] = 'Paid';
                         }
                         else
                         {
                              $tmp[] = 'UnPaid';
                         }
                         $tmp[]  = !empty($employee->pay_slip_id) ? $employee->pay_slip_id : 0;
                         $tmp['url']  = route('employee.show', Crypt::encrypt($employee->id));
                         $data[] = $tmp;
                    }
               }
               return $data;
          }
     }

     public function paysalary($id, $date)
     {
          $employeePayslip = PaySlip::where('employee_id', '=', $id)->where('created_by', \Auth::user()->creatorId())->where('salary_month', '=', $date)->first();
          if (!empty($employeePayslip))
          {
               $employeePayslip->status = 1;
               $employeePayslip->save();
               return redirect()->route('payslip.index')->with('success', __('Payslip Payment successfully.'));
          }
          else
          {
               return redirect()->route('payslip.index')->with('error', __('Payslip Payment failed.'));
          }
     }
     public function bulk_pay_create($date)
     {
          $Employees       = PaySlip::where('salary_month', $date)->where('created_by', \Auth::user()->creatorId())->get();
          $unpaidEmployees = PaySlip::where('salary_month', $date)->where('created_by', \Auth::user()->creatorId())->where('status', '=', 0)->get();
          return view('payslip.bulkcreate', compact('Employees', 'unpaidEmployees', 'date'));
     }
     public function bulkpayment(Request $request, $date)
     {
          $unpaidEmployees = PaySlip::where('salary_month', $date)->where('created_by', \Auth::user()->creatorId())->where('status', '=', 0)->get();
          foreach ($unpaidEmployees as $employee)
          {
               $employee->status = 1;
               $employee->save();
          }
          return redirect()->route('payslip.index')->with('success', __('Payslip Bulk Payment successfully.'));
     }

     public function employeepayslip()
     {
          $employees = Employee::where(
               [
                    'user_id' => \Auth::user()->id,
               ]
          )->first();
          $payslip = PaySlip::where('employee_id', '=', $employees->id)->get();
          return view('payslip.employeepayslip', compact('payslip'));
     }

     public function pdf($id, $month)
     {
          $payslip  = PaySlip::where('employee_id', $id)->where('salary_month', $month)->where('created_by', \Auth::user()->creatorId())->first();

          if ($payslip != null)
          {
               $employee = Employee::find($payslip->employee_id);

               if ($payslip->pay_slip_data_type == 0)
               {
                    $payslipDetail = Utility::employeePayslipDetail($id, $payslip->play_slab_id, $payslip);
                    return view('payslip.new_pdf_salary_new', compact('payslip', 'employee', 'payslipDetail'));
               }
               else
               {
                    $user = Auth::user();
                    $leave_counts =  LeaveType::where('play_slab_id', $employee->play_slab_id)->where('created_by', Auth::user()->creatorId())->get();
                    $year = date('Y', strtotime($payslip->salary_month));
                    $month = date('m', strtotime($payslip->salary_month));

                    if (!empty($leave_counts))
                    {
                         foreach ($leave_counts as $row)
                         {
                              $userLeaveBalance = UserLeaveBalanceYear::where("leave_type_id", $row->id)->where("leaves_year", $year)->where("user_id", $employee->id)->sum("pending_leaves");
                              $row->used_leaved = $userLeaveBalance;

                              $applied_leaves = Leave::where('leave_type_id', $row->id)->where('employee_id', $employee->id)
                                   ->whereYear("start_date", $year)
                                   ->whereMonth("start_date", $month)
                                   ->where('status', 'Approved')
                                   ->sum('total_leave_days');
                              $row->applied_leaves = $applied_leaves;
                         }
                    }

                    $payslipDetail = json_decode($payslip->pay_slip_data);
                    return view('payslip.salary-slip', compact('payslip', 'employee', 'payslipDetail', 'leave_counts'));
               }
          }
          else
          {
               return redirect()->back()->with('error', __('Payslip not found.'));
          }
     }


     public function pdf_api($id, $month)
     {
          $payslip  = PaySlip::where('employee_id', $id)->where('salary_month', $month)->first();
          if ($payslip != null)
          {
               $employee = Employee::find($payslip->employee_id ?? 0);
               $payslipDetail = Utility::employeePayslipDetail($id, $payslip->play_slab_id, $payslip, $employee->created_by);

               $companyID = $employee->created_by;

               $pdf = Pdf::loadView('payslip.new_pdf_salary_new', compact('payslip', 'employee', 'payslipDetail', 'companyID'));
               return $pdf->download("Salary Slip of $month.pdf");
          }
          else
          {
               return ApiResponse(["status" => 0, "message" => "Payslip Not Found"]);
          }



          // $options = new Options();
          // $options->set('isHtml5ParserEnabled', true);
          // $options->set('isPhpEnabled', true);

          // // Set the font configuration
          // $options->set('defaultFont', 'DejaVuSans');

          // $dompdf = new Dompdf($options);

          // $data = [
          //      "payslip" => $payslip,
          //      "employee" => $employee,
          //      "payslipDetail" => $payslipDetail,
          //      "companyID" => $companyID,
          // ];

          // $view = view("payslip.new_pdf_salary_new", $data);

          // $dompdf->loadHtml($view->render());

          // $dompdf->setPaper('A4', 'portrait');

          // $dompdf->render();

          // return $dompdf->stream('example.pdf');


          // return view('payslip.new_pdf_salary_new', compact('payslip', 'employee', 'payslipDetail', 'companyID'));
     }
     public function send($id, $month)
     {
          $payslip  = PaySlip::where('employee_id', $id)->where('salary_month', $month)->where('created_by', \Auth::user()->creatorId())->first();
          $employee = Employee::find($payslip->employee_id);
          $payslip->name  = $employee->name;
          $payslip->email = $employee->email;
          $payslipId    = Crypt::encrypt($payslip->id);
          $payslip->url = route('payslip.payslipPdf', $payslipId);
          $setings = Utility::settings();
          if ($setings['new_payroll'] == 1)
          {
               $uArr = [
                    'payslip_email' => $payslip->email,
                    'name'  => $payslip->name,
                    'url' => $payslip->url,
                    'salary_month' => $payslip->salary_month,
               ];
               $resp = Utility::sendEmailTemplate('new_payroll', [$payslip->email], $uArr);
               // dd($resp);
               return redirect()->back()->with('success', __('Payslip successfully sent.')  . ((!empty($resp) && $resp['is_success'] == false && !empty($resp['error'])) ? '<br> <span class="text-danger">' . $resp['error'] . '</span>' : ''));
          }
          return redirect()->back()->with('success', __('Payslip successfully sent.'));
     }
     public function payslipPdf($id)
     {
          $payslipId = Crypt::decrypt($id);
          $payslip  = PaySlip::where('id', $payslipId)->where('created_by', \Auth::user()->creatorId())->first();
          $employee = Employee::find($payslip->employee_id);
          $payslipDetail = Utility::employeePayslipDetail($payslip->employee_id, $payslip->play_slab_id);
          return view('payslip.payslipPdf', compact('payslip', 'employee', 'payslipDetail'));
     }

     public function editEmployee($paySlip)
     {
          $payslip = PaySlip::find($paySlip);

          $payslipDetail = json_decode($payslip->pay_slip_data);

          $employee = Employee::find($payslip->employee_id);

          return view('payslip.salaryEdit', compact('payslip', 'payslipDetail', 'employee'));
     }

     public function updateEmployee(Request $request, $id)
     {
          if (isset($request->allowance) && !empty($request->allowance))
          {
               $allowances   = $request->allowance;
               $allowanceIds = $request->allowance_id;
               foreach ($allowances as $k => $allownace)
               {
                    $allowanceData         = Allowance::find($allowanceIds[$k]);
                    $allowanceData->amount = $allownace;
                    $allowanceData->save();
               }
          }
          if (isset($request->commission) && !empty($request->commission))
          {
               $commissions   = $request->commission;
               $commissionIds = $request->commission_id;
               foreach ($commissions as $k => $commission)
               {
                    $commissionData         = Commission::find($commissionIds[$k]);
                    $commissionData->amount = $commission;
                    $commissionData->save();
               }
          }
          if (isset($request->loan) && !empty($request->loan))
          {
               $loans   = $request->loan;
               $loanIds = $request->loan_id;
               foreach ($loans as $k => $loan)
               {
                    $loanData         = Loan::find($loanIds[$k]);
                    $loanData->amount = $loan;
                    $loanData->save();
               }
          }
          if (isset($request->saturation_deductions) && !empty($request->saturation_deductions))
          {
               $saturation_deductionss   = $request->saturation_deductions;
               $saturation_deductionsIds = $request->saturation_deductions_id;
               foreach ($saturation_deductionss as $k => $saturation_deductions)
               {
                    $saturation_deductionsData         = SaturationDeduction::find($saturation_deductionsIds[$k]);
                    $saturation_deductionsData->amount = $saturation_deductions;
                    $saturation_deductionsData->save();
               }
          }
          if (isset($request->other_payment) && !empty($request->other_payment))
          {
               $other_payments   = $request->other_payment;
               $other_paymentIds = $request->other_payment_id;
               foreach ($other_payments as $k => $other_payment)
               {
                    $other_paymentData         = OtherPayment::find($other_paymentIds[$k]);
                    $other_paymentData->amount = $other_payment;
                    $other_paymentData->save();
               }
          }
          if (isset($request->rate) && !empty($request->rate))
          {
               $rates   = $request->rate;
               $rateIds = $request->rate_id;
               $hourses = $request->hours;
               foreach ($rates as $k => $rate)
               {
                    $overtime        = Overtime::find($rateIds[$k]);
                    $overtime->rate  = $rate;
                    $overtime->hours = $hourses[$k];
                    $overtime->save();
               }
          }
          $payslipEmployee                       = PaySlip::find($request->payslip_id);
          $payslipEmployee->allowance            = Employee::allowance($payslipEmployee->employee_id);
          $payslipEmployee->commission           = Employee::commission($payslipEmployee->employee_id);
          $payslipEmployee->loan                 = Employee::loan($payslipEmployee->employee_id);
          $payslipEmployee->saturation_deduction = Employee::saturation_deduction($payslipEmployee->employee_id);
          $payslipEmployee->other_payment        = Employee::other_payment($payslipEmployee->employee_id);
          $payslipEmployee->overtime             = Employee::overtime($payslipEmployee->employee_id);
          $payslipEmployee->net_payble           = Employee::find($payslipEmployee->employee_id)->get_net_salary();
          $payslipEmployee->save();
          return redirect()->route('payslip.index')->with('success', __('Employee payroll successfully updated.'));
     }

     public function PayslipExport(Request $request)
     {
          $name = 'payslip_' . date('Y-m-d i:h:s');
          $data = \Excel::download(new PayslipExport($request), $name . '.xlsx');
          // ob_end_clean();
          return $data;
     }
}
