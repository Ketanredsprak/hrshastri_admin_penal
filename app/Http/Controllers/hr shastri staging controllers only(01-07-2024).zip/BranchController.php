<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\CityModel;
use App\Models\Employee;
use App\Models\Department;
use App\Models\Designation;
use App\Models\District;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class BranchController extends Controller
{

     public function getcities($id)
     {
          $cities = CityModel::where('districtid', $id)->get();
          return $cities;
     }
     public function getdistict($id)
     {
          $getdistict = District::where('state_id', $id)->get();
          return $getdistict;
     }
     public function index()
     {
          if (Auth::user()->can('Manage Branch'))
          {
               $branches = Branch::with('states', 'districts')->where('created_by', '=', Auth::user()->creatorId())->orderBy('id', 'DESC')->get();

               return view('branch.index', compact('branches'));
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function create()
     {
          if (Auth::user()->can('Create Branch'))
          {
               $state = State::get();
               return view('branch.create', compact('state'));
          }
          else
          {
               return response()->json(['error' => __('Permission denied.')], 401);
          }
     }

     public function store(Request $request)
     {
          if (Auth::user()->can('Create Branch'))
          {

               $geofencing_status = $request->has("geofencing_status") ? 1 : 0;
               $geofencingValidations = ['name' => 'required'];
               if ($geofencing_status == 1)
               {
                    $geofencingValidations = [
                         'name' => 'required',
                         "geofencing_radius" => "required",
                    ];
               }

               $validator = Validator::make(
                    $request->all(),
                    $geofencingValidations,
                    [
                         "name" => "Name  is required.",
                         "geofencing_radius" => "Geofencing Radius is required.",
                    ]
               );
               if ($validator->fails())
               {
                    $messages = $validator->getMessageBag();

                    return redirect()->back()->with('error', $messages->first());
               }

               // $state = State::where('state_title', $request->state_name)->first();
               // $district_name = District::where('districtid', $request->district_name)->first();


               DB::beginTransaction();
               $branch             = new Branch();
               $branch->name       = $request->name;
               $branch->country_name = $request->country_name;
               $branch->state_name    = $request->state_name;
               $branch->district_name = $request->district_name;
               $branch->city_name    = $request->city_name;
               $branch->zip_code    = $request->zip_code;
               $branch->address    = $request->address;
               $branch->created_by = Auth::user()->creatorId();

               $branch->geofencing_status = $geofencing_status;
               if ($geofencing_status == 1)
               {
                    $branch->geofencing_radius = $request->geofencing_radius ?? "";
               }

               $branch->save();
               DB::commit();

               return redirect()->route('branch.index')->with('success', __('Branch  successfully created.'));
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function show(Branch $branch)
     {
          return redirect()->route('branch.index');
     }

     public function edit(Branch $branch)
     {
          if (Auth::user()->can('Edit Branch'))
          {
               if ($branch->created_by == Auth::user()->creatorId())
               {
                    $state = State::get();
                    return view('branch.edit', compact('branch', 'state'));
               }
               else
               {
                    return response()->json(['error' => __('Permission denied.')], 401);
               }
          }
          else
          {
               return response()->json(['error' => __('Permission denied.')], 401);
          }
     }

     public function update(Request $request, Branch $branch)
     {
          if (Auth::user()->can('Edit Branch'))
          {
               if ($branch->created_by == Auth::user()->creatorId())
               {
                    $geofencing_status = $request->has("geofencing_status") ? 1 : 0;
                    $geofencingValidations = ['name' => 'required'];
                    if ($geofencing_status == 1)
                    {
                         $geofencingValidations = [
                              'name' => 'required',
                              "geofencing_radius" => "required",
                         ];
                    }

                    $validator = Validator::make(
                         $request->all(),
                         $geofencingValidations,
                         [
                              "name" => "Name  is required.",
                              "geofencing_radius" => "Geofencing Radius is required.",
                         ]
                    );
                    if ($validator->fails())
                    {
                         $messages = $validator->getMessageBag();

                         return redirect()->back()->with('error', $messages->first());
                    }

                    DB::beginTransaction();

                    // $state = State::where('state_id', $request->state_name)->first();
                    // $district_name = District::where('districtid', $request->district_name)->first();

                    $branch->name = $request->name;
                    $branch->country_name  = $request->country_name;
                    $branch->state_name    = $request->state_name;
                    $branch->district_name = $request->district_name;
                    $branch->city_name    = $request->city_name;
                    $branch->zip_code    = $request->zip_code;
                    $branch->address    = $request->address;

                    $branch->geofencing_status = $geofencing_status;
                    if ($geofencing_status == 1)
                    {
                         $branch->geofencing_radius = $request->geofencing_radius ?? "";
                    }

                    $branch->save();

                    Employee::where("branch_id", $branch->id)->update(["geofencing_status" => $branch->geofencing_status]);

                    DB::commit();

                    return redirect()->route('branch.index')->with('success', __('Branch successfully updated.'));
               }
               else
               {
                    return redirect()->back()->with('error', __('Permission denied.'));
               }
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function destroy(Branch $branch)
     {
          if (Auth::user()->can('Delete Branch'))
          {
               if ($branch->created_by == Auth::user()->creatorId())
               {
                    $employee     = Employee::where('branch_id', $branch->id)->get();
                    if (count($employee) == 0)
                    {
                         $department = Department::where('branch_id', $branch->id)->first();
                         if (!empty($department))
                         {
                              Designation::where('department_id', $department->branch_id)->delete();
                              $department->delete();
                         }
                         $branch->delete();
                    }
                    else
                    {
                         return redirect()->route('branch.index')->with('error', __('This branch has employees. Please remove the employee from this branch.'));
                    }

                    return redirect()->route('branch.index')->with('success', __('Branch successfully deleted.'));
               }
               else
               {
                    return redirect()->back()->with('error', __('Permission denied.'));
               }
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function getdepartment(Request $request)
     {

          if ($request->branch_id == 0)
          {
               $departments = Department::get()->pluck('name', 'id')->toArray();
          }
          else
          {
               $departments = Department::where('branch_id', $request->branch_id)->get()->pluck('name', 'id')->toArray();
          }

          return response()->json($departments);
     }

     public function getemployee(Request $request)
     {
          if (in_array('0', $request->department_id))
          {
               $employees = Employee::get()->pluck('name', 'id')->toArray();
          }
          else
          {
               $employees = Employee::whereIn('department_id', $request->department_id)->get()->pluck('name', 'id')->toArray();
          }

          return response()->json($employees);
     }


     public function getDistrictByStateName($stateName)
     {
          $stateId = State::where("state_title", $stateName)->first()->state_id ?? 0;
          $getdistict = District::where('state_id', $stateId)->get();
          return $getdistict;
     }

     public function getCityByDistrictName($districtName)
     {
          $districtId = District::where("district_title", $districtName)->first()->districtid ?? 0;
          $cities = CityModel::where('districtid', $districtId)->get();
          return $cities;
     }
}
