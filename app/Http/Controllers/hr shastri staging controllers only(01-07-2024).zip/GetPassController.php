<?php



namespace App\Http\Controllers;



use Exception;

use Throwable;

use App\Models\User;

use App\Models\GetPass;

use App\Models\Employee;

use Illuminate\Http\Request;

use App\Models\NotificationModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Models\EarlyLateCommingLeave;
use Carbon\Carbon;

class GetPassController extends Controller
{
     public function index()
     {
          if (Auth::user())
          {
               $employee = Employee::where('user_id', Auth::id())->first();
               $getpass   = GetPass::with('employee')->where('employee_id', ($employee->id ?? 0))->where('created_by', '=', Auth::user()->creatorId())->orderBy('id', 'DESC')->get();
          }

          return view('getpass.index', compact('getpass'));
     }

     public function getpass_request()
     {
          $getpass = 0;
          $employees   = Employee::where('created_by', Auth::user()->creatorId())->get();
          $getpass     = GetPass::with('employee')->whereIn('employee_id', selectedEmployee())->where('created_by', '=', Auth::user()->creatorId())->orderBy('id', 'DESC')->get();
          return view('getpass.getpass_request', compact('getpass'));
     }

     public function create()
     {
          $users = '';
          if (Auth::user()->type == 'employee')
          {
               $employees       = Employee::where('user_id', '=', Auth::user()->id)->get()->pluck('name', 'id');
               $employeesData   = Employee::where('user_id', '=', Auth::user()->id)->get()->first();
          }
          else
          {
               $employees       = Employee::where('created_by', '=', Auth::user()->creatorId())->get()->pluck('name', 'id', 'play_slab_id');
               $users           = User::where('type', '!=', 'employee')->where('created_by', '=', Auth::user()->creatorId())->get()->pluck('name', 'id',);
          }

          return view('getpass.create', compact('employees', 'users'));
     }

     public function store(Request $request)
     {
          try
          {
               DB::beginTransaction();
               $inTime = $request->in_time;
               $outTime = $request->out_time;
               $employeeId = '';

               $employee = Employee::where('user_id', '=', Auth::user()->id)->first();

               $data               = new GetPass();
               $data->name         = $request->leave_type_id;
               $data->employee_id  = $employee->id;
               $data->date         = $request->start_date;
               $data->in_time   = $inTime;
               $data->out_time  = $outTime;
               $data->resone    = $request->leave_reason;
               $data->veryfy_status    = 0;
               $data->status    = 0;
               $data->created_by   = Auth::user()->creatorId();
               $data->save();

               //notification Code
               $employee = Employee::where('user_id', '=', Auth::id())->first();
               $upUser = User::where('assign_employees', '!=', null)->where('created_by', '=', Auth::user()->creatorId())->select('assign_employees', 'id')->get();
               foreach ($upUser as $row)
               {
                    foreach (json_decode($row['assign_employees']) ?? [] as $key => $user)
                    {
                         if (!empty($user))
                         {
                              if ($user == $employee->id)
                              {
                                   $notification               = new NotificationModel();
                                   $notification->user_id      = $row->id;
                                   $notification->employee_id  = $employee->id;
                                   $notification->title        = "Gate pass applied by " . $employee->name . " ";
                                   $notification->details      = "Gate pass applied by " . $employee->name . " ";
                                   $notification->status       = 0;
                                   $notification->date         = Carbon::now();
                                   $notification->created_by   = $employee->created_by;
                                   $notification->redirect   = 'getpass';
                                   $notification->save();
                              }
                         }
                    }
               }
               //end notification
               DB::commit();
               return redirect()->route('getpass.index')->with('success', __('Gete pass successfully created.'));
          }
          catch (Exception $ex)
          {
               DB::rollBack();
               return redirect()->route('getpass.index')->with('error', $ex->getMessage());
          }
          catch (Throwable $ex)
          {
               DB::rollBack();
               return redirect()->route('getpass.index')->with('error', $ex->getMessage());
          }
     }

     public function show($id)
     {
          //
     }

     public function edit($id)
     {
          $data = GetPass::with('employee')->find($id);
          return view('getpass.edit', compact('data'));
     }

     public function update(Request $request, $id)
     {
          try
          {
               DB::beginTransaction();
               $inTime = $request->in_time;
               $outTime = $request->out_time;
               $employeeId = '';
               if (Auth::user()->type == 'company')
               {
                    $employeeId = $request->employee_id;
               }
               else
               {
                    $employeeId = Auth::id();
               }
               $data            = GetPass::find($id);
               $data->name      = $request->leave_type_id;
               // $data->employee_id = $employeeId;
               $data->date      = $request->start_date;
               $data->in_time   = $inTime;
               $data->out_time  = $outTime;
               $data->resone    = $request->leave_reason;
               $data->veryfy_status    = 0;
               $data->status    = 0;
               $data->created_by       = Auth::user()->creatorId();
               $data->save();

               if (Auth::user()->type == 'employee')
               {
                    $Employee = Employee::where('user_id', $employeeId)->first();
               }
               else
               {
                    $Employee = User::find(Auth::id());
               }

               //notification Code
               $employee = Employee::where('user_id', '=', Auth::id())->first();
               $upUser = User::where('assign_employees', '!=', null)->where('created_by', '=', Auth::user()->creatorId())->select('assign_employees', 'id')->get();

               foreach ($upUser as $row)
               {
                    foreach (json_decode($row['assign_employees']) ?? [] as $key => $user)
                    {
                         if (!empty($user))
                         {
                              if ($user == $employee->id)
                              {
                                   $notification               = new NotificationModel();
                                   $notification->user_id      = $row->id;
                                   $notification->employee_id  = $employee->id;
                                   $notification->title        = "Gate pass applied by  " . $employee->name . " ";
                                   $notification->details      = "Gate pass applied by  " . $employee->name . " ";
                                   $notification->status       = 0;
                                   $notification->date         = Carbon::now();
                                   $notification->created_by   = $employee->created_by;
                                   $notification->redirect   = 'getpass';
                                   $notification->save();
                              }
                         }
                    }
               }
               //end notification

               DB::commit();
               return redirect()->route('getpass.index')->with('success', __('Gete pass successfully updated.'));
          }
          catch (Exception $ex)
          {
               DB::rollBack();
               return redirect()->route('getpass.index')->with('error', $ex->getMessage());
          }
          catch (Throwable $ex)
          {
               DB::rollBack();
               return redirect()->route('getpass.index')->with('error', $ex->getMessage());
          }
     }

     public function destroy($id)
     {
          try
          {
               DB::beginTransaction();

               $data = GetPass::find($id);
               $data->delete();

               DB::commit();
               return redirect()->route('getpass.index')->with('success', __('Gete pass successfully created.'));
          }
          catch (Exception $ex)
          {
               DB::rollBack();
               return redirect()->route('getpass.index')->with('error', $ex->getMessage());
          }
          catch (Throwable $ex)
          {
               DB::rollBack();
               return redirect()->route('getpass.index')->with('error', $ex->getMessage());
          }
     }

     public function changeaction($id)
     {
          $data       = GetPass::with('employee')->find($id);
          return view('getpass.action', compact('data'));
     }

     public function changeactionupdate(request $request)
     {
          try
          {
               DB::beginTransaction();
               $data = GetPass::find($request->leave_id);
               $employee = Employee::where('id', $data->employee_id)->first();
               $upUser = User::where('assign_employees', '!=', null)->where('created_by', '=', Auth::user()->creatorId())->select('assign_employees', 'id')->get();
               if ($request->status == 'Approved')
               {
                    $data->status = 1;
               }
               else
               {
                    $data->status = 2;
               }
               $data->save();

               //notification Code
               foreach ($upUser as $row)
               {
                    foreach (json_decode($row['assign_employees']) ?? [] as $key => $user)
                    {
                         if (!empty($user))
                         {
                              if ($user == $employee->id)
                              {
                                   $notification   = new NotificationModel();
                                   if ($row->id != Auth::id())
                                   {
                                        $notification->user_id = $row->id;
                                        $notification->redirect     = 'getpass';
                                   }
                                   else
                                   {
                                        $notification->user_id      = $employee->user_id;
                                        $notification->redirect     = 'getpass_employee';
                                   }

                                   $status = ($request->status == "Reject" ? "Rejected" : $request->status);

                                   $notification->action_status = $status;
                                   $notification->employee_id  = $employee->id;
                                   $notification->title        = 'Gate pass request ' . $status . ' by ' . Auth::user()->name;
                                   $notification->details        = 'Gate pass request ' . $status . ' by ' . Auth::user()->name;
                                   // $notification->title        = $employee->name  . "Gate pass "  .  $status . ' : ' . User::find(auth::id())->name  .  " ";
                                   $notification->status       = 0;
                                   $notification->date         = Carbon::now();
                                   $notification->created_by   = $employee->created_by;
                                   $notification->save();
                              }
                         }
                    }
               }
               //end notification

               // Send Push Notification to App
               if (in_array($data->status, [1, 2]))
               {
                    $usersData = User::where("id", $employee->user_id)->where("device_token", "!=", NULL)->select("id", "device_type", "device_token")->get();

                    if (!$usersData->isEmpty())
                    {
                         $statusArray = [
                              "1" => "Approved",
                              "2" => "Rejected",
                         ];

                         $gatePassText = ($data->name == 1 ? __("Personal Work") : __("Office Work"));
                         $title = __("Your Gate Pass for $gatePassText has been " . $statusArray[$data->status]);
                         $body = __("Your Gate Pass for $gatePassText has been " . $statusArray[$data->status]);

                         $click_action = "gate_pass_status_changed";
                         $extraData = ["id" => $data->id];

                         sendpPushNotification($title, $body, $usersData, $click_action, $extraData);
                    }
               }
               // Send Push Notification to App

               DB::commit();
               return redirect()->route('getpass_request')->with('success', __('Gete pass status successfully updated.'));
          }
          catch (Exception $ex)
          {
               DB::rollBack();
               return redirect()->route('getpass.index')->with('error', $ex->getMessage());
          }
          catch (Throwable $ex)
          {
               DB::rollBack();
               return redirect()->route('getpass.index')->with('error', $ex->getMessage());
          }
     }
}
