<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;
use App\Models\Employee;
use App\Models\LeaveType;
use App\Models\User;
use App\Models\NotificationModel;
use App\Models\UserLeaveBalance;
use App\Models\UserLeaveBalanceYear;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Throwable;

class FireEmailUsingCronJobController extends Controller
{
     public function test_email()
     {
          $email = "viral@mailinator.com";
          $content = "Content writing is the process of creating and publishing written content for a variety of purposes, including marketing, education, and entertainment. Content writers must be able to research topics, write in a clear and concise style, and edit their work for grammar and spelling";

          Mail::send(
               ['html' => 'emails.demoMail'],
               array(
                    'content' => $content,
               ),
               function ($message) use ($email)
               {
                    $message->from(env('MAIL_USERNAME'), 'Employee Birthday');
                    $message->to($email)->subject("Employee Birthday");
               }
          );
          dd("success");
     }
     public function employeeBday()
     {

          $data = Employee::whereDay('dob', Carbon::now())->whereMonth('dob', Carbon::now())->get();

          foreach ($data as $row)
          {
               $email = $row->email;
               $companies = User::where('id', $row->created_by)->first();
               $content = "<h2>Employee Birthday</h2>";
               Mail::send(
                    ['html' => 'system_emails.employee_email_birthday'],
                    array(
                         'content' => $content,
                         'user'    => $row,
                         'companies' => $companies
                    ),
                    function ($message) use ($email)
                    {
                         $message->from(env('MAIL_USERNAME'), 'Employee Birthday');
                         $message->to($email)->subject("Employee Birthday");
                    }
               );
          }

          $datamployee = Employee::whereDay('dob', Carbon::now())->whereMonth('dob', Carbon::now())->get();

          if (!empty($datamployee))
          {
               foreach ($datamployee as $row)
               {
                    $companies = User::where('created_by', $row->created_by)->get();
                    foreach ($companies as $company)
                    {
                         $notification  = new NotificationModel();
                         $notification->user_id      = $company->id;
                         $notification->employee_id  = $row->id;
                         $notification->title        = "Happy BirthDay " . $row->name;
                         $notification->details      = "Happy BirthDay " . $row->name . " wish you all company";
                         $notification->status       = 0;
                         $notification->date         = Carbon::now();
                         $notification->created_by   = $row->created_by;
                         $notification->redirect   = 'employee birthday';
                         $notification->save();
                    }
               }
          }
     }

     public function employeeWorkAnyversary()
     {



          $data = Employee::whereDay('company_doj', Carbon::now())->whereMonth('company_doj', Carbon::now())->get();
          foreach ($data as $row)
          {
               $email = $row->email;
               $companies = User::where('id', $row->created_by)->first();
               $content = "<h2>Employee Anniversary</h2>";
               Mail::send(
                    ['html' => 'system_emails.employee_email_anniversary'],
                    array(
                         'content' => $content,
                         'user'    => $row,
                         'companies' => $companies
                    ),
                    function ($message) use ($email)
                    {
                         $message->from(env('MAIL_USERNAME'), 'Employee Anniversary');
                         $message->to($email)->subject("Employee Anniversary");
                    }
               );
          }



          $datamployee = Employee::whereDay('company_doj', Carbon::now())->whereMonth('company_doj', Carbon::now())->get();

          if (!empty($datamployee))
          {

               foreach ($datamployee as $row)
               {
                    $companies = User::where('created_by', $row->created_by)->get();
                    foreach ($companies as $company)
                    {
                         $notification  = new NotificationModel();
                         $notification->user_id      = $company->id;
                         $notification->employee_id  = $row->id;
                         $notification->title        = "Happy Work Anniversary " . $row->name;
                         $notification->details      = "Happy Work Anniversary " . $row->name . " wish you all company";
                         $notification->status       = 0;
                         $notification->date         = Carbon::now();
                         $notification->created_by   = $row->created_by;
                         $notification->redirect   = 'employee work anniversary';
                         $notification->save();
                    }
               }
          }
     }

     public function addMonthlyLeave(Request $request)
     {
          try
          {
               $data = Employee::where('employe_status', "Active")
                    // ->where("id", 365)
                    ->get();

               $leaveAddedCount = 0;
               foreach ($data as $employee)
               {
                    $probation_period_date = $employee->probation_period_date;
                    $confirm_probation_period = $employee->confirm_probation_period;

                    $addLeave = 0;
                    if (
                         date("Y-m-d") > date("Y-m-d", strtotime($probation_period_date)) &&
                         (empty($confirm_probation_period) || $confirm_probation_period == null)
                    )
                    {
                         $leaveTypes = LeaveType::where("play_slab_id", $employee->play_slab_id)->where('created_by', '=', $employee->created_by)->get();

                         foreach ($leaveTypes as $leaveType)
                         {
                              $addLeave = ($leaveType->days / 12);

                              // old
                              // UserLeaveBalance::where("leave_type_id", $data->leave_type_id)->where("user_id", $employee->id)->increment('pending_leaves', $addLeave);
                              // old


                              // Add Leave Balance
                              $userLeaveBalance = UserLeaveBalance::where([
                                   ["user_id", "=", $employee->id],
                                   ["leave_type_id", "=", $leaveType->id],
                              ])->first();

                              if (empty($userLeaveBalance))
                              {
                                   $userLeaveBalance = new UserLeaveBalance();

                                   $userLeaveBalance->user_id = $employee->id;
                                   $userLeaveBalance->leave_type_id = $leaveType->id;
                                   $userLeaveBalance->pending_leaves = $addLeave;
                                   $userLeaveBalance->created_by = $employee->created_by;
                              }
                              else
                              {
                                   $userLeaveBalance->pending_leaves = ($userLeaveBalance->pending_leaves + $addLeave);
                              }

                              $userLeaveBalance->save();
                              // Add Leave Balance

                              // Add Leave Balance Year
                              $currentYear = date('Y');
                              $userLeaveBalanceYear = UserLeaveBalanceYear::where([
                                   ["user_id", "=", $employee->id],
                                   ["leave_type_id", "=", $leaveType->id],
                                   ["leaves_year", "=", $currentYear],
                              ])->first();

                              if (empty($userLeaveBalanceYear))
                              {
                                   $userLeaveBalanceYear = new UserLeaveBalanceYear();

                                   $userLeaveBalanceYear->user_id = $employee->id;
                                   $userLeaveBalanceYear->leave_type_id = $leaveType->id;
                                   $userLeaveBalanceYear->pending_leaves = $addLeave;
                                   $userLeaveBalanceYear->created_by =  $employee->created_by;
                                   $userLeaveBalanceYear->leaves_year = $currentYear;
                              }
                              else
                              {
                                   $userLeaveBalanceYear->pending_leaves = ($userLeaveBalanceYear->pending_leaves + $addLeave);
                              }

                              $userLeaveBalanceYear->save();
                              // Add Leave Balance
                         }

                         Employee::where("id", $employee->id)->update(['confirm_probation_period' => 1]);
                         $leaveAddedCount++;
                    }

                    if (date("Y-m-d") == Carbon::now()->startOfMonth()->format("Y-m-d"))
                    {
                         $leaveTypes = LeaveType::where("play_slab_id", $employee->play_slab_id)->where('created_by', '=', $employee->created_by)->get();
                         foreach ($leaveTypes as $leaveType)
                         {
                              $addLeave = ($leaveType->days / 12);
                              // UserLeaveBalance::where("leave_type_id", $data->leave_type_id)->where("user_id", $employee->id)->increment('pending_leaves', $addLeave);

                              // Add Leave Balance
                              $userLeaveBalance = UserLeaveBalance::where([
                                   ["user_id", "=", $employee->id],
                                   ["leave_type_id", "=", $leaveType->id],
                              ])->first();

                              if (empty($userLeaveBalance))
                              {
                                   $userLeaveBalance = new UserLeaveBalance();

                                   $userLeaveBalance->user_id = $employee->id;
                                   $userLeaveBalance->leave_type_id = $leaveType->id;
                                   $userLeaveBalance->pending_leaves = $addLeave;
                                   $userLeaveBalance->created_by = $employee->created_by;
                              }
                              else
                              {
                                   $userLeaveBalance->pending_leaves = ($userLeaveBalance->pending_leaves + $addLeave);
                              }

                              $userLeaveBalance->save();
                              // Add Leave Balance

                              // Add Leave Balance Year
                              $currentYear = date('Y');
                              $userLeaveBalanceYear = UserLeaveBalanceYear::where([
                                   ["user_id", "=", $employee->id],
                                   ["leave_type_id", "=", $leaveType->id],
                                   ["leaves_year", "=", $currentYear],
                              ])->first();

                              if (empty($userLeaveBalanceYear))
                              {
                                   $userLeaveBalanceYear = new UserLeaveBalanceYear();

                                   $userLeaveBalanceYear->user_id = $employee->id;
                                   $userLeaveBalanceYear->leave_type_id = $leaveType->id;
                                   $userLeaveBalanceYear->pending_leaves = $addLeave;
                                   $userLeaveBalanceYear->created_by = $employee->created_by;
                                   $userLeaveBalanceYear->leaves_year = $currentYear;
                              }
                              else
                              {
                                   $userLeaveBalanceYear->pending_leaves = ($userLeaveBalanceYear->pending_leaves + $addLeave);
                              }

                              $userLeaveBalanceYear->save();
                              // Add Leave Balance

                              $leaveAddedCount++;
                         }
                    }
               }
               return "Total $leaveAddedCount Employees Leave Added.";
          }
          catch (Exception $th)
          {
               dd($th);
               return 0;
          }
          catch (Throwable $th)
          {
               dd($th);
               return 0;
          }
          return 1;
     }

     public function addMonthlyLeaveByEmployee(Request $request)
     {
          // try
          // {
          //      $email = $request->email ?? "";

          //      $leaveAddedCount = 0;

          //      $data = Employee::where('email', $email)->get();
          //      if (empty($data) || count($data) <= 0)
          //      {
          //           return "Employee Data Not Found.";
          //      }

          //      foreach ($data as $employee)
          //      {
          //           $probation_period_date = $employee->probation_period_date;
          //           $confirm_probation_period = $employee->confirm_probation_period;

          //           $addLeave = 0;

          //           if (
          //                date("Y-m-d") > date("Y-m-d", strtotime($probation_period_date)) &&
          //                empty($confirm_probation_period)
          //           )
          //           {
          //                $leaveTypes = LeaveType::where("play_slab_id", $employee->play_slab_id)->where('created_by', '=', $employee->created_by)->get();
          //                foreach ($leaveTypes as $leaveType)
          //                {
          //                     $addLeave = ($leaveType->days / 12);
          //                     UserLeaveBalance::where("leave_type_id", $data->leave_type_id)->where("user_id", $employee->id)->increment('pending_leaves', $addLeave);

          //                     $leaveAddedCount++;
          //                }

          //                Employee::where("id", $employee->id)->update(['confirm_probation_period' => 1]);
          //           }

          //           if (date("Y-m-d") == Carbon::now()->startOfMonth()->format("Y-m-d"))
          //           {
          //                $leaveTypes = LeaveType::where("play_slab_id", $employee->play_slab_id)->where('created_by', '=', $employee->created_by)->get();
          //                foreach ($leaveTypes as $leaveType)
          //                {
          //                     $addLeave = ($leaveType->days / 12);
          //                     UserLeaveBalance::where("leave_type_id", $data->leave_type_id)->where("user_id", $employee->id)->increment('pending_leaves', $addLeave);
          //                     $leaveAddedCount++;
          //                }
          //           }
          //      }
          //      return "Total $leaveAddedCount Employees Leave Added.";
          // }
          // catch (Exception $th)
          // {
          //      return 0;
          // }
          // catch (Throwable $th)
          // {
          //      return 0;
          // }
          // return 1;
     }
}
