<?php

namespace App\Http\Controllers;

use Exception;
use Throwable;
use Carbon\Carbon;
use App\Models\User;
use App\Models\Leave;
use App\Models\Branch;
use App\Models\Deposit;
use App\Models\Expense;
use App\Models\Holiday;
use App\Models\PaySlip;
use App\Models\Utility;
use App\Models\CityTier;
use App\Models\Employee;
use App\Models\CityModel;
use App\Models\LeaveType;
use App\Models\TimeSheet;
use App\Models\Department;
use App\Models\AccountList;
use App\Exports\LeaveExport;
use App\Models\MyClaimModel;
use App\Models\Designation;
use Illuminate\Http\Request;
use App\Exports\PayrollExport;
use App\Exports\TimesheetExport;
use App\Exports\LeaveReportExport;
use App\Models\AttendanceEmployee;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Exports\TimesheetReportExport;
use App\Exports\accountstatementExport;
use App\Exports\EmployeeAttendanceGeofencingExcelExport;
use App\Exports\MergedColumnsExport;
use App\Exports\MonthelyAttendanceReportExport;
use App\Models\UserLeaveBalanceYear;
use DateTime;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Maatwebsite\Excel\Facades\Excel;
use Symfony\Component\HttpFoundation\StreamedResponse;

class ReportController extends Controller
{
     public function incomeVsExpense(Request $request)
     {
          if (Auth::user()->can('Manage Report'))
          {
               $deposit = Deposit::where('created_by', Auth::user()->creatorId());

               $labels       = $data = [];
               $expenseCount = $incomeCount = 0;

               // dd($request->start_month, $request->end_month);

               if (!empty($request->start_month) && !empty($request->end_month))
               {
                    $start = strtotime(date("Y-m", strtotime($request->start_month)));
                    $end   = strtotime($request->end_month);

                    $currentdate = $start;
                    $month       = [];

                    // dd(strtotime($request->start_month), $start, $end, $currentdate);
                    while ($currentdate <= $end)
                    {
                         $month = date('m', $currentdate);
                         $year  = date('Y', $currentdate);

                         $depositFilter = Deposit::where('created_by', Auth::user()->creatorId())->whereMonth('date', $month)->whereYear('date', $year)->get();

                         $depositsTotal = 0;
                         foreach ($depositFilter as $deposit)
                         {
                              $depositsTotal += $deposit->amount;
                         }

                         $incomeData[] = $depositsTotal;
                         $incomeCount  += $depositsTotal;

                         $expenseFilter = Expense::where('created_by', Auth::user()->creatorId())->whereMonth('date', $month)->whereYear('date', $year)->get();
                         $expenseTotal  = 0;
                         foreach ($expenseFilter as $expense)
                         {
                              $expenseTotal += $expense->amount;
                         }
                         $expenseData[] = $expenseTotal;
                         $expenseCount  += $expenseTotal;

                         $labels[]    = date('M Y', $currentdate);
                         $currentdate = strtotime('+1 month', $currentdate);
                    }

                    $filter['startDateRange'] = date('M-Y', strtotime($request->start_month));
                    $filter['endDateRange']   = date('M-Y', strtotime($request->end_month));
               }
               else
               {
                    for ($i = 0; $i < 6; $i++)
                    {

                         $month = date('m', strtotime("-$i month"));
                         $year  = date('Y', strtotime("-$i month"));

                         $depositFilter = Deposit::where('created_by', Auth::user()->creatorId())->whereMonth('date', $month)->whereYear('date', $year)->get();

                         $depositTotal = 0;
                         foreach ($depositFilter as $deposit)
                         {
                              $depositTotal += $deposit->amount;
                         }

                         $incomeData[] = $depositTotal;
                         $incomeCount  += $depositTotal;

                         $expenseFilter = Expense::where('created_by', Auth::user()->creatorId())->whereMonth('date', $month)->whereYear('date', $year)->get();
                         $expenseTotal  = 0;
                         foreach ($expenseFilter as $expense)
                         {
                              $expenseTotal += $expense->amount;
                         }
                         $expenseData[] = $expenseTotal;
                         $expenseCount  += $expenseTotal;

                         $labels[] = date('M Y', strtotime("-$i month"));
                    }
                    $filter['startDateRange'] = date('M-Y');
                    $filter['endDateRange']   = date('M-Y', strtotime("-5 month"));
               }

               $incomeArr['name'] = __('Income');
               $incomeArr['data'] = $incomeData ?? [];

               $expenseArr['name'] = __('Expense');
               $expenseArr['data'] = $expenseData;

               $data[] = $incomeArr;
               $data[] = $expenseArr;

               return view('report.income_expense', compact('labels', 'data', 'incomeCount', 'expenseCount', 'filter'));
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function leave(Request $request)
     {
          if (Auth::user()->can('Manage Report'))
          {

               $branch = Branch::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
               $branch->prepend('All', '');

               $department = Department::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
               $department->prepend('All', '');

               $filterYear['branch']        = __('All');
               $filterYear['department']    = __('All');
               $filterYear['type']          = __('Monthly');

               $year = $request->year ?? date('Y');

               if (Auth::user()->type == 'company')
               {
                    $employees = Employee::where('created_by', Auth::user()->creatorId());
               }
               else
               {
                    $assign_employees = json_decode(Auth::user()->assign_employees) ?? [];
                    $employees = Employee::whereIn('id', $assign_employees)->where('created_by', Auth::user()->creatorId());
               }

               if (!empty($request->branch))
               {
                    $employees->where('branch_id', $request->branch);
                    $filterYear['branch'] = !empty(Branch::find($request->branch)) ? Branch::find($request->branch)->name : '';
               }

               if (!empty($request->department))
               {
                    $employees->where('department_id', $request->department);
                    $filterYear['department'] = !empty(Department::find($request->department)) ? Department::find($request->department)->name : '';
               }

               $leaveTypes = LeaveType::where('created_by', Auth::user()->creatorId())->get();

               $employees = $employees->get();

               $leaves = [];
               $totalApproved = $totalReject = $totalPending = 0;
               $totalLeaveBalance = 0;

               $yearsCount = 4;

               foreach ($employees as $employee)
               {
                    $employeeLeave['id']          = $employee->id;
                    $employeeLeave['employee_id'] = $employee->employee_id;
                    $employeeLeave['employee']    = $employee->name;
                    $employeeLeave['employee_id_cus']    = $employee->id;

                    $approved = Leave::where('employee_id', $employee->id)->where('status', 'Approved')->whereYear("created_at", $year)->sum('total_leave_days');
                    $reject   = Leave::where('employee_id', $employee->id)->where('status', 'Reject')->whereYear("created_at", $year)->sum('total_leave_days');
                    $pending  = Leave::where('employee_id', $employee->id)->where('status', 'Pending')->whereYear("created_at", $year)->sum('total_leave_days');

                    $leaveBalance = UserLeaveBalanceYear::where("leaves_year", $year)->where("user_id", $employee->id)->sum("pending_leaves");

                    $totalApproved += $approved;
                    $totalReject   += $reject;
                    $totalPending  += $pending;
                    $totalLeaveBalance  += $leaveBalance;

                    $employeeLeave['approved'] = $approved;
                    $employeeLeave['reject']   = $reject;
                    $employeeLeave['pending']  = $pending;
                    $employeeLeave['leaveBalance']  = $leaveBalance;

                    foreach ($leaveTypes as $leaveType)
                    {
                         // $leaveBalanceOfLeaveType = UserLeaveBalanceYear::where("leave_type_id", $leaveType->id)->where("leaves_year", $year)->where("user_id", $employee->id)->sum("pending_leaves") ?? 0;
                         $leaveBalanceOfLeaveType = Leave::where('employee_id', $employee->id)->where("leave_type_id", $leaveType->id)->where('status', 'Approved')->whereYear("created_at", $year)->sum('total_leave_days');

                         $employeeLeave[$leaveType->title] = $leaveBalanceOfLeaveType;
                    }

                    $leaves[] = $employeeLeave;
               }

               $filter['totalApproved'] = $totalApproved;
               $filter['totalReject']   = $totalReject;
               $filter['totalPending']  = $totalPending;
               $filter['totalLeaveBalance']  = $totalLeaveBalance;

               return view('report.leave', compact('department', 'branch', 'leaves', 'filterYear', 'filter', 'yearsCount', 'year', 'leaveTypes'));
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function employeeLeave(Request $request, $employee_id, $status, $type, $month, $year)
     {
          if (Auth::user()->can('Manage Report'))
          {
               $employee = Employee::find($employee_id);
               $leaveTypes = LeaveType::where('created_by', Auth::user()->creatorId())->where('play_slab_id', $employee->play_slab_id)->get();
               $leaves     = [];
               foreach ($leaveTypes as $leaveType)
               {
                    $leave        = new Leave();
                    $leave->title = $leaveType->title;
                    $totalLeave   = Leave::where('employee_id', $employee_id)->where('status', $status)->where('leave_type_id', $leaveType->id);
                    $totalLeave1  = Leave::where('employee_id', $employee_id)->get();
                    if ($type == 'yearly')
                    {
                         // $totalLeave->whereYear('applied_on', $year);
                         $totalLeave->whereYear('end_date', $year);
                    }
                    else
                    {
                         $m = date('m', strtotime($month));
                         $y = date('Y', strtotime($month));

                         // $totalLeave->whereMonth('applied_on', $m)->whereYear('applied_on', $y);
                         $totalLeave->whereMonth('end_date', $m)->whereYear('end_date', $y);
                    }
                    // $totalLeave = $totalLeave->count();
                    $totalLeave = $totalLeave->get();

                    $totalLeaveCount = [];
                    $daystotalLeaveCount = [];
                    foreach ($totalLeave as $leaveCount)
                    {
                         array_push($totalLeaveCount, $leaveCount->leave_day);
                         array_push($daystotalLeaveCount, $leaveCount->total_leave_days);
                    }

                    $leave->total = array_sum($totalLeaveCount);
                    $leave->Daystotal = array_sum($daystotalLeaveCount);
                    $leaves[]     = $leave;
               }

               $leaveData = Leave::where('employee_id', $employee_id)->where('status', $status);
               if ($type == 'yearly')
               {
                    // $leaveData->whereYear('applied_on', $year);
                    $leaveData->whereYear('end_date', $year);
               }
               else
               {
                    $m = date('m', strtotime($month));
                    $y = date('Y', strtotime($month));
                    // $leaveData->whereMonth('applied_on', $m)->whereYear('applied_on', $y);
                    $leaveData->whereMonth('end_date', $m)->whereYear('end_date', $y);
               }
               $leaveData = $leaveData->get();
               $leaveDataCount = $leaveData->sum('total_leave_days');
               return view('report.leaveShow', compact('leaves', 'leaveData', 'leaveDataCount'));
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function accountStatement(Request $request)
     {
          if (Auth::user()->can('Manage Report'))
          {
               $accountList = AccountList::where('created_by', Auth::user()->creatorId())->get()->pluck('account_name', 'id');
               $accountList->prepend('All', '');

               $filterYear['account'] = __('All');
               $filterYear['type']    = __('Income');


               if ($request->type == 'expense')
               {
                    $accountData = Expense::orderBy('id');
                    $accounts    = Expense::select('account_lists.id', 'account_lists.account_name')->leftjoin('account_lists', 'expenses.account_id', '=', 'account_lists.id')->groupBy('expenses.account_id')->selectRaw('sum(amount) as total');

                    if (!empty($request->start_month) && !empty($request->end_month))
                    {
                         $start = strtotime($request->start_month);
                         $end   = strtotime($request->end_month);
                    }
                    else
                    {
                         $start = strtotime(date('Y-m'));
                         $end   = strtotime(date('Y-m', strtotime("-5 month")));
                    }

                    $currentdate = $start;

                    while ($currentdate <= $end)
                    {
                         $data['month'] = date('m', $currentdate);
                         $data['year']  = date('Y', $currentdate);

                         $accountData->Orwhere(
                              function ($query) use ($data)
                              {
                                   $query->whereMonth('date', $data['month'])->whereYear('date', $data['year']);
                              }
                         );

                         $accounts->Orwhere(
                              function ($query) use ($data)
                              {
                                   $query->whereMonth('date', $data['month'])->whereYear('date', $data['year']);
                              }
                         );

                         $currentdate = strtotime('+1 month', $currentdate);
                    }

                    $filterYear['startDateRange'] = date('M-Y', $start);
                    $filterYear['endDateRange']   = date('M-Y', $end);

                    if (!empty($request->account))
                    {
                         $accountData->where('account_id', $request->account);
                         $accounts->where('account_lists.id', $request->account);

                         $filterYear['account'] = !empty(AccountList::find($request->account)) ? Department::find($request->account)->account_name : '';
                    }

                    $accounts->where('expenses.created_by', Auth::user()->creatorId());

                    $filterYear['type'] = __('Expense');
               }
               else
               {
                    $accountData = Deposit::orderBy('id');
                    $accounts    = Deposit::select('account_lists.id', 'account_lists.account_name')->leftjoin('account_lists', 'deposits.account_id', '=', 'account_lists.id')->groupBy('deposits.account_id')->selectRaw('sum(amount) as total');

                    if (!empty($request->start_month) && !empty($request->end_month))
                    {

                         $start = strtotime($request->start_month);
                         $end   = strtotime($request->end_month);
                    }
                    else
                    {
                         $start = strtotime(date('Y-m'));
                         $end   = strtotime(date('Y-m', strtotime("-5 month")));
                    }


                    $currentdate = $start;

                    while ($currentdate <= $end)
                    {
                         $data['month'] = date('m', $currentdate);
                         $data['year']  = date('Y', $currentdate);

                         $accountData->Orwhere(
                              function ($query) use ($data)
                              {
                                   $query->whereMonth('date', $data['month'])->whereYear('date', $data['year']);
                              }
                         );
                         $currentdate = strtotime('+1 month', $currentdate);

                         $accounts->Orwhere(
                              function ($query) use ($data)
                              {
                                   $query->whereMonth('date', $data['month'])->whereYear('date', $data['year']);
                              }
                         );
                         $currentdate = strtotime('+1 month', $currentdate);
                    }

                    $filterYear['startDateRange'] = date('M-Y', $start);
                    $filterYear['endDateRange']   = date('M-Y', $end);

                    if (!empty($request->account))
                    {
                         $accountData->where('account_id', $request->account);
                         $accounts->where('account_lists.id', $request->account);

                         $filterYear['account'] = !empty(AccountList::find($request->account)) ? Department::find($request->account)->account_name : '';
                    }
                    $accounts->where('deposits.created_by', Auth::user()->creatorId());
               }

               $accountData->where('created_by', Auth::user()->creatorId());
               $accountData = $accountData->get();

               $accounts = $accounts->get();


               return view('report.account_statement', compact('accountData', 'accountList', 'accounts', 'filterYear'));
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function payroll(Request $request)
     {

          if (Auth::user()->can('Manage Report'))
          {
               $branch = Branch::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
               $branch->prepend('All', '');

               $department = Department::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
               $department->prepend('All', '');

               $filterYear['branch']     = __('All');
               $filterYear['department'] = __('All');
               $filterYear['type']       = __('Monthly');

               $payslips = PaySlip::select('pay_slips.*', 'employees.name')->leftjoin('employees', 'pay_slips.employee_id', '=', 'employees.id')->where('pay_slips.created_by', Auth::user()->creatorId());


               if ($request->type == 'monthly' && !empty($request->month))
               {

                    $payslips->where('salary_month', $request->month);

                    $filterYear['dateYearRange'] = date('M-Y', strtotime($request->month));
                    $filterYear['type']          = __('Monthly');
               }
               elseif (!isset($request->type))
               {
                    $month = date('Y-m');

                    $payslips->where('salary_month', $month);

                    $filterYear['dateYearRange'] = date('M-Y', strtotime($month));
                    $filterYear['type']          = __('Monthly');
               }


               if ($request->type == 'yearly' && !empty($request->year))
               {
                    $startMonth = $request->year . '-01';
                    $endMonth   = $request->year . '-12';
                    $payslips->where('salary_month', '>=', $startMonth)->where('salary_month', '<=', $endMonth);

                    $filterYear['dateYearRange'] = $request->year;
                    $filterYear['type']          = __('Yearly');
               }


               if (!empty($request->branch))
               {
                    $payslips->where('employees.branch_id', $request->branch);

                    $filterYear['branch'] = !empty(Branch::find($request->branch)) ? Branch::find($request->branch)->name : '';
               }

               if (!empty($request->department))
               {
                    $payslips->where('employees.department_id', $request->department);

                    $filterYear['department'] = !empty(Department::find($request->department)) ? Department::find($request->department)->name : '';
               }

               $payslips = $payslips->get();

               $totalBasicSalary = $totalNetSalary = $totalAllowance = $totalCommision = $totalLoan = $totalSaturationDeduction = $totalOtherPayment = $totalOverTime = 0;

               foreach ($payslips as $payslip)
               {
                    $totalBasicSalary += $payslip->basic_salary;
                    $totalNetSalary   += $payslip->net_payble;

                    $allowances = json_decode($payslip->allowance);
                    foreach ($allowances as $allowance)
                    {
                         $totalAllowance += $allowance->amount;
                    }

                    $commisions = json_decode($payslip->commission);
                    foreach ($commisions as $commision)
                    {
                         $totalCommision += $commision->amount;
                    }

                    $loans = json_decode($payslip->loan);
                    foreach ($loans as $loan)
                    {
                         $totalLoan += $loan->amount;
                    }

                    $saturationDeductions = json_decode($payslip->saturation_deduction);
                    foreach ($saturationDeductions as $saturationDeduction)
                    {
                         $totalSaturationDeduction += $saturationDeduction->amount;
                    }

                    $otherPayments = json_decode($payslip->other_payment);
                    foreach ($otherPayments as $otherPayment)
                    {
                         $totalOtherPayment += $otherPayment->amount;
                    }

                    $overtimes = json_decode($payslip->overtime);
                    foreach ($overtimes as $overtime)
                    {
                         $days  = $overtime->number_of_days;
                         $hours = $overtime->hours;
                         $rate  = $overtime->rate;

                         $totalOverTime += ($rate * $hours) * $days;
                    }
               }

               $filterData['totalBasicSalary']         = $totalBasicSalary;
               $filterData['totalNetSalary']           = $totalNetSalary;
               $filterData['totalAllowance']           = $totalAllowance;
               $filterData['totalCommision']           = $totalCommision;
               $filterData['totalLoan']                = $totalLoan;
               $filterData['totalSaturationDeduction'] = $totalSaturationDeduction;
               $filterData['totalOtherPayment']        = $totalOtherPayment;
               $filterData['totalOverTime']            = $totalOverTime;


               $starting_year = date('Y', strtotime('-5 year'));
               $ending_year   = date('Y', strtotime('+5 year'));

               $filterYear['starting_year'] = $starting_year;
               $filterYear['ending_year']   = $ending_year;

               return view('report.payroll', compact('payslips', 'filterData', 'branch', 'department', 'filterYear'));
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }


     private function streamDownload(callable $callback, $fileName)
     {
          $response = new StreamedResponse($callback, 200, [
               'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
               'Content-Disposition' => 'attachment; filename="' . $fileName . '"',
          ]);

          return $response->send();
     }

     public function monthlyAttendance(Request $request)
     {


          // $employeeId = !empty(Auth::user()->employee) ? Auth::user()->employee->id : 0;
          // $employeeId = [156, 534];

          // $month = date('m');
          // $year = date('Y');

          // $data = AttendanceEmployee::select("*", "date as attendance_date")->whereIn('employee_id', $employeeId)->whereMonth('date', $month)->whereYear('date', $year)->get();

          // $pasasData = [
          //      "month" => $month,
          //      "year" => $year,
          //      "data" => $data,
          // ];



          // return Excel::download(new EmployeeAttendanceGeofencingExcelExport($pasasData), "employee-attendance-geofencing-excel-export($month-$year).xlsx");


          // ---------------------------------------------------------------------------


          if (Auth::user()->can('Manage Report'))
          {
               $setting = Utility::settings();

               $weefOffArray = [];
               if ($setting['company_office_week_off_monday'] == 'on')
               {
                    $weefOffArray[] = "Monday";
               }
               if ($setting['company_office_week_off_tuesday'] == 'on')
               {
                    $weefOffArray[] = "Tuesday";
               }
               if ($setting['company_office_week_off_wednesday'] == 'on')
               {
                    $weefOffArray[] = "Wednesday";
               }
               if ($setting['company_office_week_off_thusday'] == 'on')
               {
                    $weefOffArray[] = "Thursday";
               }
               if ($setting['company_office_week_off_friday'] == 'on')
               {
                    $weefOffArray[] = "Friday";
               }
               if ($setting['company_office_week_off_saturday'] == 'on')
               {
                    $weefOffArray[] = "Saturday";
               }
               if ($setting['company_office_week_off_sunday'] == 'on')
               {
                    $weefOffArray[] = "Sunday";
               }
               $branch = Branch::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
               $branch->prepend('All', '');

               $department = Department::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
               $department->prepend('All', '');

               $data['branch']     = __('All');
               $data['department'] = __('All');

               $employees = Employee::with('designation')->select('id', 'name', 'designation_id', 'branch_id', 'is_custom_weekoffs', 'weekoffs_data');
               if (!empty($request->employee_id) && $request->employee_id[0] != 0)
               {
                    $employees->whereIn('id', $request->employee_id);
               }

               if (Auth::user()->type == 'company')
               {
                    $employees = $employees->where('created_by', Auth::user()->creatorId());
               }
               else
               {
                    $assign_employees = json_decode(Auth::user()->assign_employees) ?? [];
                    $employees = $employees->whereIn('id', $assign_employees)->where('created_by', Auth::user()->creatorId());
               }

               if (!empty($request->branch))
               {
                    $employees->where('branch_id', $request->branch);
                    $data['branch'] = !empty(Branch::find($request->branch)) ? Branch::find($request->branch)->name : '';
               }

               if (!empty($request->department))
               {
                    $employees->where('department_id', $request->department);
                    $data['department'] = !empty(Department::find($request->department)) ? Department::find($request->department)->name : '';
               }

               if (!empty($request->employees))
               {
                    $employees->where('employee_id', $request->employees);
                    $data['employees'] = !empty(Employee::find($request->employees)) ? Employee::find($request->employees)->name : '';
               }

               $employees = $employees->get();

               $month = "";
               if (!empty($request->month))
               {
                    $currentdate = strtotime($request->month);
                    $month       = date('m', $currentdate);
                    $year        = date('Y', $currentdate);
                    $curMonth    = date('M-Y', strtotime($request->month));
                    $currentMonth = $month . '-' . $year;
               }
               else
               {
                    $month    = date('m');
                    $year     = date('Y');
                    $curMonth = date('M-Y', strtotime($year . '-' . $month));
                    $currentMonth = $month . '-' . $year;
               }

               $user = User::find(Auth::user()->creatorId());

               $num_of_days = date('t', mktime(0, 0, 0, $month, 1, $year));
               for ($i = 1; $i <= $num_of_days; $i++)
               {
                    $dates[] = str_pad($i, 2, '0', STR_PAD_LEFT);
               }

               $employeesAttendance = [];
               $totalPresent        = $totalLeave = $totalEarlyLeave = 0;
               $ovetimeHours        = $overtimeMins = $earlyleaveHours = $earlyleaveMins = $lateHours = $lateMins = 0;

               foreach ($employees as $key => $employee)
               {
                    $attendances['name'] = $employee->name;
                    $attendances['designation'] = (!empty($employee->designation)) ? $employee->designation->name : '';
                    $attendances['branch'] = (!empty($employee->branch)) ? $employee->branch->name : '';

                    $is_custom_weekoffs = $employee->is_custom_weekoffs ?? 0;
                    $employee_weekoffs_data = json_decode($employee->weekoffs_data) ?? [];

                    $test = [];
                    foreach ($dates as $date)
                    {
                         $dateFormat = $year . '-' . $month . '-' . $date;
                         $days = date('l', strtotime($dateFormat));

                         $localLeave = Leave::where('employee_id', $employee->id)->where('status', 'Approved')
                              ->where('start_date', '<=', $dateFormat)->where('end_date', '>=', $dateFormat)
                              ->where('created_by', Auth::user()->creatorId())
                              ->first();

                         $holiday = Holiday::where('status', 1)
                              ->where('start_date', '<=', $dateFormat)->where('end_date', '>=', $dateFormat)
                              ->where('created_by', Auth::user()->creatorId())
                              ->first();

                         // check is week off
                         $isWeekOff = false;
                         if ($is_custom_weekoffs == 1) // if 1 then check custom week off of employee
                         {
                              if (in_array($dateFormat, $employee_weekoffs_data))
                              {
                                   $isWeekOff = true;
                              }
                         }
                         else // if 0 then check company week off
                         {
                              if (in_array($days, $weefOffArray))
                              {
                                   $isWeekOff = true;
                              }
                         }
                         // check is week off



                         if (!empty($localLeave))
                         {
                              if ($localLeave->total_leave_days == "0.5")
                              {
                                   $attendanceStatus[$date] = "HD";
                                   $totalLeave              += 0.5;
                              }
                              else
                              {
                                   $attendanceStatus[$date] = "L";
                                   $totalLeave              += 1;
                              }
                         }
                         else
                         {
                              if ($dateFormat <= date('Y-m-d'))
                              {
                                   $employeeAttendance = AttendanceEmployee::where('employee_id', $employee->id)->where('date', $dateFormat)->first();

                                   if (empty($employeeAttendance))
                                   {

                                        // if (in_array($days, $weefOffArray))
                                        if ($isWeekOff)
                                        {
                                             $attendanceStatus[$date] = 'WO';
                                        }
                                        else
                                        {
                                             if (!empty($holiday) && $holiday->branch_name == $employee->branch_id)
                                             {
                                                  $attendanceStatus[$date] = 'H';
                                             }
                                             else
                                             {
                                                  if ($dateFormat == date('Y-m-d') && $setting['company_start_time'] >= date('H:i'))
                                                  {
                                                       $attendanceStatus[$date] = '';
                                                  }
                                                  else
                                                  {
                                                       $attendanceStatus[$date] = 'A';
                                                       $totalLeave              += 1;
                                                  }
                                             }
                                        }
                                   }
                                   elseif (!empty($employeeAttendance) && $employeeAttendance->status == 'Present')
                                   {
                                        $attendanceStatus[$date] = 'P';
                                        $totalPresent            += 1;

                                        if ($employeeAttendance->overtime > 0 && $employeeAttendance->overtime != "00:00:00")
                                        {

                                             $ovetimeHours += date('H', strtotime($employeeAttendance->overtime));
                                             $overtimeMins += date('i', strtotime($employeeAttendance->overtime));

                                             // dd(date('H', strtotime($employeeAttendance->overtime)), $employeeAttendance->overtime, $ovetimeHours, $overtimeMins);

                                             // $test[] = $employeeAttendance;
                                        }

                                        if ($employeeAttendance->early_leaving > 0  && $employeeAttendance->early_leaving != "00:00:00")
                                        {
                                             $earlyleaveHours += date('H', strtotime($employeeAttendance->early_leaving));
                                             $earlyleaveMins  += date('i', strtotime($employeeAttendance->early_leaving));
                                        }

                                        if ($employeeAttendance->late > 0  && $employeeAttendance->late != "00:00:00")
                                        {
                                             $lateHours += date('H', strtotime($employeeAttendance->late));
                                             $lateMins  += date('i', strtotime($employeeAttendance->late));
                                        }
                                   }
                                   else
                                   {
                                        $attendanceStatus[$date] = '';
                                   }
                              }
                              else
                              {
                                   if ($isWeekOff)
                                   // if (in_array($days, $weefOffArray))
                                   {
                                        $attendanceStatus[$date] = 'WO';
                                   }
                                   else
                                   {
                                        if (!empty($holiday) && $holiday->branch_name == $employee->branch_id)
                                        {
                                             $attendanceStatus[$date] = 'H';
                                        }
                                        else
                                        {
                                             $attendanceStatus[$date] = '';
                                        }
                                   }
                              }
                         }
                    }
                    $attendances['status'] = $attendanceStatus;
                    $employeesAttendance[] = $attendances;
               }

               // $totalOverTime   = $ovetimeHours + ($overtimeMins / 60);
               // $totalEarlyleave = $earlyleaveHours + ($earlyleaveMins / 60);
               // $totalLate       = $lateHours + ($lateMins / 60);


               // calculate total Early Leaving Time
               // dd($ovetimeHours, $overtimeMins, $test);
               $totalOvertimeMinutes = $ovetimeHours * 60 + $overtimeMins;
               $calculatedOvertimeHours = floor($totalOvertimeMinutes / 60);
               $calculatedOvertimeMinutes = $totalOvertimeMinutes % 60;
               $totalOverTime = sprintf("%02d:%02d:00", $calculatedOvertimeHours, $calculatedOvertimeMinutes);
               // calculate total Early Leaving Time


               // calculate total Early Leaving Time
               $totalEarlyLeaveMinutes = $earlyleaveHours * 60 + $earlyleaveMins;
               $calculatedEarlyLeaveHours = floor($totalEarlyLeaveMinutes / 60);
               $calculatedEarlyLeaveMinutes = $totalEarlyLeaveMinutes % 60;
               $totalEarlyleave = sprintf("%02d:%02d:00", $calculatedEarlyLeaveHours, $calculatedEarlyLeaveMinutes);
               // calculate total Early Leaving Time

               // calculate total Late time
               $totalLateMinutes = $lateHours * 60 + $lateMins;
               $calculatedLateHours = floor($totalLateMinutes / 60);
               $calculatedLateMinutes = $totalLateMinutes % 60;
               $totalLate = sprintf("%02d:%02d:00", $calculatedLateHours, $calculatedLateMinutes);
               // calculate total Late time

               $data['totalOvertime']   = $totalOverTime;
               $data['totalEarlyLeave'] = $totalEarlyleave;
               $data['totalLate']       = $totalLate;
               $data['totalPresent']    = $totalPresent;
               $data['totalLeave']      = $totalLeave;
               $data['curMonth']        = $curMonth;


               $requestMonth = $request->month ?? date('Y-m');
               $requestBranchId = $request->branch_id ?? "";
               $requestDepartmentId = $request->department ?? "";
               $requestEmployeeId = $request->employee_id ?? [0];


               return view('report.monthlyAttendance', compact('employeesAttendance', 'requestMonth', 'requestBranchId', 'requestDepartmentId', 'requestEmployeeId', 'branch', 'department', 'employees', 'dates', 'data'));
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function employeeAttendanceGeofencingReport(Request $request)
     {
          // dd($request->all());

          if (Auth::user()->can('Manage Report'))
          {
               $setting = Utility::settings();

               $weefOffArray = [];

               $branch = Branch::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
               $branch->prepend('All', '');

               $department = Department::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
               $department->prepend('All', '');

               $data['branch']     = __('All');
               $data['department'] = __('All');

               $employees = Employee::with('designation')->select('id', 'name', 'designation_id', 'branch_id');
               if (!empty($request->employee_id) && $request->employee_id[0] != 0)
               {
                    $employees->whereIn('id', $request->employee_id);
               }

               if (Auth::user()->type == 'company')
               {
                    $employees = $employees->where('created_by', Auth::user()->creatorId());
               }
               else
               {
                    $assign_employees = json_decode(Auth::user()->assign_employees) ?? [];
                    $employees = $employees->whereIn('id', $assign_employees)->where('created_by', Auth::user()->creatorId());
               }

               if (!empty($request->branch))
               {
                    $employees->where('branch_id', $request->branch);
                    $data['branch'] = !empty(Branch::find($request->branch)) ? Branch::find($request->branch)->name : '';
               }

               if (!empty($request->department))
               {
                    $employees->where('department_id', $request->department);
                    $data['department'] = !empty(Department::find($request->department)) ? Department::find($request->department)->name : '';
               }

               if (!empty($request->employees))
               {
                    $employees->where('employee_id', $request->employees);
                    $data['employees'] = !empty(Employee::find($request->employees)) ? Employee::find($request->employees)->name : '';
               }

               $employees = $employees->get();

               $month = "";
               if (!empty($request->month))
               {
                    $currentdate = strtotime($request->month);
                    $month       = date('m', $currentdate);
                    $year        = date('Y', $currentdate);
                    $curMonth    = date('M-Y', strtotime($request->month));
                    $currentMonth = $month . '-' . $year;
               }
               else
               {
                    $month    = date('m');
                    $year     = date('Y');
                    $curMonth = date('M-Y', strtotime($year . '-' . $month));
                    $currentMonth = $month . '-' . $year;
               }
               $data['curMonth']        = $curMonth;

               $employeeIds = $employees->pluck("id")->toArray();

               $employeesAttendance = AttendanceEmployee::select("*", "date as attendance_date")->whereIn('employee_id', $employeeIds)->whereMonth('date', $month)->whereYear('date', $year)->get();

               $monthDates = [];
               $date = DateTime::createFromFormat('Y-m-d', "$year-$month-01");
               $daysInMonth = $date->format('t');

               for ($day = 1; $day <= $daysInMonth; $day++)
               {
                    $formattedDate = $date->format('Y-m-d');
                    $monthDates[] = $formattedDate;
                    $date->modify('+1 day');
               }

               if ($request->has("export"))
               {
                    $pasasData = [
                         "month" => $month,
                         "year" => $year,
                         "data" => $employeesAttendance,
                         "monthDates" => $monthDates,
                    ];

                    return Excel::download(new EmployeeAttendanceGeofencingExcelExport($pasasData), "employee-attendance-geofencing-excel-export($month-$year).xlsx");
               }

               $user = User::find(Auth::user()->creatorId());

               $num_of_days = date('t', mktime(0, 0, 0, $month, 1, $year));
               for ($i = 1; $i <= $num_of_days; $i++)
               {
                    $dates[] = str_pad($i, 2, '0', STR_PAD_LEFT);
               }

               $requestMonth = $request->month ?? date('Y-m');
               $requestBranchId = $request->branch_id ?? "";
               $requestDepartmentId = $request->department ?? "";
               $requestEmployeeId = $request->employee_id ?? [0];


               return view('report.employee-attendance-geofencing', compact('employeesAttendance', 'requestMonth', 'requestBranchId', 'requestDepartmentId', 'requestEmployeeId', 'branch', 'department', 'employees', 'dates', 'data', "monthDates"));
          }
          else
          {
               return redirect()->back()->with('error', __('Permission denied.'));
          }
     }

     public function timesheet(Request $request)
     {
          try
          {
               if (Auth::user()->can('Manage Report'))
               {
                    $btn_trigger = $request->btn_trigger ?? "";

                    $branch = Branch::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
                    $branch->prepend('All', '');

                    $department = Department::where('created_by', Auth::user()->creatorId())->get()->pluck('name', 'id');
                    $department->prepend('All', '');

                    $filterYear['branch']     = __('All');
                    $filterYear['department'] = __('All');

                    if (Auth::user()->type == 'company')
                    {
                         $timesheets = TimeSheet::select('time_sheets.*', 'employees.name')->leftjoin('employees', 'time_sheets.employee_id', '=', 'employees.id')->where('time_sheets.created_by', Auth::user()->creatorId());
                         $timesheetFilters = TimeSheet::select('time_sheets.*', 'employees.name')->groupBy('employee_id')->selectRaw('sum(hours) as total')->leftjoin('employees', 'time_sheets.employee_id', '=', 'employees.id')->where('time_sheets.created_by', Auth::user()->creatorId());
                    }
                    else
                    {
                         $assign_employees = json_decode(Auth::user()->assign_employees) ?? [];
                         $assign_employees[] = Auth::user()->getUSerEmployee(Auth::id())->id;
                         $timesheets       = TimeSheet::select('time_sheets.*', 'employees.name')->leftjoin('employees', 'time_sheets.employee_id', '=', 'employees.id')->whereIn('time_sheets.employee_id', $assign_employees)->where('time_sheets.created_by', Auth::user()->creatorId());
                         $timesheetFilters = TimeSheet::select('time_sheets.*', 'employees.name')->groupBy('employee_id')->selectRaw('sum(hours) as total')->leftjoin('employees', 'time_sheets.employee_id', '=', 'employees.id')->whereIn('time_sheets.employee_id', $assign_employees)->where('time_sheets.created_by', Auth::user()->creatorId());
                    }

                    $filterYear['start_date'] = (!empty($request->start_date)) ? $request->start_date : date('Y-m-d');
                    $filterYear['end_date']   = (!empty($request->end_date)) ? $request->end_date : date('Y-m-d');

                    if ($btn_trigger == "reset")
                    {
                         $filterYear['start_date'] = date('Y-m-d');
                         $filterYear['end_date']   = date('Y-m-d');
                    }

                    if (!empty($request->start_date) && !empty($request->end_date) && $btn_trigger != "reset")
                    {
                         $timesheets->where('date', '>=', $filterYear['start_date']);
                         $timesheets->where('date', '<=',  $filterYear['end_date']);

                         $timesheetFilters->where('date', '>=', $filterYear['start_date']);
                         $timesheetFilters->where('date', '<=',  $filterYear['end_date']);
                    }
                    else
                    {

                         $timesheets->where('date', '>=', $filterYear['start_date']);
                         $timesheets->where('date', '<=', $filterYear['end_date']);

                         $timesheetFilters->where('date', '>=', $filterYear['start_date']);
                         $timesheetFilters->where('date', '<=', $filterYear['end_date']);
                    }

                    if (!empty($request->branch)  && $btn_trigger != "reset")
                    {
                         $timesheets->where('branch_id', $request->branch);
                         $timesheetFilters->where('branch_id', $request->branch);
                         $filterYear['branch'] = !empty(Branch::find($request->branch)) ? Branch::find($request->branch)->name : '';
                    }

                    if (!empty($request->department)  && $btn_trigger != "reset")
                    {
                         $timesheets->where('department_id', $request->department);
                         $timesheetFilters->where('department_id', $request->department);

                         $filterYear['department'] = !empty(Department::find($request->department)) ? Department::find($request->department)->name : '';
                    }

                    $timesheets = $timesheets->orderBy('time_sheets.id', 'desc')->get();

                    $timesheetFilters = $timesheetFilters->get();

                    $totalHours = 0;

                    foreach ($timesheetFilters as $timesheetFilter)
                    {
                         $totalHours += $timesheetFilter->hours;
                    }

                    $filterYear['totalHours']    = $totalHours;
                    $filterYear['totalEmployee'] = count($timesheetFilters);

                    if ($btn_trigger == "export")
                    {
                         if ($timesheets->isEmpty())
                         {
                              return redirect()->back()->with('error', __('No data to export.'));
                         }

                         $name = 'Timesheet_' . date('Y-m-d i:h:s');
                         return Excel::download(new TimesheetReportExport($timesheets), $name . '.xlsx');
                    }
                    else if ($btn_trigger == "reset")
                    {
                         return redirect()->route("report.timesheet");
                    }
                    else
                    {
                         return view('report.timesheet', compact('timesheets', 'branch', 'department', 'filterYear', 'timesheetFilters'));
                    }
               }
               else
               {
                    return redirect()->back()->with('error', __('Permission denied.'));
               }
          }
          catch (Exception $ex)
          {
               return redirect()->back()->with('error', showExceptionMessage($ex));
          }
          catch (Throwable $ex)
          {
               return redirect()->back()->with('error', showExceptionMessage($ex));
          }
     }

     public function LeaveReportExport(Request $request)
     {
          $year = $request->year ?? date('Y');
          $branch = $request->branch ?? "";
          $department = $request->department ?? "";

          $requestData = [
               "year" => $year,
               "branch" => $branch,
               "department" => $department,
          ];

          $name = 'leave_' . date('Y-m-d i:h:s');

          try
          {
               $data = Excel::download(new LeaveReportExport($requestData), $name . '.xlsx');
               return $data;
          }
          catch (ModelNotFoundException $exception)
          {
               // Handle the exception, for example, redirect back with an error message
               return redirect()->back()->with('error', $exception->getMessage());
               return redirect()->route("report.leave")->with('error', $exception->getMessage());
          }
     }

     public function AccountStatementReportExport(Request $request)
     {
          $name = 'Account Statement_' . date('Y-m-d i:h:s');
          $data = Excel::download(new accountstatementExport(), $name . '.xlsx');

          return $data;
     }

     public function PayrollReportExport(Request $request)
     {
          $name = 'Payroll_' . date('Y-m-d i:h:s');
          $data = Excel::download(new PayrollExport(), $name . '.xlsx');

          return $data;
     }

     public function exportTimeshhetReport(Request $request)
     {
          $name = 'Timesheet_' . date('Y-m-d i:h:s');
          $data = Excel::download(new TimesheetReportExport(), $name . '.xlsx');

          return $data;
     }

     public function monthelyAttendanceReport($filter_month, $branch, $department, $employee)
     {
          $setting = Utility::settings();

          $weefOffArray = [];
          if ($setting['company_office_week_off_monday'] == 'on')
          {
               $weefOffArray[] = "Monday";
          }
          if ($setting['company_office_week_off_tuesday'] == 'on')
          {
               $weefOffArray[] = "Tuesday";
          }
          if ($setting['company_office_week_off_wednesday'] == 'on')
          {
               $weefOffArray[] = "Wednesday";
          }
          if ($setting['company_office_week_off_thusday'] == 'on')
          {
               $weefOffArray[] = "Thursday";
          }
          if ($setting['company_office_week_off_friday'] == 'on')
          {
               $weefOffArray[] = "Friday";
          }
          if ($setting['company_office_week_off_saturday'] == 'on')
          {
               $weefOffArray[] = "Saturday";
          }
          if ($setting['company_office_week_off_sunday'] == 'on')
          {
               $weefOffArray[] = "Sunday";
          }
          // clock_in

          $data['branch'] = __('All');
          $data['department'] = __('All');

          $employees = Employee::with('designation')->select('id', 'name', 'designation_id', 'branch_id', 'department_id', 'employee_id')->where('created_by', Auth::user()->creatorId());

          if (Auth::user()->type != 'company')
          {
               $assign_employees = json_decode(Auth::user()->assign_employees) ?? [];
               $employees = $employees->whereIn('id', $assign_employees);
          }

          if ($branch != 0)
          {
               $employees->where('branch_id', $branch);
               $data['branch'] = !empty(Branch::find($branch)) ? Branch::find($branch)->name : '';
          }

          if ($department != 0)
          {
               $employees->where('department_id', $department);
               $data['department'] = !empty(Department::find($department)) ? Department::find($department)->name : '';
          }
          if ($employee != 0)
          {
               $employeeIds = explode(',', $employee);
               $employees->whereIn('id', $employeeIds);
          }

          $employees = $employees->get();

          $currentdate = strtotime($filter_month);
          $month       = date('m', $currentdate);
          $year        = date('Y', $currentdate);
          $data['curMonth']    = date('M-Y', strtotime($filter_month));


          $fileName = $data['branch'] . ' ' . __('Branch') . ' ' . $data['curMonth'] . ' ' . __('Attendance Report of') . ' ' . $data['department'] . ' ' . __('Department') . ' ' . '.csv';


          $num_of_days = date('t', mktime(0, 0, 0, $month, 1, $year));
          for ($i = 1; $i <= $num_of_days; $i++)
          {
               $dates[] = str_pad($i, 2, '0', STR_PAD_LEFT);
          }

          $employeesAttendance = [];
          foreach ($employees as $key => $employee)
          {
               $attendances['employee_id'] = $employee->employee_id;
               $attendances['name'] = $employee->name;
               $attendances['branch'] = (!empty($employee->branch)) ? $employee->branch->name : '';
               $attendances['designation'] = (!empty($employee->designation)) ? $employee->designation->name : '';
               // $attendances['department'] = (!empty($employee->department)) ? $employee->department->name : '';

               // Present
               // Leave

               $employeeAttendanceData = AttendanceEmployee::where('employee_id', $employee->id)->whereYear("date", $year)->whereMonth("date", $month)->get();

               $attendances['present_days'] = $employeeAttendanceData->where("status", "Present")->count("*") ?? 0;
               $attendances['absend_days'] = $employeeAttendanceData->where("status", "Leave")->count("*") ?? 0;

               $present_days = 0;
               $absend_days = 0;

               $is_custom_weekoffs = $employee->is_custom_weekoffs ?? 0;
               $employee_weekoffs_data = json_decode($employee->weekoffs_data) ?? [];

               foreach ($dates as $date)
               {
                    $dateFormat = $year . '-' . $month . '-' . $date;
                    $days = date('l', strtotime($dateFormat));

                    $localLeave = Leave::where('employee_id', $employee->id)->where('status', 'Approved')
                         ->where('start_date', '<=', $dateFormat)->where('end_date', '>=', $dateFormat)
                         ->where('created_by', Auth::user()->creatorId())
                         ->first();

                    $holiday = Holiday::where('status', 1)
                         ->where('start_date', '<=', $dateFormat)->where('end_date', '>=', $dateFormat)
                         ->where('created_by', Auth::user()->creatorId())
                         ->first();

                    // check is week off
                    $isWeekOff = false;
                    if ($is_custom_weekoffs == 1) // if 1 then check custom week off of employee
                    {
                         if (in_array($dateFormat, $employee_weekoffs_data))
                         {
                              $isWeekOff = true;
                         }
                    }
                    else // if 0 then check company week off
                    {
                         if (in_array($days, $weefOffArray))
                         {
                              $isWeekOff = true;
                         }
                    }
                    // check is week off

                    if (!empty($localLeave))
                    {
                         if ($localLeave->total_leave_days == "0.5")
                         {
                              $attendanceStatus[$date] = "HD";
                         }
                         else
                         {
                              $attendanceStatus[$date] = "L";
                         }
                    }
                    else
                    {
                         if ($dateFormat <= date('Y-m-d'))
                         {
                              $employeeAttendance = AttendanceEmployee::where('employee_id', $employee->id)->where('date', $dateFormat)->first();

                              if (empty($employeeAttendance))
                              {
                                   if ($isWeekOff)
                                   // if (in_array($days, $weefOffArray))
                                   {
                                        $attendanceStatus[$date] = 'WO';
                                   }
                                   else
                                   {
                                        if (!empty($holiday) && $holiday->branch_name == $employee->branch_id)
                                        {
                                             $attendanceStatus[$date] = 'H';
                                        }
                                        else
                                        {
                                             if ($dateFormat == date('Y-m-d') && $setting['company_start_time'] >= date('H:i'))
                                             {
                                                  $attendanceStatus[$date] = '-';
                                             }
                                             else
                                             {
                                                  $attendanceStatus[$date] = 'A';
                                                  $absend_days++;
                                             }
                                        }
                                   }
                              }
                              elseif (!empty($employeeAttendance) && $employeeAttendance->status == 'Present')
                              {
                                   // dd("employeeAttendance", $employeeAttendance);

                                   $clockIn = "";
                                   $clockOut = "";

                                   if (!empty($employeeAttendance->clock_in) && $employeeAttendance->clock_in != "00:00:00")
                                   {
                                        $clockIn = Auth::user()->timeFormat($employeeAttendance->clock_in);
                                   }

                                   if (!empty($employeeAttendance->clock_out) && $employeeAttendance->clock_out != "00:00:00")
                                   {
                                        $clockOut = Auth::user()->timeFormat($employeeAttendance->clock_out);
                                   }

                                   // $clockOut = Auth::user()->timeFormat($employeeAttendance->clock_out);

                                   $clockInLatitude = $employeeAttendance->clock_in_latitude;
                                   $clockInLongitude = $employeeAttendance->clock_in_longitude;

                                   $clockOutLatitude = $employeeAttendance->clock_out_latitude;
                                   $clockOutLongitude = $employeeAttendance->clock_out_longitude;

                                   $clockInLink = "";
                                   if (!empty($clockInLatitude) && !empty($clockInLongitude))
                                   {
                                        $clockInLink = "(https://www.google.com/maps/search/?api=1&query={$clockInLatitude},{$clockInLongitude})";
                                   }


                                   $clockOutLink = "";
                                   if (!empty($clockOutLatitude) && !empty($clockOutLongitude))
                                   {
                                        $clockOutLink = "(https://www.google.com/maps/search/?api=1&query={$clockOutLatitude},{$clockOutLongitude})";
                                   }

                                   // $clockInLinkShow = '=HYPERLINK("' . $clockInLink . '", "Click Here")';
                                   // $clockOurLinkShow = '=HYPERLINK("' . $clockOutLink . '", "Click Here")';


                                   // $attendanceStatus[$date] = $clockIn . " $clockInLink , " . $clockOut . " $clockOutLink";
                                   $attendanceStatus[$date] = $clockIn . " , " . $clockOut;
                                   // $attendanceStatus[$date] = "<a href='https://www.google.com'>Click Here</a>";
                                   $present_days++;
                              }
                              else
                              {
                                   $attendanceStatus[$date] = '-';
                              }
                         }
                         else
                         {
                              if ($isWeekOff)
                              // if (in_array($days, $weefOffArray))
                              {
                                   $attendanceStatus[$date] = 'WO';
                              }
                              else
                              {
                                   if (!empty($holiday) && $holiday->branch_name == $employee->branch_id)
                                   {
                                        $attendanceStatus[$date] = 'H';
                                   }
                                   else
                                   {
                                        $attendanceStatus[$date] = '-';
                                   }
                              }
                         }
                    }
                    $attendances[$date] = $attendanceStatus[$date];
               }

               $attendances['present_days'] = $present_days;
               $attendances['absend_days'] = $absend_days;

               $employeesAttendance[] = $attendances;
          }

          $headers = array(
               "Content-type" => "text/csv",
               "Content-Disposition" => "attachment; filename=$fileName",
               "Pragma" => "no-cache",
               "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
               "Expires" => "0",
          );
          $emp = array(
               'Employee Id',
               'Employee',
               'Branch',
               'Designation',
               'Present (In Days)',
               'Absent (In Days)',
          );

          $changedColumns = [];

          foreach ($dates as $columnsRow)
          {
               $changedColumns[] = $columnsRow . "-" . $month . "-" . $year;
          }

          $columns = array_merge($emp, $changedColumns);

          $data = [
               "columns" => $columns,
               "data" => $employeesAttendance,
          ];

          // return Excel::download(new MonthelyAttendanceReportExport($data), 'exported_data.xlsx');

          $callback = function () use ($employeesAttendance, $columns)
          {
               $file = fopen('php://output', 'w');
               fputcsv($file, $columns);

               foreach ($employeesAttendance as $attendance)
               {
                    fputcsv($file, str_replace('"', '', array_values($attendance)));
               }

               fclose($file);
          };

          return response()->stream($callback, 200, $headers);
     }

     public function monthelyAttendanceRepor_OldExcel($filter_month, $branch, $department, $employee)
     {
          $setting = Utility::settings();

          $weefOffArray = [];
          if ($setting['company_office_week_off_monday'] == 'on')
          {
               $weefOffArray[] = "Monday";
          }
          if ($setting['company_office_week_off_tuesday'] == 'on')
          {
               $weefOffArray[] = "Tuesday";
          }
          if ($setting['company_office_week_off_wednesday'] == 'on')
          {
               $weefOffArray[] = "Wednesday";
          }
          if ($setting['company_office_week_off_thusday'] == 'on')
          {
               $weefOffArray[] = "Thursday";
          }
          if ($setting['company_office_week_off_friday'] == 'on')
          {
               $weefOffArray[] = "Friday";
          }
          if ($setting['company_office_week_off_saturday'] == 'on')
          {
               $weefOffArray[] = "Saturday";
          }
          if ($setting['company_office_week_off_sunday'] == 'on')
          {
               $weefOffArray[] = "Sunday";
          }

          $data['branch'] = __('All');
          $data['department'] = __('All');

          $employees = Employee::with('designation')->select('id', 'name', 'designation_id', 'branch_id', 'department_id')->where('created_by', Auth::user()->creatorId());

          if (Auth::user()->type != 'company')
          {
               $assign_employees = json_decode(Auth::user()->assign_employees) ?? [];
               $employees = $employees->whereIn('id', $assign_employees);
          }

          if ($branch != 0)
          {
               $employees->where('branch_id', $branch);
               $data['branch'] = !empty(Branch::find($branch)) ? Branch::find($branch)->name : '';
          }

          if ($department != 0)
          {
               $employees->where('department_id', $department);
               $data['department'] = !empty(Department::find($department)) ? Department::find($department)->name : '';
          }
          if ($employee != 0)
          {
               $employeeIds = explode(',', $employee);
               $employees->whereIn('id', $employeeIds);
          }

          $employees = $employees->get();

          $currentdate = strtotime($filter_month);
          $month       = date('m', $currentdate);
          $year        = date('Y', $currentdate);
          $data['curMonth']    = date('M-Y', strtotime($filter_month));


          $fileName = $data['branch'] . ' ' . __('Branch') . ' ' . $data['curMonth'] . ' ' . __('Attendance Report of') . ' ' . $data['department'] . ' ' . __('Department') . ' ' . '.csv';


          $num_of_days = date('t', mktime(0, 0, 0, $month, 1, $year));
          for ($i = 1; $i <= $num_of_days; $i++)
          {
               $dates[] = str_pad($i, 2, '0', STR_PAD_LEFT);
          }

          $employeesAttendance = [];
          foreach ($employees as $key => $employee)
          {
               $attendances['employee_id'] = Auth::user()->employeeIdFormat($employee->id);
               $attendances['name'] = $employee->name;
               $attendances['designation'] = (!empty($employee->designation)) ? $employee->designation->name : '';
               $attendances['department'] = (!empty($employee->department)) ? $employee->department->name : '';

               // Present
               // Leave

               $employeeAttendanceData = AttendanceEmployee::where('employee_id', $employee->id)->whereYear("date", $year)->whereMonth("date", $month)->get();

               $attendances['present_days'] = $employeeAttendanceData->where("status", "Present")->count("*") ?? 0;
               $attendances['absend_days'] = $employeeAttendanceData->where("status", "Leave")->count("*") ?? 0;

               $present_days = 0;
               $absend_days = 0;

               foreach ($dates as $date)
               {
                    $dateFormat = $year . '-' . $month . '-' . $date;
                    $days = date('l', strtotime($dateFormat));

                    $localLeave = Leave::where('employee_id', $employee->id)->where('status', 'Approved')
                         ->where('start_date', '<=', $dateFormat)->where('end_date', '>=', $dateFormat)
                         ->where('created_by', Auth::user()->creatorId())
                         ->first();

                    $holiday = Holiday::where('status', 1)
                         ->where('start_date', '<=', $dateFormat)->where('end_date', '>=', $dateFormat)
                         ->where('created_by', Auth::user()->creatorId())
                         ->first();

                    if (!empty($localLeave))
                    {
                         if ($localLeave->total_leave_days == "0.5")
                         {
                              $attendanceStatus[$date] = "HD";
                         }
                         else
                         {
                              $attendanceStatus[$date] = "L";
                         }
                    }
                    else
                    {
                         if ($dateFormat <= date('Y-m-d'))
                         {
                              $employeeAttendance = AttendanceEmployee::where('employee_id', $employee->id)->where('date', $dateFormat)->first();

                              if (empty($employeeAttendance))
                              {
                                   if (in_array($days, $weefOffArray))
                                   {
                                        $attendanceStatus[$date] = 'WO';
                                   }
                                   else
                                   {
                                        if (!empty($holiday) && $holiday->branch_name == $employee->branch_id)
                                        {
                                             $attendanceStatus[$date] = 'H';
                                        }
                                        else
                                        {
                                             if ($dateFormat == date('Y-m-d') && $setting['company_start_time'] >= date('H:i'))
                                             {
                                                  $attendanceStatus[$date] = '-';
                                             }
                                             else
                                             {
                                                  $attendanceStatus[$date] = 'A';
                                                  $absend_days++;
                                             }
                                        }
                                   }
                              }
                              elseif (!empty($employeeAttendance) && $employeeAttendance->status == 'Present')
                              {
                                   // dd("employeeAttendance", $employeeAttendance);

                                   $clockIn = Auth::user()->timeFormat($employeeAttendance->clock_in);
                                   $clockOut = Auth::user()->timeFormat($employeeAttendance->clock_out);

                                   $clockInLatitude = $employeeAttendance->clock_in_latitude;
                                   $clockInLongitude = $employeeAttendance->clock_in_longitude;

                                   $clockOutLatitude = $employeeAttendance->clock_out_latitude;
                                   $clockOutLongitude = $employeeAttendance->clock_out_longitude;


                                   $clockInLink = "";
                                   if (!empty($clockInLatitude) && !empty($clockInLongitude))
                                   {
                                        $clockInLink = "(https://www.google.com/maps/search/?api=1&query={$clockInLatitude},{$clockInLongitude})";
                                   }


                                   $clockOutLink = "";
                                   if (!empty($clockOutLatitude) && !empty($clockOutLongitude))
                                   {
                                        $clockOutLink = "(https://www.google.com/maps/search/?api=1&query={$clockOutLatitude},{$clockOutLongitude})";
                                   }

                                   // $clockInLinkShow = '=HYPERLINK("' . $clockInLink . '", "Click Here")';
                                   // $clockOurLinkShow = '=HYPERLINK("' . $clockOutLink . '", "Click Here")';


                                   $attendanceStatus[$date] = $clockIn . " $clockInLink , " . $clockOut . " $clockOutLink";
                                   $present_days++;
                              }
                              else
                              {
                                   $attendanceStatus[$date] = '-';
                              }
                         }
                         else
                         {
                              if (in_array($days, $weefOffArray))
                              {
                                   $attendanceStatus[$date] = 'WO';
                              }
                              else
                              {
                                   if (!empty($holiday) && $holiday->branch_name == $employee->branch_id)
                                   {
                                        $attendanceStatus[$date] = 'H';
                                   }
                                   else
                                   {
                                        $attendanceStatus[$date] = '-';
                                   }
                              }
                         }
                    }
                    $attendances[$date] = $attendanceStatus[$date];
               }

               $attendances['present_days'] = $present_days;
               $attendances['absend_days'] = $absend_days;

               $employeesAttendance[] = $attendances;
          }

          $headers = array(
               "Content-type" => "text/csv",
               "Content-Disposition" => "attachment; filename=$fileName",
               "Pragma" => "no-cache",
               "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
               "Expires" => "0",
          );
          $emp = array(
               'Employee Id',
               'Employee',
               'Designation',
               'Department',
               'Present (In Days)',
               'Absent (In Days)',
          );

          $changedColumns = [];

          foreach ($dates as $columnsRow)
          {
               $changedColumns[] = $columnsRow . "-" . $month . "-" . $year;
          }

          $columns = array_merge($emp, $changedColumns);

          $data = [
               "columns" => $columns,
               "data" => $employeesAttendance,
          ];
          // return Excel::download(new MonthelyAttendanceReportExport($data), 'exported_data.xlsx');

          $callback = function () use ($employeesAttendance, $columns)
          {
               $file = fopen('php://output', 'w');
               fputcsv($file, $columns);

               foreach ($employeesAttendance as $attendance)
               {
                    fputcsv($file, str_replace('"', '', array_values($attendance)));
               }

               fclose($file);
          };

          return response()->stream($callback, 200, $headers);
     }

     public function monthelyAttendanceReport_ORIGINAL($filter_month, $branch, $department, $employee)
     {
          $setting = Utility::settings();

          $weefOffArray = [];
          if ($setting['company_office_week_off_monday'] == 'on')
          {
               $weefOffArray[] = "Monday";
          }
          if ($setting['company_office_week_off_tuesday'] == 'on')
          {
               $weefOffArray[] = "Tuesday";
          }
          if ($setting['company_office_week_off_wednesday'] == 'on')
          {
               $weefOffArray[] = "Wednesday";
          }
          if ($setting['company_office_week_off_thusday'] == 'on')
          {
               $weefOffArray[] = "Thursday";
          }
          if ($setting['company_office_week_off_friday'] == 'on')
          {
               $weefOffArray[] = "Friday";
          }
          if ($setting['company_office_week_off_saturday'] == 'on')
          {
               $weefOffArray[] = "Saturday";
          }
          if ($setting['company_office_week_off_sunday'] == 'on')
          {
               $weefOffArray[] = "Sunday";
          }

          $data['branch'] = __('All');
          $data['department'] = __('All');

          $employees = Employee::with('designation')->select('id', 'name', 'designation_id')->where('created_by', Auth::user()->creatorId());

          if (Auth::user()->type != 'company')
          {
               $assign_employees = json_decode(Auth::user()->assign_employees) ?? [];
               $employees = $employees->whereIn('id', $assign_employees);
          }

          if ($branch != 0)
          {
               $employees->where('branch_id', $branch);
               $data['branch'] = !empty(Branch::find($branch)) ? Branch::find($branch)->name : '';
          }

          if ($department != 0)
          {
               $employees->where('department_id', $department);
               $data['department'] = !empty(Department::find($department)) ? Department::find($department)->name : '';
          }
          if ($employee != 0)
          {
               $employeeIds = explode(',', $employee);
               $employees->whereIn('id', $employeeIds);
          }

          $employees = $employees->get();

          $currentdate = strtotime($filter_month);
          $month       = date('m', $currentdate);
          $year        = date('Y', $currentdate);
          $data['curMonth']    = date('M-Y', strtotime($filter_month));


          $fileName = $data['branch'] . ' ' . __('Branch') . ' ' . $data['curMonth'] . ' ' . __('Attendance Report of') . ' ' . $data['department'] . ' ' . __('Department') . ' ' . '.csv';


          $num_of_days = date('t', mktime(0, 0, 0, $month, 1, $year));
          for ($i = 1; $i <= $num_of_days; $i++)
          {
               $dates[] = str_pad($i, 2, '0', STR_PAD_LEFT);
          }

          $employeesAttendance = [];
          foreach ($employees as $key => $employee)
          {
               $attendances['name'] = $employee->name;
               $attendances['designation'] = (!empty($employee->designation)) ? $employee->designation->name : '';

               foreach ($dates as $date)
               {
                    $dateFormat = $year . '-' . $month . '-' . $date;
                    $days = date('l', strtotime($dateFormat));

                    $localLeave = Leave::where('employee_id', $employee->id)->where('status', 'Approved')
                         ->where('start_date', '<=', $dateFormat)->where('end_date', '>=', $dateFormat)
                         ->where('created_by', Auth::user()->creatorId())
                         ->first();

                    // $halfDay = Leave::where('employee_id', $employee->id)->where('total_leave_days',0.5)->where('status', 'Approved')
                    //      ->where('start_date', '<=', $dateFormat)->where('end_date', '>=', $dateFormat)
                    //      ->where('created_by', Auth::user()->creatorId())
                    //      ->first();

                    $holiday = Holiday::where('status', 1)
                         ->where('start_date', '<=', $dateFormat)->where('end_date', '>=', $dateFormat)
                         ->where('created_by', Auth::user()->creatorId())
                         ->first();

                    if (!empty($localLeave))
                    {
                         if ($localLeave->total_leave_days == "0.5")
                         {
                              $attendanceStatus[$date] = "HD";
                         }
                         else
                         {
                              $attendanceStatus[$date] = "L";
                         }
                    }
                    else
                    {
                         if ($dateFormat <= date('Y-m-d'))
                         {
                              $employeeAttendance = AttendanceEmployee::where('employee_id', $employee->id)->where('date', $dateFormat)->first();

                              if (empty($employeeAttendance))
                              {
                                   if (in_array($days, $weefOffArray))
                                   {
                                        $attendanceStatus[$date] = 'WO';
                                   }
                                   else
                                   {
                                        if (!empty($holiday))
                                        {
                                             $attendanceStatus[$date] = 'H';
                                        }
                                        else
                                        {
                                             if ($dateFormat == date('Y-m-d') && $setting['company_start_time'] >= date('H:i'))
                                             {
                                                  $attendanceStatus[$date] = '-';
                                             }
                                             else
                                             {
                                                  $attendanceStatus[$date] = 'A';
                                             }
                                        }
                                   }
                              }
                              elseif (!empty($employeeAttendance) && $employeeAttendance->status == 'Present')
                              {
                                   $attendanceStatus[$date] = 'P';
                              }
                              else
                              {
                                   $attendanceStatus[$date] = '-';
                              }
                         }
                         else
                         {
                              if (in_array($days, $weefOffArray))
                              {
                                   $attendanceStatus[$date] = 'WO';
                              }
                              else
                              {
                                   if (!empty($holiday))
                                   {
                                        $attendanceStatus[$date] = 'H';
                                   }
                                   else
                                   {
                                        $attendanceStatus[$date] = '-';
                                   }
                              }
                         }
                    }

                    // if ($dateFormat <= date('Y-m-d')) {
                    //      $employeeAttendance = AttendanceEmployee::where('employee_id', $employee->id)->where('date', $dateFormat)->first();

                    //      if (!empty($employeeAttendance) && $employeeAttendance->status == 'Present') {
                    //           $attendanceStatus[$date] = 'P';
                    //      } elseif (!empty($employeeAttendance) && $employeeAttendance->status == 'Leave') {
                    //           $attendanceStatus[$date] = 'A';
                    //      } else {
                    //           $attendanceStatus[$date] = '-';
                    //      }
                    // } else {
                    //      $attendanceStatus[$date] = '-';
                    // }
                    $attendances[$date] = $attendanceStatus[$date];
               }

               $employeesAttendance[] = $attendances;
          }

          $headers = array(
               "Content-type" => "text/csv",
               "Content-Disposition" => "attachment; filename=$fileName",
               "Pragma" => "no-cache",
               "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
               "Expires" => "0",
          );
          $emp = array(
               'Employee',
               'Designation',
          );

          $columns = array_merge($emp, $dates);

          $callback = function () use ($employeesAttendance, $columns)
          {
               $file = fopen('php://output', 'w');
               fputcsv($file, $columns);

               foreach ($employeesAttendance as $attendance)
               {
                    fputcsv($file, str_replace('"', '', array_values($attendance)));
               }

               fclose($file);
          };

          return response()->stream($callback, 200, $headers);
     }

     public function getdepartment(Request $request)
     {
          $branch_id = $request->branch_id ?? 0;
          $departments = Department::where('created_by', '=', Auth::user()->creatorId());

          if ($branch_id != 0)
          {
               $departments->where('branch_id', $request->branch_id);
          }
          $departments = $departments->get()->pluck('name', 'id')->toArray();

          // if ($request->branch_id == 0) {
          //      $departments = Department::where('created_by', '=', Auth::user()->creatorId())->get()->pluck('name', 'id')->toArray();
          // } else {
          //      $departments = Department::where('created_by', '=', Auth::user()->creatorId())->where('branch_id', $request->branch_id)->get()->pluck('name', 'id')->toArray();
          // }
          return response()->json($departments);
     }

     public function getemployee(Request $request)
     {
          $department_id = $request->department_id ?? 0;
          $employees = Employee::Query();
          if (Auth::user()->type == 'company')
          {
               $employees->where('created_by', '=', Auth::user()->creatorId());
          }
          else
          {
               $assign_employees = json_decode(Auth::user()->assign_employees) ?? [];
               $employees->whereIn('id', $assign_employees)->where('created_by', '=', Auth::user()->creatorId());
          }
          if ($department_id != 0)
          {
               $employees->where('department_id', $department_id);
          }
          $employees =  $employees->get()->pluck('name', 'id')->toArray();

          // if (!$request->department_id) {
          //      $employees = Employee::where('created_by', '=', Auth::user()->creatorId())->get()->pluck('name', 'id')->toArray();
          // } else {
          //      $employees = Employee::where('created_by', '=', Auth::user()->creatorId())->where('department_id', $request->department_id)->get()->pluck('name', 'id')->toArray();
          // }

          return response()->json($employees);
     }

     public function claim(Request $request)
     {
          try
          {
               if (Auth::user()->can('Manage Report'))
               {
                    $status = [
                         '' => 'All',
                         'Pending' => 'Pending',
                         'Approved' => 'Approved',
                         'Rejected' => 'Rejected'
                    ];
                    $filterYear['type']          = __('Daily');
                    $filterYear['dateYearRange'] = date('M-Y');

                    $start_date = $request->start_date;
                    $end_date = $request->end_date;

                    DB::enableQueryLog();
                    $claim = MyClaimModel::with('GradeName', 'myvisitData', 'employee');

                    $approved = MyClaimModel::where('status', 'Approved');

                    $reject = MyClaimModel::where('status', 'Rejected');

                    $pending = MyClaimModel::where('status', 'Pending');

                    $claim->where('created_by', '=', Auth::user()->creatorId());
                    if (!empty($request->status))
                    {
                         $claim->where('status', $request->status);
                    }


                    // Start Date and End Date filter 
                    if ($request->type == 'daily' && !empty($request->start_date) && !empty($request->end_date))
                    {

                         $claim->where([['created_at', '>=', $request->start_date . " 00:00:00"], ['created_at', '<=', $request->end_date . " 23:59:59"]]);
                         $approved->where([['created_at', '>=', $request->start_date . " 00:00:00"], ['created_at', '<=', $request->end_date . " 23:59:59"]]);
                         $reject->where([['created_at', '>=', $request->start_date . " 00:00:00"], ['created_at', '<=', $request->end_date . " 23:59:59"]]);
                         $pending->where([['created_at', '>=', $request->start_date . " 00:00:00"], ['created_at', '<=', $request->end_date . " 23:59:59"]]);

                         $filterYear['dateYearRange'] = date('d-M-Y', strtotime($request->start_date)) . ' to ' . date('d-M-Y', strtotime($request->end_date));
                         $filterYear['type']          = __('Daily');
                    }
                    elseif (!isset($request->type))
                    {
                         $month     = date('m');
                         $year      = date('Y');
                         $monthYear = date('Y-m');

                         $claim->whereMonth('created_at', $month)->whereYear('created_at', $year);
                         $approved->whereMonth('created_at', $month)->whereYear('created_at', $year);
                         $reject->whereMonth('created_at', $month)->whereYear('created_at', $year);
                         $pending->whereMonth('created_at', $month)->whereYear('created_at', $year);

                         $filterYear['dateYearRange'] = date('d-M-Y', strtotime($monthYear));
                         $filterYear['type']          = __('Daily');
                    }

                    if ($request->type == 'monthly' && !empty($request->month))
                    {
                         $month = date('m', strtotime($request->month));
                         $year  = date('Y', strtotime($request->month));

                         $claim->whereMonth('created_at', $month)->whereYear('created_at', $year);
                         $approved->whereMonth('created_at', $month)->whereYear('created_at', $year);
                         $reject->whereMonth('created_at', $month)->whereYear('created_at', $year);
                         $pending->whereMonth('created_at', $month)->whereYear('created_at', $year);

                         $filterYear['dateYearRange'] = date('M-Y', strtotime($request->month));
                         $filterYear['type']          = __('Monthly');
                    }

                    if ($request->type == 'yearly' && !empty($request->year))
                    {
                         $claim->whereYear('created_at', $request->year);
                         $approved->whereYear('created_at', $request->year);
                         $reject->whereYear('created_at', $request->year);
                         $pending->whereYear('created_at', $request->year);


                         $filterYear['dateYearRange'] = $request->year;
                         $filterYear['type']          = __('Yearly');
                    }

                    $claims = $claim->where('created_by', '=', Auth::user()->creatorId())->orderBy("id", "DESC")->get();
                    $totalApproved = $approved->count();
                    $totalReject = $reject->count();
                    $totalPending = $pending->count();


                    $starting_year = date('Y', strtotime('-5 year'));
                    $ending_year   = date('Y', strtotime('+5 year'));

                    $filterYear['starting_year'] = $starting_year;
                    $filterYear['ending_year']   = $ending_year;

                    $filter['totalApproved'] = $totalApproved;
                    $filter['totalReject']   = $totalReject;
                    $filter['totalPending']  = $totalPending;

                    if ($request->export)
                    {
                         if (empty($claims) || count($claims) <= 0)
                         {
                              return redirect()->back()->with('error', __('No records to export.'));
                         }

                         $fileName = 'claims.csv';

                         $headers = array(
                              "Content-type"        => "text/csv",
                              "Content-Disposition" => "attachment; filename=$fileName",
                              "Pragma"              => "no-cache",
                              "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
                              "Expires"             => "0"
                         );

                         $columns = array(
                              'Sr No',
                              'Employee',
                              'Visit Type',
                              'Visit Name',
                              'Other Claim',
                              'Visit Date',
                              'Vehicle Type',
                              'Tier',
                              'City',
                              'Amount',
                              'Status',
                              'Status Changed By'
                         );

                         $callback = function () use ($claims, $columns)
                         {
                              $file = fopen('php://output', 'w');
                              fputcsv($file, $columns);

                              $srNo = 1;
                              foreach ($claims as $claim)
                              {
                                   $visit_type = "";
                                   $visitDate = "";
                                   if ($claim->visit_type == 0)
                                   {
                                        if (!empty($claim->myvisitData))
                                        {
                                             $visitDate = (Auth::user()->dateFormat($claim->myvisitData->form_date) ?? "");
                                             if ($claim->myvisitData->visit_type == 1)
                                             {
                                                  $visit_type = 'Local visit';
                                             }
                                             else
                                             {
                                                  $visit_type = 'Out of City visit';
                                             }
                                        }
                                        else
                                        {
                                             $visit_type = 'Out of City visit';
                                        }
                                   }
                                   else
                                   {
                                        $visit_type = 'Other Claim';
                                        $visitDate = Auth::user()->dateFormat($claim->created_at);
                                   }

                                   if ($claim->status == 'Approved')
                                   {
                                        $status = "Approved";
                                   }
                                   else if ($claim->status == 'Rejected')
                                   {
                                        $status = 'Rejected';
                                   }
                                   else
                                   {
                                        $status = 'Pending';
                                   }

                                   $vehicleType = "";

                                   if ($claim->commuting_type == 1)
                                   {
                                        $vehicleType = "Two wheeler";
                                   }
                                   else
                                   {
                                        $vehicleType = "Four wheeler";
                                   }

                                   $tier = "";
                                   $city = "";

                                   if ($claim->visit_type == 0)
                                   {
                                        if (($claim->myvisitData->visit_type ?? 0) == 2)
                                        {
                                             $tierData = CityTier::find($claim->myvisitData->tier_id);
                                             $tier = $tierData->name ?? '';

                                             $cityData = CityModel::find($claim->myvisitData->city_id);
                                             $city = $cityData->name;
                                        }
                                   }

                                   $row['Sr No']  = $srNo;
                                   $row['Employee']  = $claim->employee->name;
                                   $row['Visit Type']    = $visit_type;
                                   $row['Visit Name']    = $claim->myvisitData->visit_name ?? "";
                                   $row['Other Claim']    = $claim->name ?? "";
                                   $row['Visit Date']    = $visitDate;
                                   $row['Vehicle Type']    = $vehicleType;
                                   $row['Tier']    = $tier;
                                   $row['City']    = $city;
                                   $row['Amount']    = $claim->total_amount;
                                   $row['Status']    = $status;
                                   $row['Status Changed By']    = findEmployeeByUser($claim->status_changed_by);

                                   fputcsv($file, array(
                                        $row['Sr No'],
                                        $row['Employee'],
                                        $row['Visit Type'],
                                        $row['Visit Name'],
                                        $row['Other Claim'],
                                        $row['Visit Date'],
                                        $row['Vehicle Type'],
                                        $row['Tier'],
                                        $row['City'],
                                        $row['Amount'],
                                        $row['Status'],
                                        $row['Status Changed By'],
                                   ));
                                   $srNo++;
                              }

                              fclose($file);
                         };
                         return response()->stream($callback, 200, $headers);
                    }
                    return view('report.claim', compact('claims', 'status', 'filterYear', 'filter'));
               }
               else
               {
                    return redirect()->back()->with('error', __('Permission denied.'));
               }
          }
          catch (Exception $e)
          {
               // dd($e);
               return redirect()->back()->with('error', showExceptionMessage($e));
          }
          catch (Throwable $e)
          {
               return redirect()->back()->with('error', showExceptionMessage($e));
          }
     }
}
